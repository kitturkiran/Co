from fastapi import FastAPI
from .auth import auth_router
from .schemes import cv_ce_router, auto_couns_router, cv_counsellor_router, tw_router, Auto_Dma,Tw_Weeler_SE,auto_couns_man_router,auto_couns_booster_router,Auto_Dma_booster,cv_ce_router_med,cv_ce_router_booster,cv_counsellor_MED_router,cv_indostar_router,tw_indostar_router
import warnings
warnings.filterwarnings("ignore")

app = FastAPI()

@app.get("/", tags=["Home"])
def home():
    return "Welcome to CCCO Payout"


app.include_router(auth_router, tags=["Authorization"], prefix="/auth")
app.include_router(Auto_Dma, tags=["Auto DMA"], prefix="/auto-dma")
app.include_router(Auto_Dma_booster, tags=["Auto Dma_booster"], prefix="/auto_dma_booster")
app.include_router(auto_couns_router, tags=["Auto Counsellor"], prefix="/auto-couns")
app.include_router(auto_couns_booster_router, tags=["Auto Counsellor_booster"], prefix="/auto_coun_booster")
app.include_router(auto_couns_man_router, tags=["Auto Counsellor_manipal"], prefix="/auto-couns_man")
app.include_router(cv_ce_router, tags=["CV-CE"], prefix="/cv-ce")
app.include_router(cv_ce_router_booster, tags=["cv_ce_booster"], prefix="/cv_ce_booster")
app.include_router(cv_ce_router_med, tags=["cv_ce_medical"], prefix="/cv_cd_medical")
app.include_router(cv_counsellor_router, tags=["CV Counsellor"], prefix="/cv-couns")
app.include_router(tw_router, tags=["Two Wheeler"], prefix="/two-wheeler")
app.include_router(Tw_Weeler_SE, tags=["Two Wheeler_SE"], prefix="/two-wheeler_SE")
app.include_router(cv_counsellor_MED_router,tags=["CV_counsellor_MED"],prefix="/cv_couns_med")
app.include_router(cv_indostar_router,tags=["CV_Indostar"],prefix="/cv_indostar")
app.include_router(tw_indostar_router,tags=["TW_Indostar"],prefix="/tw_indostar")



