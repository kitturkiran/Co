from fastapi import APIRouter, Body, HTTPException
from .models import UserSchema, UserLoginSchema
from .auth_handler import signJWT
from passlib.context import CryptContext
import json

auth_router = APIRouter()

hash_helper = CryptContext(schemes=["bcrypt"])


def add_user(new_user: dict):
    with open("users.json") as user_file:
        user_list = json.load(user_file)
        
    user_list.append(new_user)
    
    with open("users.json", 'w') as user_file:
        json.dump(user_list, user_file, indent=4, separators=(',',': '))


def validate_login(data: UserLoginSchema):
    with open("users.json") as user_file:
        user_list = json.load(user_file)
        
    for user in user_list:
        if user["email"] == data.email and hash_helper.verify(data.password, user["password"]):
            return True
    
    return False


@auth_router.post("/signup")
async def user_signup(user: UserSchema = Body()):
    user.password = hash_helper.encrypt(user.password)
    add_user(dict(user))
    
    return signJWT(user.email)


@auth_router.post("/login")
async def user_login(user: UserLoginSchema = Body()):
    if validate_login(user):
        return signJWT(user.email)
    else:
        raise HTTPException(status_code=401, detail="Invalid login credentials")