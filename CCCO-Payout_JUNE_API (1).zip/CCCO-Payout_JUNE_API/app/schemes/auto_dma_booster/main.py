import pandas as pd
from data_calculation_old1 import Calculation
from data_massaing_old import delhi_gird
from data_calculation_new import Calculation1
from summary_new import generateSummary
from summary_old import generateSummary1

# df_new_jan=pd.read_excel(r"D:\schema _scource code\Auto DMA\Auto Dma January 2023\Auto dma _january_booster\Input_file\Auto DMA New Car_January 23.xlsx")
# df_old_jan=pd.read_excel(r"D:\schema _scource code\Auto DMA\Auto Dma January 2023\Auto dma _january_booster\Input_file\Auto DMA Used Car_January 23.xlsx")
df_new_feb=pd.read_excel(r"C:\Users\kiran.k\Downloads\Auto DMA\AUTO DMA_NEW CAR_OUTPUT_MAY23.xlsx")
df_old_feb=pd.read_excel(r"C:\Users\kiran.k\Downloads\Auto DMA\Auto Dma\Auto dma _booster\Input_file\AUTO DMA_USED CAR_OUTPUT_MAY2023.xlsx")
df_new_jan=pd.read_excel(r"C:\Users\kiran.k\Downloads\Auto DMA\Auto Dma\Auto dma _booster\Input_file\AUTO DMA_NEW CAR_OUTPUT_APRIL23.xlsx")
df_old_jan=pd.read_excel(r"C:\Users\kiran.k\Downloads\Auto DMA\Auto Dma\Auto dma _booster\Input_file\AUTO DMA_USED CAR_OUTPUT_APRIL23.xlsx")
tagging_path = r"C:\Users\kiran.k\Downloads\Auto DMA\Auto Dma\Auto dma _booster\Input_file\Tagging All.xlsx"
tagging_new_df = pd.read_excel(tagging_path, sheet_name="New")
tagging_used_df = pd.read_excel(tagging_path, sheet_name="Used")


obj=Calculation(df_old_feb,df_old_jan,tagging_used_df)
obj.execute()
# # print("kiran")
# # # obj=Calculation1(df_new_jan,df_new_feb)
# # # obj.execute1()
# # # Booster=obj.df_old_jan
delhi_gird=delhi_gird(obj.df_old_feb)
# print("kiran")

delhi_gird.to_excel("booster_used.xlsx",index=False)
# obj.df_old_feb.to_excel("booster_used1.xlsx")

obj1=Calculation1(df_new_jan,df_new_feb,tagging_new_df)
obj1.execute1()
obj1.df_feb_new.to_excel("booster_new.xlsx",index=False)
new_car_summary=generateSummary(obj1.df_feb_new)
old_car_summary=generateSummary1(delhi_gird,new_car_summary)#audm02232742
# new_old_car_summary=pd.concat([new_car_summary,old_car_summary],ignore_index=True)
# new_old_car_summary.insert(0,"Ref No",range(2831,2831+new_old_car_summary.shape[0]))
# new_old_car_summary["Ref No"]=new_old_car_summary["Ref No"].apply(lambda x:"AUDM0423"+str(x))
new_car_summary.to_excel("summary_booster_new.xlsx",index=False)
old_car_summary.to_excel("summary_booster_old.xlsx",index=False)
output_new_used=pd.concat([obj1.df_feb_new,delhi_gird],ignore_index=True)
output_new_used.rename(columns={"DMABROKERCODE_y":"DMABROKERCODE"},inplace=True)
output_new_used["GST State From"]=output_new_used["GST State From"].str.lower()
output_new_used["GST State To"]=output_new_used["GST State To"].str.lower()
output_new_used.rename(columns={"Auto Type":"CAR TYPE"},inplace=True)
output_new_used.rename(columns={"GST State From":"FROM LOCATION"},inplace=True)
output_new_used.rename(columns={"GST State To":"TO LOCATION"},inplace=True)
output_new_used=pd.merge(output_new_used,old_car_summary[["Ref No","DMABROKERCODE","FROM LOCATION","TO LOCATION","CAR TYPE"]],on=["DMABROKERCODE","FROM LOCATION","TO LOCATION","CAR TYPE"],how="left")
# columns=["AUTO DEBIT","Nill_Payout_Remark","alto_cases","CHANNELCODE1","NO_of_cases_jan","NO_of_cases_dec","135% of previous month	PO_rate	Target Condition	payout	temp_broker	Count_of_temp_broker	Count_of_temp_broker1	Overrate_remark	Override_rate+po_rate	Override_rate+po_rate1

output_new_used.to_excel("summary__new_old_booster.xlsx",index=False)
# new_old_car_summary.to_excel("summary_new_old_booster_old.xlsx",index=False)
# summary_new_old.to_excel("summary_booster_new_old.xlsx",index=False)