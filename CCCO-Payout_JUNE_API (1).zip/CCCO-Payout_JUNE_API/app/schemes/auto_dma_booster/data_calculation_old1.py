import pandas as pd

class Calculation:
    def __init__(self,df_old_feb:pd.DataFrame,df_old_jan:pd.DataFrame,tagging:pd.DataFrame,start_date,end_date):
        self.df_old_feb=df_old_feb
        self.df_old_jan=df_old_jan
        self.tagging=tagging
        self.start_date=start_date
        self.end_date-end_date


    def Add_structure(self):
        # self.df_old_jan.loc[(self.df_old_jan["Consolidated State for Po processing"]=="AP/ROTG"),"Temp_State"]="Andhra Pradesh"
        self.df_old_feb=pd.merge(self.df_old_feb,self.tagging[["AGREEMENTNO","Booster condition"]],on="AGREEMENTNO",how="left")
        self.df_old_jan["Sum_of_amtfin_jan"]=0
        self.df_old_jan["No_of_count_jan"]=0
        self.df_old_feb["No_of_count"]=0
        self.df_old_feb["Sum_of_amtfin_feb"]=0
        self.df_old_feb["previous_moth 15%"]=0
        self.df_old_feb["previous_moth 30%"]=0
    def applicableState_dec(self):
        self.df_old_jan["Temp_State"] = self.df_old_jan["Consolidated State for Po processing"].str.lower()
        self.df_old_jan.loc[(self.df_old_jan["Consolidated State for Po processing"]=="AP/ROTG"),"Temp_State"]="andhra pradesh"
        self.df_old_jan.loc[(self.df_old_jan["Consolidated State for Po processing"].isin(["Delhi", "Noida", "Gurgaon"])), "Temp_State"] = "delhi"
        # self.df_old_jan.loc[(self.df_old_jan["Consolidated State for Po processing"].isin(["Haryana", "Pun, HP, J&K"])), "Temp_State"] = "Haryana"
        self.df_old_jan.loc[(self.df_old_jan["Consolidated State for Po processing"].isin(["Haryana", "Punjab","HP","J&K"])), "Temp_State"] = "haryana"   
    def Previous_month_amtsum(self):
        self.df_old_jan["Sum_of_amtfin_jan"]=self.df_old_jan.groupby(["DMABROKERCODE_y","Temp_State"])["AMTFIN"].transform(sum)
        self.df_old_jan["No_of_count_jan"]=self.df_old_jan.groupby(["DMABROKERCODE_y","Temp_State"])["DMABROKERCODE_y"].transform("count")
    def applicableState(self):
        self.df_old_feb["Temp_State"] = self.df_old_feb["Consolidated State for Po processing"].str.lower()
        self.df_old_feb.loc[(self.df_old_feb["Consolidated State for Po processing"].isin(["Delhi", "Noida", "Gurgaon"])), "Temp_State"] = "delhi"
        self.df_old_feb.loc[(self.df_old_feb["Consolidated State for Po processing"].isin(["Haryana", "Punjab","HP","J&K"])), "Temp_State"] = "haryana"
    def Present_month(self):
        self.df_old_feb["No_of_count"]=self.df_old_feb.groupby(["DMABROKERCODE_y","Temp_State"])["DMABROKERCODE_y"].transform("count")
        self.df_old_feb["Sum_of_amtfin_feb"]=self.df_old_feb.groupby(["DMABROKERCODE_y","Temp_State"])["AMTFIN"].transform(sum)
    
    def merging_both_month(self):
        self.df_old_feb=pd.merge(self.df_old_feb,self.df_old_jan[["DMABROKERCODE_y","Temp_State","Sum_of_amtfin_jan","No_of_count_jan"]],on=["DMABROKERCODE_y","Temp_State"],how="left")
        self.df_old_feb["Sum_of_amtfin_feb"].fillna(0,inplace=True)

        
        self.df_old_feb["previous_moth 15%"]=self.df_old_feb["Sum_of_amtfin_jan"]*1.15
        self.df_old_feb["previous_moth 30%"]=self.df_old_feb["Sum_of_amtfin_jan"]*1.30
        self.df_old_feb["previous_moth_no_of count 15%"]=self.df_old_feb["No_of_count_jan"]*1.15
        self.df_old_feb["previous_moth_no_of count 30%"]=self.df_old_feb["No_of_count_jan"]*1.30
        self.df_old_feb=self.df_old_feb[(self.df_old_feb["AGREEMENTNO"].duplicated()==False)]
        
        self.df_old_feb.loc[((self.df_old_feb["previous_moth 15%"]<1500000)),"previous_moth 15%"]=1500000
        self.df_old_feb.loc[((self.df_old_feb["previous_moth_no_of count 15%"]<4)),"previous_moth_no_of count 15%"]=4
        
        self.df_old_feb.loc[((self.df_old_feb["previous_moth 30%"]<3500000)),"previous_moth 30%"]=3500000
        self.df_old_feb.loc[((self.df_old_feb["previous_moth_no_of count 30%"]<7)),"previous_moth_no_of count 30%"]=7
        
        self.df_old_feb["No_of_count_jan"].fillna(0,inplace=True)
        self.df_old_feb["previous_moth_no_of count 15%"].fillna(0,inplace=True)
        self.df_old_feb["previous_moth_no_of count 30%"].fillna(0,inplace=True)
        

    def Calculation(self):
        self.df_old_feb["PO rate after capping"]=0
        self.df_old_feb.loc[(((self.df_old_feb["Sum_of_amtfin_feb"]>=3500000)|(self.df_old_feb["No_of_count"]>=7))&((self.df_old_feb["Sum_of_amtfin_feb"]>=self.df_old_feb["previous_moth 30%"])|(self.df_old_feb["No_of_count"]>=self.df_old_feb["previous_moth_no_of count 30%"]))),"PO rate after capping"]=0.0050
        self.df_old_feb.loc[(((self.df_old_feb["Sum_of_amtfin_feb"]>=1500000)|(self.df_old_feb["No_of_count"]>=4))&((self.df_old_feb["Sum_of_amtfin_feb"]>=self.df_old_feb["previous_moth 15%"])|(self.df_old_feb["No_of_count"]>=self.df_old_feb["previous_moth_no_of count 15%"]))&(self.df_old_feb["PO rate after capping"]==0)),"PO rate after capping"]=0.0025

    
    def NIL_PAYOUT(self):
        brocker_code=[266338,
                    266450,
                    269302,
                    275078,
                    274328,
                    286228,
                    302241,
                    230043,
                    302312,
                    311204,
                    316343,
                    
                    ]
        self.df_old_feb.loc[(self.df_old_feb["DMABROKERCODE_x"].isin(brocker_code)),"PO rate after capping"]=0
    
    
    def Hyderabad(self):
        broker_code11={250056:15,
                    309571:5,
                    217893:5,
                    301886:5,
                    299986:5,
                    284597:7.5,
                    303047:5,
                    269650:6,
                    299704:6,
                    301145:5,
                    300243:5,
                    180508:3,
                    300186:5,
                    301221:3.5,
                    303048:3.5,
                    299831:3.5,
                    301223:2.5,
                    300242:2.5,
                    158383:2.5,
                    255197:3,
                    315087:10,
                    306519:2.5,
                    # 301216:2.5,
                    # 225369:2.5,
                    183831:3.5,
                    # 302152:2.5,
                    # 236901:2.5,
                    283609:3,
                    311249:3,

                    

        }   
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="Hyderabad"
        for i in broker_code11.keys():
            # for j in rate:
                
                tad2=self.df_old_feb[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                print(tad2,"kiran")
                if (tad2>=broker_code11[i]*1000000):
                    self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i) & ((self.df_old_feb["PROCHANNEL"]=="sale purchase")),"PO rate after capping"]=0.01
                else:
                    self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)& ((self.df_old_feb["PROCHANNEL"]=="sale purchase")),"PO rate after capping"]=0
                # self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)& ((self.df_old_feb["PROCHANNEL"]=="refinance")),"PO rate after capping"]=0

    def Bangalore(self):
        broker_code11={
                        171062:2.5,
                        141524:2,
                        256398:10,
                        164432:3,
                        312927:2.5,
                        304002:3,
                        171800:2,
                        180231:2.5,
                        216758:2,
                        201159:7.5,
                        188988:2.5,
                        265711:5,
                        211568:2,
                        296463:5,
                        183412:3,
                        194656:7.5,
                        290612:2,
                        181807:3,
                        178434:3,
                        260798:5,
                        254169:2,
                        316945:3,
                        248915:3,


                    

        }   
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="Bangalore"
        for i in broker_code11.keys():
            # for j in rate:
                
                tad2=self.df_old_feb[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                print(tad2,"kiran")
                if (tad2>=broker_code11[i]*1000000):
                    self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0.0025
                else:
                    self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0
    
    def Bangalore1(self):
        broker_code11={
                        171062:5,
                        141524:4,
                        256398:12.5,
                        164432:5,
                        312927:5,
                        304002:5,
                        171800:4,
                        180231:5,
                        216758:4,
                        201159:10,
                        188988:5,
                        265711:7.5,
                        211568:4,
                        296463:7.5,
                        183412:5,
                        194656:10,
                        290612:4,
                        181807:5,
                        178434:5,
                        260798:7.5,
                        254169:4,
                        316945:5,
                        248915:5,


                    

        }   
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="Bangalore"
        for i in broker_code11.keys():
            # for j in rate:
                
                tad2=self.df_old_feb[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                print(tad2,"kiran")
                if (tad2>=broker_code11[i]*1000000):
                    self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0.0050
                # else:
                #     self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0    
    
    def pune(self):
        broker_code11=[
                        143627,
                        101979,
                        127790,
                        163850,
                        170597,
                        134470,
                        220776,
                        235025,
                        160717,
                        170417,
                        104822,
                        174886,
                        237388,
                        303533,
                        264142,
                        168396,



                    

        ]  
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="pune"
        for i in broker_code11:
            # for j in rate:
                # self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0
                self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)&(self.df_old_feb["PROCHANNEL"]=="sale purchase")&(self.df_old_feb["PRETAXIRR"] < 12.75),"PO rate after capping"]=0
                # self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i)&(self.df_old_feb["PROCHANNEL"]!="sale purchase"),"PO rate after capping"]=0.0025
                # print(tad2,"kiran")
                # if (tad2>=broker_code11[i]*1000000):
                    # self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i),"PO rate after capping"]=0.0050
    
    def execute(self):
        self.Add_structure()
        self.applicableState_dec()
        # self.Previous_month_amtsum()
        self.applicableState()
        self.Previous_month_amtsum()
        self.Present_month()
        self.merging_both_month()
        # self.pune()
        self.Calculation()
        self.pune()
        self.NIL_PAYOUT()
        # self.Hyderabad()
        # self.Bangalore()
        # self.Bangalore1()