import pandas as pd
import math
from datetime import datetime

class Calculation1:
    def __init__(self,df_jan_new,df_feb_new,tagging):
        self.df_feb_new=df_feb_new
        self.df_jan_new=df_jan_new
        self.tagging=tagging
        print(self.df_feb_new.shape[0])
    def Add_Structure(self):
        
        self.df_jan_new.loc[(self.df_jan_new["Consolidated State for Po processing"]=="AP/ROTG"),"Temp_State"]="Andhra Pradesh"
        self.df_feb_new=pd.merge(self.df_feb_new,self.tagging[["AGREEMENTNO","Booster condition"]],on="AGREEMENTNO",how="left")
        self.df_feb_new["NO_of_cases_jan"]=0
        self.df_jan_new["NO_of_cases_dec"]=0
        self.df_jan_new.loc[(self.df_jan_new["Temp_State"]=="UTTARAKHAND"),"Temp_State"]="Uttarakhand"
        # self.df_feb_new["Temp_State"]=self.df_feb_new["Temp_State"].str.lower()
    
    def NO_of_cases(self):
        self.df_feb_new["NO_of_cases_jan"]=self.df_feb_new.groupby(["DMABROKERCODE_y","Temp_State"])["DMABROKERCODE_y"].transform("count")
        self.df_jan_new["NO_of_cases_dec"]=self.df_jan_new.groupby(["DMABROKERCODE_y","Temp_State"])["DMABROKERCODE_y"].transform("count")
    
    def Merge(self):
        self.df_feb_new=pd.merge(self.df_feb_new,self.df_jan_new[["DMABROKERCODE_y","Temp_State","NO_of_cases_dec"]],on=["DMABROKERCODE_y","Temp_State"],how="left")
        self.df_feb_new["NO_of_cases_dec"].fillna(0,inplace=True)
        self.df_feb_new["135% of previous month"]=0
        self.df_feb_new["135% of previous month"]=self.df_feb_new["NO_of_cases_dec"]*1.35
        self.df_feb_new.loc[(self.df_feb_new["135% of previous month"]<15),"135% of previous month"]=15
        # self.df_feb_new.loc[(self.df_feb_new["Consolidated State for Po processing"]=="Kerala") & (self.df_feb_new["Override Rate"]<=0),"Override Rate"]=self.df_feb_new["Base Rate"]
    
    def Calculation(self):
        self.df_feb_new["PO_rate"]=0
        self.df_feb_new.loc[(self.df_feb_new["NO_of_cases_jan"]>=15)&(self.df_feb_new["NO_of_cases_jan"]>=self.df_feb_new["135% of previous month"]),"PO_rate"]=0.0025
        # self.df_feb_new.loc[(self.df_feb_new["135% of previous month"]<15),"135% of previous month"]=0
        self.df_feb_new=self.df_feb_new.loc[(self.df_feb_new["AGREEMENTNO"].duplicated()==False)]
    def Calculation_gird(self):
        broker={
                286169:5,
                218551:5,
                326068:5,
                192451:5,
                319343:5,
                253940:5,
                284407:5,
                237613:5,
                183457:10,
                259667:5,
                264832:10,
                155962:10,
                149898:10,
                105059:5,
                229137:8,
                103112:17,
                267747:8,
                240630:5,
                265985:24,
                293014:15,
                245813:9,
                285333:5,
                226183:10,
                214897:5,
                115918:5,
                286346:5,
                188120:10,
                101427:10,
                191017:5,
                315009:5,
                192445:5,
                182906:10,
                297970:5,
                197088:5,
                246529:5,
                305143:5,
                320581:5,
                102356:5,
                293543:5,
                168489:5,
                290386:5,
                258602:5,
                289887:5,
                304050:5,
                269742:5,
                290820:5,
                306958:5,
                284866:5,
                247476:5,
                270450:5,
                101626:5,
                207944:10,
                240373:5,
                293545:10,
                226554:5,
                290811:5,
                175573:5,
                272694:12,
                264830:5,
                234498:10,
                216469:5,
                271884:5,
                219607:5,
                168612:5,
                294335:5,
                181479:5,
                210414:10,
                320439:5,
                299838:10,
                172823:5,
                153152:5,
                244807:5,
                297745:5,
                191975:5,
                214056:5,
                289922:5,
                134660:10,


                
                
                }




        rate=[ 5.00, 
                5.00, 
                5.00,
                5.00,
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                10.00,
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00, 
                8.00, 
                8.00, 
                8.00, 
                10.00, 
                5.00, 
                5.00, 
                8.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00, 
                17.00, 
                10.00, 
                18.00, 
                25.00, 
                5.00, 
                17.00, 
                10.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                12.00, 
                5.00, 
                10.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                5.00, 
                10.00, 
                5.00]


        self.df_feb_new["Target Condition"]=0
        self.df_feb_new["payout"]=0
        # k="Rajasthan"
        # for i in broker.keys():
            
                
        #         tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
        #         if tad2>((broker[i])*1000000):
        #             self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0.0025
        #         else:
        #             self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0
        

    def Calculation_Mumbai_countwise(self):
        self.df_feb_new["temp_broker"]=self.df_feb_new["DMABROKERCODE_y"]
        broker_code1=[104532,301720]
        broker_code2=[230164,227613,163891]
        broker_code3=[272355,181343]
        broker_code4=[256601,209562,164968]
        broker_code5=[261656,218674,299254]
        broker_code6=[291778,295348]
        broker_code7=[106746,266367]
        broker_code8=[205115,260414,227880,310184]
        broker_code9=[235320,191433,273843,234376,299357]
        broker_code10=[171071,173193]
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([301720])),"temp_broker"]=104532
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([227613,163891])),"temp_broker"]=230164
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([181343])),"temp_broker"]=272355
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([209562,164968])),"temp_broker"]=256601
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([173503,179283,299254])),"temp_broker"]=104566
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([295348])),"temp_broker"]=291778
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([266367])),"temp_broker"]=106746
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([227880,227880,310184])),"temp_broker"]=205115
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([191433,273843,234376,299357])),"temp_broker"]=235320
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([173193])),"temp_broker"]=171071
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([173503,179283,299254])),"temp_broker"]=104566
        
        self.df_feb_new["Count_of_temp_broker"]=self.df_feb_new.groupby(["temp_broker","Temp_State"])["temp_broker"].transform("count")
        self.df_feb_new["Count_of_temp_broker1"]=self.df_feb_new.groupby(["temp_broker"])["temp_broker"].transform("count")
        broker_code11={
                        311146:5,
                        233609:10,
                        104532:15,
                        101402:15,
                        230164:8,
                        268143:8,
                        298069:3,
                        144140:5,
                        287915:17,
                        273842:20,
                        239294:8,
                        272355:10,
                        144435:2,
                        256601:3,
                        245024:8,
                        222151:4,
                        177945:7,
                        123964:3,
                        177295:3,
                        104566:15,
                        291778:3,
                        244983:10,
                        258295:11,
                        101696:15,
                        177591:8,
                        308499:11,
                        196575:6,
                        236531:10,
                        172023:19,
                        215034:8,
                        106746:25,
                        152966:8,
                        205823:6,
                        270686:7,
                        244694:4,
                        172769:7,
                        271489:8,
                        104549:3,
                        205115:16,
                        235320:22,
                        244737:8,
                        173974:5,
                        171071:15,
                        176842:3,
                        221815:3,
                        170960:3,





                    
                    

        }
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="Mumbai"
        for i in broker_code11.keys():
            # for j in rate:
                
                tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i)]["Count_of_temp_broker"].shape[0]
                print(tad2)
                if (tad2>=broker_code11[i]):
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i),"PO_rate"]=0.0025
                else:
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i),"PO_rate"]=0
        
    

        broker_code11={
                        104980:15,
                        245024:50,
                        # 179033:
                        # 197095
                        321366:3,
                        100923:11,
                        101104:11,
                        245566:11,
                        262946:11,
                        190277:11,
                        301581:11,
                        # 182909
                        # 194294
                        104571:15,
                        161819:11,
                        244808:3,
                        247477:3,
                        109358:11,
                        175384:11,
                        # 175121
                        # 288416
                        # 175119
                        266336:20,
                        161837:3,
                        113117:11,
                        101393:40,
                        225230:15,
                        # 104882
                        # 308587
                        # 206735
                        # 225107
                        128147:60,
                        # 101749:
                        # 305248
                        # 172223
                        # 247733
                        239218:25,
                        101046:65,
                        # 198344
                        # 266733
                        # 244287
                        287146:3,
                        # 272647
                        # 315130
                        # 158237
                        252713:15,
                        # 174472:11,
                        # 305790
                        # 296224
                        265709:15,
                        265983:13,
                        # 316163
                        # 317467
                        311386:7,
                        # 311388:7,
                        311497:7,
                        # 153813
                        # 182352
                        # 261556/
                        # 295671
                        # 322549
                        290980:15,
                        # 233260
                        # 284252
                        307873:11,
                        297826:11,
                        190275:25,
                        185496:11,
                        237745:11,
                        285704:11,
                        166457:15,
                        102467:11,
                        196888:11,
                        256606:13,
                        231275:11,
                        169498:11,
                        101139:11,
                        291956:11,
                        286415:11,
                        191668:20,





                    
                    

        }
        rate=[11,
            11,
            7,
            15,
            15,
            15,
            12,
            15,
            7,
            5,
            11,
            20,
            11,
            10,
            0,
            15,
            11,
            10,
            5,
            4,
            0,
            15,
            0,
            12,
            11,
            0,
            5,
            7,
            12,
            10,
            15,
            10,
            15,
            15,
            14,
            0,
            5,
            6,
            7,
            0,
            15,
            10,
            15,
            15,
            12,
            0,
            10,
            7,
            9,
            10,
            7,
            5,
            11,
            4,
            11,
            20,
            15,
            5,
            15,
            15,
            5,
            5,
            5,
            4,
            15
            ]
        
        k="Gujarat"
        for i in broker_code11.keys():
            # for j in rate:
                
                tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i)]["Count_of_temp_broker"].shape[0]
                print(tad2)
                if (tad2>=broker_code11[i]):
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i),"PO_rate"]=0.0025
                else:
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["temp_broker"]==i),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([179033,197095]))]["Count_of_temp_broker"].shape[0]
        if tad2>=75:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([179033,197095])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([179033,197095])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([182909,194294]))]["Count_of_temp_broker"].shape[0]
        if tad2>=11:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([182909,194294])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([182909,194294])),"PO_rate"]=0
            
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([175121,288416,175119]))]["Count_of_temp_broker"].shape[0]
        if tad2>=20:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([175121,288416,175119])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([175121,288416,175119])),"PO_rate"]=0


        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([104882,308587,206735,225107]))]["Count_of_temp_broker"].shape[0]
        if tad2>=20:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([104882,308587,206735,225107])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([104882,308587,206735,225107])),"PO_rate"]=0
        
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([101749,305248,172223,247733]))]["Count_of_temp_broker"].shape[0]
        if tad2>=20:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([101749,305248,172223,247733])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([101749,305248,172223,247733])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([198344,266733,244287]))]["Count_of_temp_broker"].shape[0]
        if tad2>=15:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([198344,266733,244287])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([198344,266733,244287])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([272647,315130,158237]))]["Count_of_temp_broker"].shape[0]
        if tad2>=45:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([272647,315130,158237])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([272647,315130,158237])),"PO_rate"]=0


        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([305790,296224]))]["Count_of_temp_broker"].shape[0]
        if tad2>=11:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([305790,296224])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([305790,296224])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([316163,317467]))]["Count_of_temp_broker"].shape[0]
        if tad2>=3:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([316163,317467])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([316163,317467])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([153813,182352,261556,295671,322549]))]["Count_of_temp_broker"].shape[0]
        if tad2>=18:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([153813,182352,261556,295671,322549])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([153813,182352,261556,295671,322549])),"PO_rate"]=0

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([233260,284252]))]["Count_of_temp_broker"].shape[0]
        if tad2>=21:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([233260,284252])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([233260,284252])),"PO_rate"]=0        

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185071,314670]))]["Count_of_temp_broker"].shape[0]
        if tad2>=11:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185071,314670])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185071,314670])),"PO_rate"]=0         

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([266404,190277]))]["Count_of_temp_broker"].shape[0]
        if tad2>=15:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([266404,190277])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([266404,190277])),"PO_rate"]=0  

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([283550,116998]))]["Count_of_temp_broker"].shape[0]
        if tad2>=40:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([283550,116998])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([283550,116998])),"PO_rate"]=0     
     
     
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185853,294492,263669,311388]))]["Count_of_temp_broker"].shape[0]
        if tad2>=30:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185853,294492,263669,311388])),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([185853,294492,263669,311388])),"PO_rate"]=0   
        # tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==172769)]["AMTFIN"].sum()
        # if tad2>=10000000:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==172769),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==172769),"PO_rate"]=0
        
        # tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==196575)]["AMTFIN"].sum()
        # if tad2>=10000000:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==196575),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==196575),"PO_rate"]=0
        
        # tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([260414,310184,196575,172769]))]["AMTFIN"].sum()
        # if tad2>=10000000:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([260414,310184,196575,172769])),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([260414,310184,196575,172769])),"PO_rate"]=0    
  
  
        # tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595)]["AMTFIN"].sum()
        # if (tad2>=30000000):
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0.0050
        # elif(tad2>=20000000):
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0
            
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==236835)]["Count_of_temp_broker"].shape[0]
        if tad2>=45:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==236835),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==236835),"PO_rate"]=0        
        
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Bangalore") & (self.df_feb_new["DMABROKERCODE_y"]==164968)&(self.df_feb_new["Irr roundup"]<=8.75),"PO_rate"]=0
        
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==101402)]["Count_of_temp_broker"].shape[0]
        # if tad2>=15:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==101402),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==101402),"PO_rate"]=0        
        
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([299254]))]["AMTFIN"].sum()
        if tad2>=30000000:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==299254),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==299254),"PO_rate"]=0 

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([173193]))]["AMTFIN"].sum()
        if tad2>=30000000:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==173193),"PO_rate"]=0.0025
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==173193),"PO_rate"]=0 
        
        
        
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kolkata") & (self.df_feb_new["DMABROKERCODE_y"]==237744)]["AMTFIN"].sum()
        # if tad2>=20000000:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kolkata") & (self.df_feb_new["DMABROKERCODE_y"]==237744),"PO_rate"]=0.0030
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kolkata") & (self.df_feb_new["DMABROKERCODE_y"]==237744),"PO_rate"]=0         
        # mumbai with Double target
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==104755)]["Count_of_temp_broker"].shape[0]
        # if tad2>=50:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==104755),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==104755),"PO_rate"]=0 

        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==112362)]["Count_of_temp_broker"].shape[0]
        # if tad2>=50:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==112362),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"]==112362),"PO_rate"]=0 
    
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216]))]["Count_of_temp_broker"].shape[0]
        tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((tad2>=50)|(tad3>=60000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0.0025
        
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([181343]))]["Count_of_temp_broker"].shape[0]
        tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([181343]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((tad2>=10)|(tad3>=100000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([181343])),"PO_rate"]=0.0025

        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([272355]))]["Count_of_temp_broker"].shape[0]
        tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([272355]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((tad2>=10)|(tad3>=100000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([272355])),"PO_rate"]=0.0025        
        
        
        
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kerala") & (self.df_feb_new["DMABROKERCODE_y"].isin([131389]))]["Count_of_temp_broker"].shape[0]
        tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kerala") & (self.df_feb_new["DMABROKERCODE_y"].isin([131389]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kerala")&((tad3>=45000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([131389])),"PO_rate"]=0.0025
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kerala")&((tad3>=50000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([131389])),"PO_rate"]=0.0035
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Kerala")&((tad3>=30000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([131389])),"PO_rate"]=0.0025
        
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([164897]))]["Count_of_temp_broker"].shape[0]
        # tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([164897]))]["AMTFIN"].sum()
        # # if tad2>=50:
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((tad2>=15)|(tad3>=30000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([164897])),"PO_rate"]=0.0025        
        
        
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((tad2<50)|(tad3<60000000)) & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0.0025
            # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0   
        
        # elif:
            
            
        # tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216]))]["AMTFIN"].sum()
        # if tad2>=60000000:
        #         self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0.0025
        # else:
        #         self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0        

        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai") & (self.df_feb_new["DMABROKERCODE_y"].isin([104755,112362,244216])),"PO_rate"]=0   
            
        
        broker_code={
                    266134:20,
                    255535:20,
                    164514:20,
                    242595:20,
                    262041:15,
                    269736:15,
                    122452:15,
                    164572:10,
                    109512:15,
                    269889:15,
                    243198:20,


        }
        rate=[ 20.00, 
            20.00,
            20.00,
            20.00,
            20.00, 
            15.00, 
            15.00, 
            20.00, 
            20.00, 
            15.00, 
            15.00, 
            20.00, 
            20.00,
            ]
        k="Chennai"
        for i in broker_code.keys():
            # for j in rate:
                
                tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                if tad2>=(broker_code[i]*1000000):
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0.0025
                else:
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0
        
    
        tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==275151)]["AMTFIN"].sum()
        if tad2>=10000000:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==275151),"PO_rate"]=0.0025
        if(tad2>=20000000):
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==275151),"PO_rate"]=0.0050
        else:
            self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==275151),"PO_rate"]=0
    

        # tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595)]["AMTFIN"].sum()
        # if (tad2>=30000000):
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0.0050
        # elif(tad2>=20000000):
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0.0025
            
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"]==242595),"PO_rate"]=0

        
        broker_code={
                    270453:10,
                    192663:10,
                    239420:10,
                    243456:10,
                    314023:10,
                    187519:10,
                    237744:10,
                    207048:10,
                    244992:10,
                    192315:10,


        }
        
        broker_code1={
                    270453:15,
                    192663:15,
                    239420:15,
                    243456:15,
                    314023:15,
                    187519:15,
                    237744:15,
                    


        }
        rate=[ 20.00, 
            20.00,
            20.00,
            20.00,
            20.00, 
            15.00, 
            15.00, 
            20.00, 
            20.00, 
            15.00, 
            15.00, 
            20.00, 
            20.00,
            ]
        k="Kolkata"
        for i in broker_code.keys():
            # for j in rate:
                
                tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                if tad2>=(broker_code[i]*1000000):
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0.0025
                else:
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0
    
        for i in broker_code1.keys():
            # for j in rate:
                
                tad2=self.df_feb_new[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i)]["AMTFIN"].sum()
                if tad2>=(broker_code1[i]*1000000):
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0.0050
                else:
                    self.df_feb_new.loc[(self.df_feb_new["Temp_State"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"PO_rate"]=0    
        
        
        
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([318136,266135,206822]))]["Count_of_temp_broker"].shape[0]
        # tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([206822,266135,206822]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=50)) & (self.df_feb_new["DMABROKERCODE_y"].isin([318136,266135,206822])),"PO_rate"]=0.0025
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=80)) & (self.df_feb_new["DMABROKERCODE_y"].isin([318136,266135,206822])),"PO_rate"]=0.0035
        
        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([275151]))]["Count_of_temp_broker"].shape[0]
        # tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([206822,266135,206822]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=10)) & (self.df_feb_new["DMABROKERCODE_y"].isin([275151])),"PO_rate"]=0.0025
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=20)) & (self.df_feb_new["DMABROKERCODE_y"].isin([275151])),"PO_rate"]=0.0035


        tad2=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([273006]))]["Count_of_temp_broker"].shape[0]
        # tad3=self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai") & (self.df_feb_new["DMABROKERCODE_y"].isin([206822,266135,206822]))]["AMTFIN"].sum()
        # if tad2>=50:
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=25)) & (self.df_feb_new["DMABROKERCODE_y"].isin([273006])),"PO_rate"]=0.0025
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Chennai")&((tad2>=40)) & (self.df_feb_new["DMABROKERCODE_y"].isin([273006])),"PO_rate"]=0.0035      
        
        
        
        
        
        # tad2=self.df_feb_new.loc[(self.df_feb_new["DMABROKERCODE_y"]==316343)]["Count_of_temp_broker1"].shape[0]
        # if tad2>=50:
        #     self.df_feb_new.loc[(self.df_feb_new["DMABROKERCODE_y"]==316343),"PO_rate"]=0.0025
        # else:
        #     self.df_feb_new.loc[(self.df_feb_new["DMABROKERCODE_y"]==316343),"PO_rate"]=0 
            
            
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((self.df_feb_new["DMABROKERCODE_y"]==132727)),"PO_rate"]=0
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((self.df_feb_new["DMABROKERCODE_y"]==208196)),"PO_rate"]=0
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((self.df_feb_new["DMABROKERCODE_y"]==242658)),"PO_rate"]=0
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((self.df_feb_new["DMABROKERCODE_y"]==179215)),"PO_rate"]=0
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Mumbai")&((self.df_feb_new["DMABROKERCODE_y"]==162269)),"PO_rate"]=0
        self.df_feb_new.loc[(self.df_feb_new["AGREEMENTNO"]=="LAMUM00047227170"),"PO_rate"]=0.0025
        self.df_feb_new.loc[(self.df_feb_new["Final Rate"]==0,"PO_rate")]=0 
        self.df_feb_new.loc[(self.df_feb_new["Payout"]==0,"PO_rate")]=0 
        self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([104980,179033,197095])),"PO_rate"]=self.df_feb_new["PO_rate"]+(self.df_feb_new["PO_rate"]*0.09)
        self.df_feb_new=self.df_feb_new.apply(lambda x :self.override59(x),axis=1)
        self.df_feb_new["payout"]=self.df_feb_new["PO_rate"]*self.df_feb_new["Final Net Loan"]
        self.df_feb_new.loc[(self.df_feb_new["Override Rate"]>0),"Overrate_remark"]=self.df_feb_new["Final Rate"]
        self.df_feb_new.fillna(0,inplace=True)
        self.df_feb_new["Override_rate+po_rate"]=self.df_feb_new["PO_rate"]+self.df_feb_new["Overrate_remark"]
        self.df_feb_new["Override_rate+po_rate1"]=self.df_feb_new["PO_rate"]+self.df_feb_new["Overrate_remark"]
        self.df_feb_new["PO rate after capping"]=self.df_feb_new["PO_rate"]
        self.df_feb_new.loc[(self.df_feb_new["Override_rate+po_rate"]>0.02) & (self.df_feb_new["PO_rate"]>0),"Override_rate+po_rate"]=self.df_feb_new["Override_rate+po_rate"]-0.02
        self.df_feb_new.loc[(self.df_feb_new["Override_rate+po_rate1"]>0.02) & (self.df_feb_new["PO_rate"]>0),"PO rate after capping"]=self.df_feb_new["PO_rate"]-self.df_feb_new["Override_rate+po_rate"]
        self.df_feb_new["Booster_Payout"]=self.df_feb_new["PO rate after capping"]*self.df_feb_new["Final Net Loan"]
        # self.df_feb_new.loc[(self.df_feb_new["PO rate after capping"]<0),"PO rate after capping"]=0
        self.df_feb_new.loc[(self.df_feb_new["PO rate after capping"]<0),"Booster_Payout"]=0
        self.df_feb_new.loc[(self.df_feb_new["Overrate_remark"]>0.02),"Booster_Payout"]=0
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["Booster_Payout"]=round_up(row["Booster_Payout"])
            return row        
        self.df_feb_new=self.df_feb_new.apply(lambda x:Round_off(x),axis=1)    
    
    def Rejection(self):
        self.df_feb_new["Removing_cases"]=0
        list=[
                171392,
                105080,
                186596,
                258364,
                267937,
                193237,
                238079,
                220249,
                104425,
                317898,



            ]
        k="Punjab"
        for i in list:
            self.df_feb_new.loc[(self.df_feb_new["Consolidated State for Po processing"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"Removing_cases"]=1
        
        list1=[
                164968,
                266737,
                294336,
                141524,
                171062,
                101650,
                256398,
                179463,
                155473,
                167708,
                173194,
                112416,
                295008,
                267233,
                174384,
                104505,
                304002,
                164432,
                108210,
                173813,
                273607,
                227239,
                295009,
                261561,
                172149,
                
                ]
        k="Bangalore"
        for i in list1:
            self.df_feb_new.loc[(self.df_feb_new["Consolidated State for Po processing"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"Removing_cases"]=1
        
        
        # list2=[271161,
        #         144536,
        #         178998,
        #         265986,
        #         297103,
        #         ]
        # k="Delhi"
        # for i in list2:
        #     self.df_feb_new.loc[(self.df_feb_new["Consolidated State for Po processing"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"Removing_cases"]=1
        brocker_code=[
                        266338,
                        266450,
                        269302,
                        275078,
                        274328,
                        286228,
                        302241,
                        230043,
                        302312,
                        311204,
                        316343,

                    ]
        self.df_feb_new.loc[(self.df_feb_new["DMABROKERCODE_x"].isin(brocker_code)),"Removing_cases"]=1
        
        brocker_code=[
                        144063,
                        220001,
                        271170,
                        269496,
                        382965,
                        110214,
                        267936,
                        268354,


                    ]
        k="Chennai"
        for i in brocker_code:
            self.df_feb_new.loc[(self.df_feb_new["Consolidated State for Po processing"]==k) & (self.df_feb_new["DMABROKERCODE_y"]==i),"Removing_cases"]=1   
        
        
        
        
        self.df_feb_new=self.df_feb_new.loc[self.df_feb_new["Removing_cases"]==0] 
        self.df_feb_new.loc[(self.df_feb_new["Booster condition"]=="N"),"Booster_Payout"]=0
        self.df_feb_new.loc[(self.df_feb_new["Booster condition"]=="N"),"PO_rate"]=0
        self.df_feb_new.loc[(self.df_feb_new["Booster condition"]=="N"),"PO rate after capping"]=0
        self.df_feb_new.loc[(self.df_feb_new["PO rate after capping"]<0),"PO rate after capping"]=0
    def override59(self,row:pd.DataFrame):
        phase_date = datetime.strptime("21-04-2023", "%d-%m-%Y")

        if(row["DISB_DATE"] <= phase_date):
            return row

        if((row["Temp_State"].lower() == "delhi")):
            product = ["safari", "grand vitara", "verna", "hycross", "hyryder","xuv 700"]

            car_make = row["MAKE"].lower()
            irr = row["Irr roundup"]
            # for item in product:
            if(("safari" in car_make)|("grand vitara" in car_make)|("verna" in car_make)|("hycross" in car_make)|("hyryder" in car_make)|("xuv 700" in car_make)):
                    if(irr < 9.00):
                        row["PO_rate"] =0

                    # row["Override Remark"] += "59, "
                    
        # if(("urban cruiser" in car_make)|("glanza" in car_make)):
        #     if(irr >= 9.10):
        #         row["Override Rate"] = 0.0100
        #         if (row["Override Rate"]>0):
        #             row["Addition In Rate"] = (row["Override Rate"] * 0.09)
        #         # row["Addition In Rate"] = (row["Override Rate"] * 0.09)
        #         row["Override Remark"] += "34, "

        return row
        # self.df_feb_new.loc[(self.df_feb_new["Temp_State"]=="Gujarat") & (self.df_feb_new["DMABROKERCODE_y"].isin([104980,179033])),""]
    def execute1(self):
        self.Add_Structure()
        self.NO_of_cases()
        self.Merge()
        self.Calculation()
        self.Calculation_gird()
        self.Calculation_Mumbai_countwise()
        self.Rejection()
        # self.df_feb_new=self.df_feb_new.apply(lambda x :self.override59(x),axis=1)
        
        