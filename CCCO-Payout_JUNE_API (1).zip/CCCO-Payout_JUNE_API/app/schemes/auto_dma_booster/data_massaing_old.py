import pandas as pd
import math

def delhi_gird(df:pd.DataFrame):
    
    
    # tad1 = df[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==271161)]["AMTFIN"].sum()
    # tad2 = df[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==144536)]["AMTFIN"].sum()
    # tad3 = df[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998)]["AMTFIN"].sum()
    # if tad1>20000000:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"Remark03"]=0.0075
    # else:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"Remark03"]=0
        
    # if tad2>20000000:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==144536),"Remark03"]=0.0075
    # else:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==144536),"Remark03"]=0
        
    # if tad3>12500000:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"Remark03"]=0.0050
    # else:
    #     df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"Remark03"]=0
    df["Remark03"]=""
    df["Remark04"]=0
    # df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==271161),"PO rate after capping"]=0   
    # df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==144536),"PO rate after capping"]=0   
    # df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"PO rate after capping"]=0    
    # df.loc[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"]==231992) & (df["Irr roundup"]<=12.75),"PO rate after capping"]=0
    # df.loc[(df["Consolidated State for Po processing"].str.lower() == "kerala"),"PO rate after capping"]=0
    df.loc[df["NAME"].str.lower().str.contains("branch"),"PO rate after capping"]=0
    df.loc[(df["Remark "] == "RXLG cases"),"PO rate after capping"]=0
    df.loc[(df["PROCHANNEL"]=="inbt"),"PO rate after capping"]=0
    df.loc[(df["PROCHANNEL"]=="topup"),"PO rate after capping"]=0
    df.loc[(df["PROCHANNEL"]=="external"),"PO rate after capping"]=0
    df.loc[(df["CHANNELCODE"].str.lower().str.contains("alpa")),"PO rate after capping"]=0
    df.loc[(df["CHANNELCODE"].str.lower().str.contains("pa_")),"PO rate after capping"]=0
    df.loc[(df["Payout"]==0),"PO rate after capping"]=0
    df.loc[(df["Booster condition"]=="N"),"PO rate after capping"]=0
    
    df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==271161),"Remark03"]="DELHI-cases-271161"  
    df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==144536),"Remark03"]="DELHI-cases-144536"    
    df.loc[(df["Consolidated State for Po processing"].str.lower() == "delhi") & (df["DMABROKERCODE_y"]==178998),"Remark03"]="DELHI-cases-178998"     
    df.loc[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"]==231992) & (df["Irr roundup"]<=12.75),"Remark03"]="Irr_less_12.75"
    df.loc[(df["Consolidated State for Po processing"].str.lower() == "kerala"),"Remark03"]="Kerala_cases"
    df.loc[(df["Remark "] == "RXLG cases"),"Remark03"]="RXLG Cases"
    df.loc[(df["PROCHANNEL"]=="inbt"),"Remark03"]="inbt Cases"
    df.loc[(df["PROCHANNEL"]=="topup"),"Remark03"]="Topup Cases"
    df.loc[(df["PROCHANNEL"]=="external"),"Remark03"]="external cases"
    df.loc[(df["CHANNELCODE"].str.lower().str.contains("alpa")),"Remark03"]="alpa cases"
    df.loc[(df["CHANNELCODE"].str.lower().str.contains("pa_")),"Remark03"]="alpa cases"
    df.loc[(df["Payout"]==0),"Remark03"]="NIL Payout"
    df.loc[(df["Booster condition"]=="N"),"Remark03"]="Booster Condition"
    # df.loc[(df["Temp_State"]=="Delhi")&(df["DMABROKERCODE_y"]==271161),"Remark04"]=1
    # df.loc[(df["Temp_State"]=="Delhi")&(df["DMABROKERCODE_y"]==144536),"Remark04"]=1
    # df.loc[(df["Temp_State"]=="Delhi")&(df["DMABROKERCODE_y"]==178998),"Remark04"]=1
    # df.loc[(df["Remark "] == "RXLG cases"),"Remark04"]=1
    # df.loc[(df["PROCHANNEL"]=="inbt"),"Remark04"]=1
    # df.loc[(df["PROCHANNEL"]=="topup"),"Remark04"]=1
    # df.loc[(df["PROCHANNEL"]=="external"),"Remark04"]=1
    # brocker_code1=[250056,
    #                 309571,
    #                 217893,
    #                 301886,
    #                 299986,
    #                 284597,
    #                 303047,
    #                 269650,
    #                 299704,
    #                 301145,
    #                 300243,
    #                 180508,
    #                 300186,
    #                 301221,
    #                 303048,
    #                 299831,
    #                 301223,
    #                 300242,
    #                 158383,
    #                 255197,
    #                 315087,
    #                 306519,
    #                 183831,
    #                 283609,
    #                 311249,
    #                 ]
    # k="Hyderabad"
    # for i in brocker_code1:
    #         # for j in rate:
                
    #             df.loc[(df["Temp_State"]==k) & (df["DMABROKERCODE_y"]==i)& (~(df["PROCHANNEL"]=="sale purchase")),"Remark04"]=1
                # print(tad2,"kiran")
                # if (tad2>=broker_code11[i]*1000000):
                #     self.df_old_feb.loc[(self.df_old_feb["Temp_State"]==k) & (self.df_old_feb["DMABROKERCODE_y"]==i) & ((self.df_old_feb["PROCHANNEL"]=="sale purchase")),"PO rate after capping"]=0.01
    
    
    brocker_code=[266338,
                    266450,
                    269302,
                    275078,
                    274328,
                    286228,
                    302241,
                    230043,
                    302312,
                    311204,
                    ]
    df.loc[(df["DMABROKERCODE_x"].isin(brocker_code)),"Remark04"]=1
    df=df.loc[(df["Remark04"]==0)]
    
    df["Booster_Payout"]=0
    df["Booster_Payout"]=df["PO rate after capping"]*df["Final Net Loan"]
    def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["Booster_Payout"]=round_up(row["Booster_Payout"])
            return row        
    df=df.apply(lambda x:Round_off(x),axis=1) 
    
    return df
    
    
    
    