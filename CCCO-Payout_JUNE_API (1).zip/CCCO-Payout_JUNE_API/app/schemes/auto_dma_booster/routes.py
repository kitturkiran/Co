import os
import pandas as pd
from .data_calculation_old1 import Calculation
from .data_massaing_old import delhi_gird
from .data_calculation_new import Calculation1
from .summary_new import generateSummary
from .summary_old import generateSummary1
from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
from datetime import datetime
from fastapi.background import BackgroundTasks
from .summary_new import generateSummary
from .summary_old import generateSummary1
import shutil

Auto_Dma_booster=APIRouter()
@Auto_Dma_booster.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(df_new_jan: UploadFile,
                                   df_old_jan: UploadFile,
                                   df_new_feb: UploadFile,
                                   df_old_feb: UploadFile,
                                   tagging:UploadFile,
                                   start_date:str = Body(...),
                                   end_date:str = Body(...),
                                   bg_task: BackgroundTasks = None):
    
    
    df_new_jan = pd.read_excel(df_new_jan.file.read())
    df_old_jan = pd.read_excel(df_old_jan.file.read())
    df_new_feb = pd.read_excel(df_new_feb.file.read())
    df_old_feb = pd.read_excel(df_old_feb.file.read())
    tagging_file=tagging.file.read()
    
    tagging_new_df = pd.read_excel(tagging_file,sheet_name="New")
    tagging_used_df=pd.read_excel(tagging_file,sheet_name="Used")
    

    
    try:
        print("Manipulation")
        obj=Calculation(df_old_feb,df_old_jan,tagging_used_df,start_date,end_date)
        obj.execute()
        print("Hello")
        delhi_gird1=delhi_gird(obj.df_old_feb)
        print("Datamasssaging completed")
        obj1=Calculation1(df_new_jan,df_new_feb,tagging_new_df)
        obj1.execute1()
        print("Calculation completed")
        # obj1.df_jan_new.to_excel("booster_new.xlsx")
        
        new_car_summary=generateSummary(obj1.df_feb_new)
        old_car_summary=generateSummary1(delhi_gird1,new_car_summary)
        output_new_used=pd.concat([obj1.df_feb_new,delhi_gird1],ignore_index=True)
        output_new_used.rename(columns={"DMABROKERCODE_y":"DMABROKERCODE"},inplace=True)
        output_new_used["GST State From"]=output_new_used["GST State From"].str.lower()
        output_new_used["GST State To"]=output_new_used["GST State To"].str.lower()
        output_new_used.rename(columns={"Auto Type":"CAR TYPE"},inplace=True)
        output_new_used.rename(columns={"GST State From":"FROM LOCATION"},inplace=True)
        output_new_used.rename(columns={"GST State To":"TO LOCATION"},inplace=True)
        output_new_used=pd.merge(output_new_used,old_car_summary[["Ref No","DMABROKERCODE","FROM LOCATION","TO LOCATION","CAR TYPE"]],on=["DMABROKERCODE","FROM LOCATION","TO LOCATION","CAR TYPE"],how="left")
        
        





    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"Auto_Dma_boosteroutput_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        delhi_gird1.to_excel(writer, sheet_name="Used", index=False)
        obj1.df_feb_new.to_excel(writer, sheet_name="NEW", index=False)
        new_car_summary.to_excel(writer,sheet_name="newCar_summary",index=False)
        old_car_summary.to_excel(writer,sheet_name="oldCar_summary",index=False)
        output_new_used.to_excel(writer,sheet_name="summary__new_old_booster",index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)
    
@Auto_Dma_booster.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/Auto_dma_booster"
    destination_dir = f"./backup/AUTO_DMA_BOOSTER/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"   