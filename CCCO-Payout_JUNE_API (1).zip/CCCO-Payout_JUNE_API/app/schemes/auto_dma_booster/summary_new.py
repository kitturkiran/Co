import pandas as pd
import numpy as np
import math
# def round_up(n,decimals=0):

#     multiplier=10**decimals
#     return math.floor(n*multiplier + 0.5)/multiplier

def generateSummary(df:pd.DataFrame):
    # cf.rename(columns={"Code":"DMABROKERCODE_y"},inplace=True)
    # df=pd.merge(df,cf[["DMABROKERCODE_y","Debit Amount"]],on="DMABROKERCODE_y",how="left")
    # df["Debit Amount"].fillna(0, inplace=True)
    df["GST State From"]=df["GST State From"].str.lower()
    df["GST State To"]=df["GST State To"].str.lower()
    summary_df=pd.DataFrame(columns=["DMABROKERCODE","MONTH","NARRATION","CAR TYPE","DMA_NAME","AMTFIN","NETLOAN","TOTAL PAYOUT","ADVN","CNCL","GROSS PAYOUT","CGST@4.5","CGST_1@4.5","SGST@4.5","SGST_1@4.5","IGST@9","IGST_1@9","REVISEDGROSSPO","TDSRATE","TDSAmount","NetPayout","ADVN2","CNCL2","PDD","OTHERDEBITS","FINALPAYOUTS","REMARKS","TDSCODE","DMA VENDOR CODE","DMA PO BRANCH","DMA PAN","DMA ACCNO","DMA IFSC Code","DMA MODE OF PAYMENT","IBOX_IBOXID","IBOX_IBOXSTATUS","FROM LOCATION","TO LOCATION","RCM/Non RCM","Channel GST"])
    grf=df.groupby(["DMABROKERCODE_y","GST State From","GST State To"])
    for code, gdf in grf:
        temp = {}
        temp["DMABROKERCODE"]=[code[0]]
        temp["MONTH"]="APRIL -23"
        temp["NARRATION"]="AUTO DMA NEW CAR BOOSTER PO"
        # temp["Ref No"]=""
        temp["CAR TYPE"]="New Car"
        temp["DMA_NAME"]=[gdf["NAME"].iloc[0]]
        temp["AMTFIN"]=[gdf["AMTFIN"].sum()]
        temp["NETLOAN"]=[gdf["Final Net Loan"].sum()]
        temp["TOTAL PAYOUT"]=[gdf["Booster_Payout"].sum()]
        temp["ADVN"]=0.0
        temp["CNCL"]=0.0
        temp["GROSS PAYOUT"]=0.0
        temp["CGST@4.5"]=0.0
        temp["CGST_1@4.5"]=0.0
        temp["SGST@4.5"]=0.0
        temp["SGST_1@4.5"]=0.0
        temp["IGST@9"]=0.0
        temp["IGST_1@9"]=0.0
        temp["REVISEDGROSSPO"]=0.0
        temp["TDSRATE"]=5
        temp["TDSAmount"]=0.0
        temp["NetPayout"]=0.0
        temp["ADVN2"]=0.0
        temp["CNCL2"]=0.0
        temp["PDD"]=0.0
        temp["OTHERDEBITS"]=0.0
        temp["FINALPAYOUTS"]=0.0
        temp["REMARKS"]=""
        temp["TDSCODE"]=""
        temp["DMA VENDOR CODE"]=""
        temp["DMA PO BRANCH"]=[gdf["BRANCHNM"].iloc[0]]
        temp["DMA PAN"]=""
        temp["DMA ACCNO"]=""
        temp["DMA IFSC Code"]=""
        temp["DMA MODE OF PAYMENT"]=""
        temp["IBOX_IBOXID"]=""
        temp["IBOX_IBOXSTATUS"]=""
        temp["FROM LOCATION"]=[gdf["GST State From"].iloc[0]]
        temp["TO LOCATION"]=[gdf["GST State To"].iloc[0]]
        temp["RCM/Non RCM"]=""
        temp["Channel GST"]=""
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True) 
        # def round_up(n,decimals=0):

        #     multiplier=10**decimals
        #     return math.floor(n*multiplier + 0.5)/multiplier
    # summary_df.loc[(summary_df["DMABROKERCODE"].duplicated()==True),"CNCL"]=0
    summary_df["GROSS PAYOUT"]=summary_df["TOTAL PAYOUT"]-summary_df["ADVN"]-summary_df["CNCL"]
    summary_df["CGST@4.5"]=(((summary_df["GROSS PAYOUT"]*4.5)/118))
    summary_df["CGST_1@4.5"]=(((summary_df["GROSS PAYOUT"]*4.5)/118))
    summary_df["SGST@4.5"]=(((summary_df["GROSS PAYOUT"]*4.5)/118))
    summary_df["SGST_1@4.5"]=(((summary_df["GROSS PAYOUT"]*4.5)/118))
    summary_df["checking"]=np.where(summary_df["FROM LOCATION"].str.lower()==summary_df["TO LOCATION"].str.lower(),"True","False")
    summary_df.loc[summary_df["checking"]=="True","IGST@9"]=0
    summary_df.loc[summary_df["checking"]=="True","IGST_1@9"]=0
    summary_df.loc[summary_df["checking"]=="False","IGST@9"]=(((summary_df["GROSS PAYOUT"]*9.0)/118))
    summary_df.loc[summary_df["checking"]=="False","IGST_1@9"]=(((summary_df["GROSS PAYOUT"]*9.0)/118))
    summary_df.loc[summary_df["checking"]=="False","CGST@4.5"]=0
    summary_df.loc[summary_df["checking"]=="False","CGST_1@4.5"]=0
    summary_df.loc[summary_df["checking"]=="False","SGST@4.5"]=0
    summary_df.loc[summary_df["checking"]=="False","SGST_1@4.5"]=0
    summary_df["REVISEDGROSSPO"]=((summary_df["GROSS PAYOUT"])-(summary_df["CGST@4.5"]+summary_df["CGST_1@4.5"]+summary_df["SGST@4.5"]+summary_df["SGST_1@4.5"]+summary_df["IGST@9"]+summary_df["IGST_1@9"]))
    summary_df["TDSAmount"]=((summary_df["REVISEDGROSSPO"]*0.05))
    summary_df["NetPayout"]=(summary_df["REVISEDGROSSPO"]-summary_df["TDSAmount"])
    summary_df["FINALPAYOUTS"]=((summary_df["NetPayout"])-(summary_df["ADVN2"]+summary_df["CNCL2"]+summary_df["PDD"]+summary_df["OTHERDEBITS"]))
    def rounding(row:pd.DataFrame):
        def round_up(n,decimals=0):

            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
        row["CGST@4.5"]=round(row["CGST@4.5"],3)
        row["CGST@4.5"]=round_up(row["CGST@4.5"])
        row["CGST_1@4.5"]=round(row["CGST_1@4.5"],3)
        row["CGST_1@4.5"]=round_up(row["CGST_1@4.5"])
        row["SGST@4.5"]=round(row["SGST@4.5"],3)
        row["SGST@4.5"]=round_up(row["SGST@4.5"])
        row["SGST_1@4.5"]=round(row["SGST_1@4.5"],3)
        row["SGST_1@4.5"]=round_up(row["SGST_1@4.5"])
        row["IGST@9"]=round(row["IGST@9"],3)
        row["IGST@9"]=round_up(row["IGST@9"])
        row["IGST_1@9"]=round(row["IGST_1@9"],3)
        row["IGST_1@9"]=round_up(row["IGST_1@9"])
        row["REVISEDGROSSPO"]=round(row["REVISEDGROSSPO"],3)
        row["REVISEDGROSSPO"]=round_up(row["REVISEDGROSSPO"])
        row["TDSAmount"]=round(row["TDSAmount"],3)
        row["TDSAmount"]=round_up(row["TDSAmount"])
        row["NetPayout"]=round(row["NetPayout"],3)
        row["NetPayout"]=round_up(row["NetPayout"])
        row["FINALPAYOUTS"]=round(row["FINALPAYOUTS"],3)
        row["FINALPAYOUTS"]=round_up(row["FINALPAYOUTS"])
        return row
    summary_df = summary_df.apply(lambda x : rounding(x), axis=1)
    # summary_df.loc=summary_df[(summary_df["DMABROKERCODE"].duplicated()==True),"CNCL"]=0
    return summary_df
