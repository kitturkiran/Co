import pandas as pd
import numpy as np
from datetime import datetime
pd.options.mode.chained_assignment = None

class Massaging:
    def __init__(self,df:pd.DataFrame,rejection:pd.DataFrame,master_df:pd.DataFrame,tagging_df,start_date,end_date):
        self.df=df
        self.rejection=rejection
        self.mf=master_df
        self.tagging_df=tagging_df
        # self.cf=cf
        # self.df=pd.merge(self.df,self.cf[["AGREEMENTNO","ECLGS / NON ECLGS","Equipment","Category","Chassis / Body / CE","DSA/ Direct/ Connector"]],on="AGREEMENTNO",how='left')
        self.mf.rename(columns={"IPRO CODE":"OSP_CODE"},inplace=True)
        self.df=pd.merge(self.df,self.mf[["OSP_CODE","State"]],on="OSP_CODE",how="left")
        self.df=pd.merge(self.df,self.tagging_df[["OSP_CODE","State as per CB Product"]],on="OSP_CODE",how="left")
        self.df.loc[(self.df["State"].isnull()==True),"State"]=self.df["State as per CB Product"]
        self.start_date=start_date
        self.end_date=end_date
    def Category(self):
        
        Rejected_=self.df.loc[self.df["Category"].isnull()==True].copy()
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="blank Category"
        self.rejection=pd.concat([self.rejection,Rejected_],ignore_index=True)
        self.df.dropna(subset=["Category"],inplace=True)
        
    def CheackingDate(self):
        
        self.df["DISBURSALDATE"]=pd.to_datetime(self.df["DISBURSALDATE"],format="%d-%m-%Y")
        # self.start_date = datetime.strptime("1-5-2023", "%d-%m-%Y")
        # self.end_date = datetime.strptime("31-5-2023", "%d-%m-%Y")
        # self.df=self.df.loc[(self.df["DISBURSALDATE"]>=self.start_date) & (self.df["DISBURSALDATE"]<= self.end_date)]
        Rejected_=self.df.loc[(self.df["DISBURSALDATE"]<self.start_date) | (self.df["DISBURSALDATE"]> self.end_date)].copy()
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="OCR"
        self.rejection=pd.concat([self.rejection,Rejected_],ignore_index=True)
        self.df=self.df.loc[(self.df["DISBURSALDATE"]>=self.start_date) & (self.df["DISBURSALDATE"]<= self.end_date)]
       
    def CheckingDuplicate(self):
        self.df=self.df.loc[self.df["AGREEMENTNO"].duplicated()==False]
        
        Rejected_=self.df.loc[self.df["AGREEMENTNO"].duplicated()].copy()
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="DUP Cases"
        self.rejection=pd.concat([self.rejection,Rejected_],ignore_index=True)
        
    def NewAndRefinanace(self):
        Rejected_= self.df[(self.df["AGREEMENTNO"].str.startswith("LV") == True) & (self.df["AGREEMENTNO"].str.startswith("LQ") == True) & (self.df["AGREEMENTNO"].str.startswith(
            "UV") == True) & (self.df["AGREEMENTNO"].str.startswith("UQ") == True)].copy()
        Rejected_= pd.DataFrame(Rejected_)
        Rejected_["Remark"] = "Neither New nor Refinance"
        self.rejection = pd.concat([Rejected_, self.rejection], ignore_index=True)
        self.df = self.df[(self.df["AGREEMENTNO"].str.startswith("LD") == True) | (self.df["AGREEMENTNO"].str.startswith(
            "UD") == True)]
        self.df["NEW/REFINANCE_OP"]=""
        self.df.loc[(self.df["AGREEMENTNO"].str.startswith("LD")==True),"NEW/REFINANCE_OP"]="NEW"
        # self.df.loc[(self.df["AGREEMENTNO"].str.startswith("LQ")==True),"NEW/REFINANCE_OP"]="NEW"
        self.df.loc[(self.df["AGREEMENTNO"].str.startswith("UD")==True),"NEW/REFINANCE_OP"]="Refinance"
        # self.df.loc[(self.df["AGREEMENTNO"].str.startswith("UQ")==True),"NEW/REFINANCE_OP"]="Refinance"
        
    def RemovingstatusNotA(self):
        Rejected_=self.df[self.df["STATUS"] !="A"].copy()
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="STATUS OTHER THAN A"
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
        
        self.df=self.df[self.df["STATUS"] =="A"]
        print(self.df.shape[0])
        print(self.rejection.shape[0])
        
    def Connector(self):
        self.df.loc[self.df["DSA/ Direct/ Connector"].str.lower().str.contains("connector"),"Connector"]="Connector"
    
    def Branchname(self):
 
        Rejected_=self.df[~(((self.df["DMA_NAME"].str.lower().str.contains("direct"))| (self.df["DMA_NAME"].str.lower().str.contains("branch"))))].copy()
        # Rejected_=Rejected_[~(Rejected_["DSA/ Direct/ Connector"].str.lower().str.contains("connector"))]
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="OTHER THAN BRANCH AND DIRECT"
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=False)
        # temp=self.df[self.df["DSA/ Direct/ Connector"].str.lower().str.contains("connector")]
        temp1=self.df[(self.df["DMA_NAME"].str.lower().str.contains("direct"))| (self.df["DMA_NAME"].str.lower().str.contains("branch") )]
        lst1=temp1
        self.df=temp1
   
    def Bodycases(self):
        self.df["Chassis / Body / CE"]=""
        self.df["top up cases"]=""
        self.df.loc[self.df["MODELNAME"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"
        self.df.loc[self.df["MAKE"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"

        self.df.loc[self.df["ASSET_CATG"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("topup plus")==True,"top up cases"]="Top up plus"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("topup")==True,"Chassis / Body / CE"]="Top up"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("top up")==True,"Chassis / Body / CE"]="Top up"
        
        Rejected_=self.df[(self.df["Chassis / Body / CE"].str.lower().str.contains("body") == True)]
       
        Rejected_=pd.DataFrame(Rejected_)
       
        Rejected_["Remark"]="BODY/TOP UP CASES"
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=False)
        
        self.df=self.df[~(self.df["Chassis / Body / CE"].str.lower().str.contains("body",na=False))]
       
        
        
    def RemovingTop_cases(self):
        Rejected_=self.df[(self.df["Chassis / Body / CE"].str.lower().str.contains("top up") == True)]
       
        Rejected_=pd.DataFrame(Rejected_)
        
        Rejected_["Remark"]="BODY/TOP UP CASES"
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=False)
        
        self.df=self.df[~(self.df["Chassis / Body / CE"].str.lower().str.contains("top up"))]
    
    
    def testcaseInDme(self):
        Rejected_=self.df[(self.df["DME_NAME"].str.lower().str.contains("test") == True)].copy()
        Rejected_=pd.DataFrame(Rejected_)
        
        Rejected_["Remark"]="CASES CONTAINS Test for construction equiment or Test for commercial vehicle"
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=False)
      
        self.df=self.df[~(self.df["DME_NAME"].str.lower().str.contains("test",na=False))]
        # temp=self.df[self.df["DSA/ Direct/ Connector"].str.lower().str.contains("connector")].copy()
        # temp1=self.df[(~self.df["DME_NAME"].str.lower().str.contains("test",na=False))]
        # lst1=[temp,temp1]
        # self.df=pd.concat((lst1),ignore_index=True)
        
    def ospcode(self):
        self.mf.dropna(subset=["OSP_CODE"],axis=0, inplace=True)
        osp = self.mf["OSP_CODE"].str.lower().tolist()
        
     
            
    
        
        Rejected_=self.df[~(self.df["OSP_CODE"].str.lower().isin(osp))].copy()
        Rejected_=pd.DataFrame(Rejected_)
      
        Rejected_["Remark"]="NOT PRESENT PRESENT IN ATTENDANCE SHEET"
   
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
       
        self.df=self.df[self.df["OSP_CODE"].str.lower().isin(osp)]
       
        print(self.df.shape[0])
        print(self.rejection.shape[0])
    def strategiccase(self):
        
        
        self.df["Strategic/ Retail/ FTU"]="Retail"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("strategic"),"Strategic/ Retail/ FTU"]="Strategic"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("str"),"Strategic/ Retail/ FTU"]="Strategic"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("stg"),"Strategic/ Retail/ FTU"]="Strategic"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("ftu"),"Strategic/ Retail/ FTU"]="FTU"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("ftb"),"Strategic/ Retail/ FTU"]="FTU"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("first time user"),"Strategic/ Retail/ FTU"]="FTU"
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("first time buyer"),"Strategic/ Retail/ FTU"]="FTU"
    
        
        
        # Rejected_=self.df.loc[(self.df["Strategic/ Retail/ FTU"].str.lower()=="strategic") & (self.df["State"].str.lower().str.contains("assam")==False) & (self.df["State"].str.lower().str.contains("bihar")==False)& (self.df["State"].str.lower().str.contains("jharkhand")==False)].copy()
        
        # Rejected_=pd.DataFrame(Rejected_)
        # Rejected_["Remark"]= "Contains Strategic and States not consider in consolidate"
        # self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
     
        # temp=self.df.loc[((self.df["Strategic/ Retail/ FTU"].str.lower()==("strategic")) & ((self.df["State"].str.lower().str.contains("assam")==True) | (self.df["State"].str.lower().str.contains("bihar")==True) | (self.df["State"].str.lower().str.contains("jharkhand")==True)))].copy()
        # temp1=self.df.loc[(self.df["Strategic/ Retail/ FTU"].str.lower()==("retail"))].copy()
        # temp2=self.df.loc[(self.df["Strategic/ Retail/ FTU"].str.lower()==("ftu"))].copy()
        
        # lst=[temp,temp1,temp2]
        # self.df=pd.concat((lst),ignore_index=True)
        # self.rejection=self.rejection.loc[self.rejection["AGREEMENTNO"].duplicated()==False]
        print(self.df.shape[0],"kiran.l")
        print(self.rejection.shape[0],"kiran.l")        
        
    def ECLGS(self):
        self.df.loc[self.df["ECLGS / NON ECLGS"].str.lower().str.contains("eclgs")==True,"ECLGS"]="ECLGS cases"
       
        
    def Topup(self):
        self.df.loc[self.df["PROMOTIONDESC"].str.lower().str.contains("top up")==True,"Top up"]="Top up"
        
    
    def ECLGSPromotion(self):
        Rejected_=self.df[(self.df["PROMOTIONDESC"].str.lower().str.contains("eclgs"))]
        Rejected_=pd.DataFrame(Rejected_)
        Rejected_["Remark"]="ECLGS Cases."
        self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
        self.df=self.df[~(self.df["PROMOTIONDESC"].str.lower().str.contains("eclgs"))]
        
        
    def novation(self):
        for col in self.df.columns:
            Rejected_=self.df[self.df[col].astype(str).str.lower().str.contains("novation")].copy()
            Rejected_=pd.DataFrame(Rejected_)
            Rejected_["Remark"]="Novation Cases."
            self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
        
    def rbk(self):
        self.df.loc[self.df['FILENO'].str.lower() == "rbk", ["Exclude Remark"]] = ["File No CONTAIN RBK"]    
        
               
    def deathNabard(self):
        for col in self.df.columns:
            self.df.loc[(self.df[col].astype(str).str.lower() == "death") | (
                self.df[col].astype(str).str.lower() == "nabard"), ["Exclude Remark"]] = "CONTAINS Death & Nabard"
    
        self.rejection=self.rejection.loc[self.rejection["AGREEMENTNO"].duplicated()==False]
        print(self.rejection.shape[0],"kiran")
        print(self.df.shape[0],"kiran")
    def execute(self):
        
        # self.Category()
        self.CheackingDate()
        self.CheckingDuplicate()
        self.NewAndRefinanace()
        self.RemovingstatusNotA()
        #self.Connector()
        self.Branchname()
        self.testcaseInDme()
        #self.RemovingTop_cases()
        self.Bodycases()
        self.RemovingTop_cases()
        self.ospcode()
        self.strategiccase()
        # self.ECLGS()
        # self.Connector()
        # self.Topup()
        # self.ECLGSPromotion()
        #self.novation()
        self.rbk()
        self.deathNabard()  
      






