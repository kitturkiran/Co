import pandas as pd

class Summary:
    def __init__(self,df:pd.DataFrame):
        self.df=df
        
    def summary(self):
           

        self.df=self.df[["OSP_CODE","AMTFIN","DME_NAME","State","PO_ME_AMOUNT","Additional Units PO",'Total PO LAN Wise']].copy()
        self.df=pd.DataFrame(self.df)
        self.df["Count"]=self.df.groupby(["OSP_CODE"])["OSP_CODE"].transform("count")
        self.df["Amtfin"]=self.df.groupby(["OSP_CODE"])["AMTFIN"].transform(sum)
        # self.df["Units Payout"]=self.df.groupby(["OSP_CODE"])["Units PO"].transform(sum)
        # self.df["Used PO"]=self.df.groupby(["OSP_CODE"])["Additional Units PO"].transform(sum)
        # self.df["IRR Addition Payout"]=self.df.groupby(["OSP_CODE"])["IRR PO"].transform(sum)
        # self.df["STRATEGIC PO"]=self.df.groupby(["OSP_CODE"])["StrategicPO"].transform(sum)
        # self.df["CONNECTOR PO"]=self.df.groupby(["OSP_CODE"])["Connector PO"].transform(sum)
        # self.df["Additional Units PO"]=self.df.groupby(["OSP_CODE"])["Additional Units PO"].transform(sum)
        self.df["PO_ME_AMOUNT"]=self.df.groupby(["OSP_CODE"])["PO_ME_AMOUNT"].transform(sum)
        self.df["Additional Units PO"]=self.df.groupby(["OSP_CODE"])["Additional Units PO"].transform(sum)
        self.df["Total_PO"]=self.df.groupby(["OSP_CODE"])["Total PO LAN Wise"].transform(sum)
        self.df["Capping"]=50000
        self.df["PO_Capped_AMT"]=self.df.groupby(["OSP_CODE"])["Total PO LAN Wise"].transform(sum)
        
        self.df.loc[self.df["PO_Capped_AMT"]>50000,"PO_Capped_AMT"]=50000
        self.df=self.df.drop(["count","AMTFIN","Units PO","Additional Units PO","IRR PO","Top Up PO","Equipment PO","Connector PO","StrategicPO","Total PO LAN Wise"],axis=1)
        self.df=self.df.loc[self.df["OSP_CODE"].duplicated()==False]
        # Total Payable
    def execute(self):
        self.summary()