import pandas as pd
import math



class Calculation:
    def __init__(self,df:pd.DataFrame,sf:pd.DataFrame):
        self.df=df
        self.sf=sf
        # self.with_connector=None
        # self.without_connector=None
        
    def Add_structure(self):

        self.df["Units PO"]=0.0
        self.df["Additional Units PO"]=0.0
        self.df["IRR PO"]=0.0
        self.df["Top Up PO"]=0.0
        self.df["Equipment PO"]=0.0
        self.df["Connector PO"]=0.0
        self.df["StrategicPO"]=0.0
        self.df["Total PO LAN Wise"]=0.0
        self.df["count"]=0
        
    def unit_wise_payout(self):
        
            

    
        temp=self.df.loc[(self.df["Strategic/ Retail/ FTU"]!="Strategic")]
        temp1=self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Strategic")]
        temp=pd.DataFrame(temp)
        temp1=pd.DataFrame(temp1)
        
        temp["count"]=temp.groupby(["OSP_CODE"])["OSP_CODE"].transform("count")
       
        temp.loc[(temp["count"]==3) & (self.df["Connector"]!="Connector") &(self.df["Category"]=="SCV"),'Units PO']=3000
        temp.loc[(temp["count"]==3) & (self.df["Connector"]!="Connector") &(self.df["Category"]!="SCV"),'Units PO']=4000
        temp.loc[(temp["count"]==4) & (self.df["Connector"]!="Connector")& (self.df["Category"]=="SCV"),'Units PO']=4000
        temp.loc[(temp["count"]==5)&(self.df["Connector"]!="Connector") &(self.df["Category"]=="SCV"),'Units PO']=4000
        temp.loc[(temp["count"]==4)&(self.df["Connector"]!="Connector") &(self.df["Category"]!="SCV"),'Units PO']=5000
        temp.loc[(temp["count"]==5)&(self.df["Connector"]!="Connector") & (self.df["Category"]!="SCV"),'Units PO']=5000
        temp.loc[(temp["count"]>5)&(self.df["Connector"]!="Connector") & (self.df["Category"]=="SCV"),'Units PO']=5000
        temp.loc[(temp["count"]>5)&(self.df["Connector"]!="Connector") & (self.df["Category"]!="SCV"),'Units PO']=6000
       
        self.df=pd.concat([temp,temp1],ignore_index=True)
        
        
    def irr_payout(self):
        self.df=self.df.round({"IRR":2})
        #Retail- SCV Unit -NEW cases
        self.df.loc[(self.df["IRR"].between(11.35,12.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]=="SCV") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=13.35) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="SCV"),'IRR PO']=2000
        #ftu- SCV Unit -NEW cases
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="SCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(13.35,14.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=14.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="NEW")&(self.df["Connector"]!="Connector")&(self.df["Category"]=="SCV"),'IRR PO']=2000
        #Retail- SCV Unit -OLD cases
        self.df.loc[(self.df["IRR"].between(11.35,12.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") &(self.df["Category"]=="SCV") &(self.df["NEW/REFINANCE_OP"]=="Refinance"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") &(self.df["NEW/REFINANCE_OP"]=="Refinance") &(self.df["Category"]=="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=13.35) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="Refinance") &(self.df["Connector"]!="Connector") &(self.df["Category"]=="SCV"),'IRR PO']=2000
        #FTU- SCV Unit -OLD cases
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Category"]=="SCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(13.35,14.35,inclusive="left")) & (self.df["Connector"]!="Connector") &(self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Category"]=="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=14.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="SCV"),'IRR PO']=2000
        #Retail NON SCV -NEW cases
        self.df.loc[(self.df["IRR"].between(9.50,10.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]!="SCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(10.35,11.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]!="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=11.35) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW")  & (self.df["Category"]!="SCV"),'IRR PO']=2000
        #FTU NON SCV -NEW cases
        self.df.loc[(self.df["IRR"].between(11.35,12.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Category"]!="SCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Category"]!="SCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=13.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Category"]!="SCV") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW"),'IRR PO']=2000
        #Retail CE -old cases
        self.df.loc[(self.df["IRR"].between(9.50,10.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") &  (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]=="CE"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(10.35,11.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]=="CE"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=11.35) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE"),'IRR PO']=2000
        #FTU CE -OLD CASES
        self.df.loc[(self.df["IRR"].between(11.35,12.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance")  & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=13.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Category"]=="CE")  & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance"),'IRR PO']=2000
        
        #Retail CE-asset -old cases
        self.df.loc[(self.df["IRR"].between(9.50,10.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") &  (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]=="CE Asset"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(10.35,11.35,inclusive="left")) & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Category"]=="CE Asset"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=11.35) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE Asset"),'IRR PO']=2000
        #FTU CE-asset -OLD CASES
        self.df.loc[(self.df["IRR"].between(11.35,12.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance")  & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE Asset"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="CE Asset"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=13.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Category"]=="CE Asset")  & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance"),'IRR PO']=2000
        #FTU HCV-OLD Cases
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="HCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(13.35,14.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="HCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=14.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance")  & (self.df["Connector"]!="Connector") & (self.df["Category"]=="HCV"),'IRR PO']=2000
        #FTU LCV -OLD cases
        self.df.loc[(self.df["IRR"].between(12.35,13.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU")  & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="LCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(13.35,14.35,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="FTU")  & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="LCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=14.35) & (self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="LCV"),'IRR PO']=2000
        #Retail HCV -OLD cases.
        self.df.loc[(self.df["IRR"].between(11.35,11.85,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail")  & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="HCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(11.85,12.85,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="HCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=12.85) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Category"]=="HCV"),'IRR PO']=2000
        #Restail LCV -OLD cases.
        self.df.loc[(self.df["IRR"].between(11.35,11.85,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="LCV"),'IRR PO']=1000
        self.df.loc[(self.df["IRR"].between(11.85,12.85,inclusive="left")) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]!="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Category"]=="LCV"),'IRR PO']=1500
        self.df.loc[(self.df["IRR"]>=12.85) & (self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["NEW/REFINANCE_OP"]=="Refinance")  & (self.df["Connector"]!="Connector") & (self.df["Category"]=="LCV"),'IRR PO']=2000
    
    def ConnectorPO(self):
       
        
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="SCV") & (self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="LCV") &(self.df["State"].str.lower()!="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="ICV")&(self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="HCV")& (self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=3000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="CE")& (self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=3000
        
     
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="SCV") & (self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="LCV") &(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="ICV")&(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="HCV")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="CE")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower() =="tamil nadu"),'Connector PO']=2000
        
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="SCV") & (self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="LCV") &(self.df["State"].str.lower()!="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="ICV")&(self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="HCV")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=3000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="CE")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower() !="tamil nadu"),'Connector PO']=3000
        
     
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="SCV") & (self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="LCV") &(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="ICV")&(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="HCV")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower()=="tamil nadu"),'Connector PO']=2000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["Category"]=="CE")&(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  &(self.df["State"].str.lower() =="tamil nadu"),'Connector PO']=2000
        
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["IRR"]<12.35) ,'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="FTU") & (self.df["Connector"]=="Connector") & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["IRR"]<11.35)  ,'Connector PO']=1000
        
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["NEW/REFINANCE_OP"]=="Refinance") &(self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["IRR"]<11.10) ,'Connector PO']=1000
        self.df.loc[(self.df["Strategic/ Retail/ FTU"]=="Retail") & (self.df["Connector"]=="Connector") & (self.df["Equipment"]!="BHL")&(self.df["Equipment"]!="Mobile Crane") & (self.df["Equipment"]!="Excavator")  & (self.df["NEW/REFINANCE_OP"]=="NEW") & (self.df["IRR"]<10.10)  ,'Connector PO']=1000
        
        
        
        
        


    def top_up_plus(self):
        
        self.df.loc[(self.df["top up cases"]=="Top up plus") & (self.df["TENURE"]>=18) & (self.df["AMTFIN"]>200000) ,"Top Up PO"]=1000
        
        self.df.loc[(self.df["top up cases"]=="Top up plus") & (self.df["TENURE"]>=18) & (self.df["AMTFIN"]>200000) ,"Top Up PO"]=2000
        self.df.loc[(self.df["top up cases"]=="Top up plus") & (self.df["TENURE"]>=18) & (self.df["AMTFIN"]>200000) ,"Top Up PO"]=3000
      
        print(self.df.shape[0])
    
    def Equipment(self):
        
        
        temp5=self.df.loc[(self.df["Connector"]!="Connector")]
        temp6=self.df.loc[(self.df["Connector"]=="Connector")]
        temp5.loc[temp5["Equipment"].str.lower().str.contains("mobile crane") & (temp5["IRR"]>=10) & (temp5["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=3000
        temp5.loc[temp5["Equipment"].str.lower().str.contains("bhl") & (temp5["IRR"]>=10) & (temp5["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=5000
        temp5.loc[temp5["Equipment"].str.lower().str.contains("excavator") & (temp5["IRR"]>=10) &  (temp5["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=7000 
        temp5.loc[temp5["Equipment"].str.lower().str.contains("mobile crane") & (temp5["IRR"]>=11.35) & (temp5["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=3000
        temp5.loc[temp5["Equipment"].str.lower().str.contains("bhl") & (temp5["IRR"]>=11.35) & (temp5["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=5000
        temp5.loc[temp5["Equipment"].str.lower().str.contains("excavator") & (temp5["IRR"]>=11.35) & (temp5["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=7000 
        temp6["count_Equipment"]=temp6.groupby(["OSP_CODE","Equipment"])["OSP_CODE"].transform("count")
        #mobile crane -Retail old.
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        #mobile crane-Retail NEW
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        #BHl -Retail old.
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        #BHL -Retail NEw.
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        #Excavator -Retail old
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=10.75) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=10.75) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=10.75) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        #Excavator -Retail NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=2000
        
        
        #mobile crane -Ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        #mobile crane -Ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        #bhl -Ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        #bhl -ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        #Excavator -ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        #Excavator -ftu NEw
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(1,3,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"].between(4,7,inclusive="both")) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=1500
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["count_Equipment"]>=8) & (temp6["IRR"]>=11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU") ,"Equipment PO"]=2000
        

        
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["IRR"]<10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW")&(temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["IRR"]<11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail") ,"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["IRR"]<10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["IRR"]<11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["IRR"]<11.10) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=1000 
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["IRR"]<10.10) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="Retail"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["IRR"]<11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("mobile crane") & (temp6["IRR"]<12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["IRR"]<11.35) & (temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("bhl") & (temp6["IRR"]<12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["IRR"]<11.35) &(temp6["NEW/REFINANCE_OP"]=="NEW") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000 
        temp6.loc[temp6["Equipment"].str.lower().str.contains("excavator") & (temp6["IRR"]<12.35) & (temp6["NEW/REFINANCE_OP"]=="Refinance") & (temp6["Strategic/ Retail/ FTU"]=="FTU"),"Equipment PO"]=1000 
        
        
        
        
         
        self.df=pd.concat([temp5,temp6],ignore_index=True)
        
        
         

    def Wirr(self):
      
        self.df["Santion_IRR"]=self.df["AMTFIN"]*self.df["IRR"]
        self.df["sum of amtfin based on osp code"]=self.df.groupby(["OSP_CODE"])["AMTFIN"].transform(sum)
        self.df["Santion based on OPS_code"]=self.df.groupby(["OSP_CODE"])["Santion_IRR"].transform(sum)
       
         
        self.df["WIRR"]=(self.df["Santion based on OPS_code"])/(self.df["sum of amtfin based on osp code"])
        
        # self.df.loc[(self.df["WIRR"]>=9.85)&(self.df["NEW/REFINANCE_OP"]=="Refinance") &  (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="Retail"),"Additional Units PO"]=1000
        # self.df.loc[(self.df["WIRR"]>=11.35)&(self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="FTU"),"Additional Units PO"]=1000
        

    def Strategic(self):
        #self.df.loc[self.df["Strategic/ Retail/ FTU"]=="Strategic","StrategicPO"]=1000
        grp=self.df.groupby(["OSP_CODE","Strategic/ Retail/ FTU"])
        data66=pd.DataFrame()
        for code,grf in grp:
            k=grp.head()
            #self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
            data66=pd.concat([k,data66],ignore_index=True)
        data66=data66.loc[data66["AGREEMENTNO"].duplicated()==False]
        l=data66["AGREEMENTNO"]
        df1=self.df[self.df["AGREEMENTNO"].isin(l)]
        df1.loc[df1["Strategic/ Retail/ FTU"]=="Strategic","StrategicPO"]=1000
        df2=self.df[~(self.df["AGREEMENTNO"].isin(l))]
        print(df1.shape[0])
        print(df2.shape[0])
        self.df=pd.concat([df1,df2],ignore_index=True)
        print(self.df.shape[0])
        # print(l)
        
          
    def Total_PO_LAN_Wise(self):
       
        self.df["Total PO LAN Wise"]=self.df["Units PO"] + self.df["Additional Units PO"] + self.df["IRR PO"]+ self.df["Top Up PO"] + self.df["Equipment PO"] + self.df["Connector PO"] + self.df["StrategicPO"]
       
    
    def Removing_columns(self):
        
        self.df=self.df.drop(["Santion_IRR","sum of amtfin based on osp code","Santion based on OPS_code","top up cases","ECLGS","Connector","Top up","Exclude Remark"],axis=1)
        self.df1=self.df
        self.df1=self.df1.drop(["count","WIRR","count_Equipment"],axis=1)
    def split(self):
        self.with_connector=self.df[self.df["DSA/ Direct/ Connector"].str.lower()=="connector"]
        self.without_connector=self.df[self.df["DSA/ Direct/ Connector"].str.lower()!="connector"]
        
    def ME_Calculation(self):
        self.df["sum_of_AMTFIN"]=0
        self.df["Net_loan"]=self.df["AMTFIN"]-self.df["ADVANCE_EMI"]
        # self.df["sum_of_AMTFIN"]=0
        self.df["PO_ME_RATE"]=0.0
        self.df["PO_ME_AMOUNT"]=0.0
        self.df["Additional Units PO"]=0.0
        
        self.df["sum_of_AMTFIN"]=self.df.groupby(["OSP_CODE"])["AMTFIN"].transform(sum)
        # self.df["Net_loan"]=self.df["AMTFIN"]-self.df["ADVANCE_EMI"]
        self.df.loc[(self.df["sum_of_AMTFIN"].between(1500000,7500000,inclusive="left")),"PO_ME_RATE"]=0.0020
        self.df.loc[(self.df["sum_of_AMTFIN"].between(7500000,10000000,inclusive="both")),"PO_ME_RATE"]=0.0015
        self.df.loc[(self.df["sum_of_AMTFIN"]>10000000),"PO_ME_RATE"]=0.0010 
        self.df["PO_ME_AMOUNT"]=self.df["PO_ME_RATE"]*self.df["Net_loan"]
        def Round_off(row:pd.DataFrame):
                    
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            row["PO_ME_AMOUNT"]=round(row["PO_ME_AMOUNT"],3)        
            row["PO_ME_AMOUNT"]=round_up(row["PO_ME_AMOUNT"])
            return row        
        self.df=self.df.apply(lambda x:Round_off(x),axis=1)  
        self.df.loc[(self.df["WIRR"]>=9.75)&(self.df["NEW/REFINANCE_OP"]=="Refinance"),"Additional Units PO"]=1000
        # self.df["PO_ME_AMOUNT_total"]=0
        # self.df["Additional Units PO_total"]=0
        self.df["PO_ME_AMOUNT_total"]=self.df["PO_ME_AMOUNT"]+self.df["Additional Units PO"]
        self.df["PO_ME_AMOUNT_total1"]=self.df.groupby(["OSP_CODE"])["PO_ME_AMOUNT"].transform(sum)
        self.df["Additional Units PO_total"]=self.df.groupby(["OSP_CODE"])["Additional Units PO"].transform(sum)
        self.df["Count_"]=self.df.groupby(["OSP_CODE"])["OSP_CODE"].transform("count")
        # self.df.loc[(self.df["WIRR"]>=11.35)&(self.df["NEW/REFINANCE_OP"]=="Refinance") & (self.df["Connector"]!="Connector") & (self.df["Strategic/ Retail/ FTU"]=="FTU"),"Additional Units PO"]=1000        
        #merging with CV Counsellor summary
        
        osp_sf=self.sf["OSP_CODE"].str.lower().tolist()
        osp_df=self.df["OSP_CODE"].str.lower().tolist()
        osp=self.df.loc[self.df["OSP_CODE"].str.lower().isin(osp_sf)==False]["OSP_CODE"]
        
        osp=list(set(osp))
        columns1=self.sf.columns
        
        # print(osp)
        df=pd.DataFrame({"OSP_CODE":osp})
        print(len(osp))
        # print(df)Amtfin
        df=pd.merge(self.df,df,on="OSP_CODE")
        df.rename(columns={"AMTFIN":"Amtfin"},inplace=True)
        df=df[["OSP_CODE","DME_NAME","State","Amtfin"]]
        # df1=self.df.loc[(self.df["OSP_CODE"].isin(osp))]
        # print(df1)
        # print(df1["OSP_CODE"])
        
        #     print(i)
            
        #     df["OSP_CODE"]=i
        #     print(df)
        self.sf=pd.concat([self.sf,df],ignore_index=True)
        print(self.sf["OSP_CODE"])
        print(self.df["OSP_CODE"])
        #     print(self.sf["OSP_CODE"].str.lower().isin([i])==True)
        # self.sf=pd.concat([self.sf,df],ignore_index=True)
        self.sf=pd.merge(self.sf,self.df[["OSP_CODE","PO_ME_AMOUNT_total1","Additional Units PO_total","Count_","sum_of_AMTFIN"]],on="OSP_CODE",how="left")
        # self.sf["AMTFIN"]=self.df.groupby(["OSP_CODE"])["AMTFIN"].transform(sum)
        self.sf["sum_of_AMTFIN"].fillna(0,inplace=True)
        self.sf["Amtfin"]=self.sf["sum_of_AMTFIN"]+self.sf["Amtfin"]
        self.sf["PO_ME_AMOUNT_total1"].fillna(0,inplace=True)
        self.sf["Additional Units PO_total"].fillna(0,inplace=True)
        self.sf["Count_"].fillna(0,inplace=True)
        self.sf["Count"].fillna(0,inplace=True)
        self.sf["Units Payout"].fillna(0,inplace=True)
        self.sf["Used PO"].fillna(0,inplace=True)
        self.sf["IRR Addition Payout"].fillna(0,inplace=True)
        self.sf["STRATEGIC PO"].fillna(0,inplace=True)
        self.sf["CONNECTOR PO"].fillna(0,inplace=True)
        self.sf["BHL Excavator Mobile Crane"].fillna(0,inplace=True)
        # self.sf["CONNECTOR PO"].fillna(0,inplace=True)
        self.sf["TOP UP Plus"].fillna(0,inplace=True)
        self.sf["Capping"].fillna(30000,inplace=True)
        self.sf["Total_PO"].fillna(0,inplace=True)
        self.sf["PO_ME_AMOUNT_total"]=self.sf["PO_ME_AMOUNT_total1"]+self.sf["Additional Units PO_total"]
        self.sf["Total_PO"]=self.sf["Total_PO"]+self.sf["PO_ME_AMOUNT_total"]
        self.sf["Count"]=self.sf["Count"]+self.sf["Count_"]
        self.sf.loc[self.sf["Total_PO"]>30000,"PO_Capped_AMT"]=30000
        self.sf.loc[self.sf["Total_PO"]<=30000,"PO_Capped_AMT"]=self.sf["Total_PO"]
        self.sf=self.sf.loc[self.sf["OSP_CODE"].duplicated()==False]   
        self.sf.drop(columns=["Additional Units PO_total","Count_","PO_ME_AMOUNT_total1"],inplace=True)
        self.df.drop(columns=["Additional Units PO_total","PO_ME_AMOUNT_total1","Count_"],inplace=True)
        self.sf.loc[(self.sf["OSP_CODE"].isin(osp),"Amtfin")]=self.sf["sum_of_AMTFIN"]
    def execution(self):
        # self.Add_structure()
        # self.unit_wise_payout()
        # self.irr_payout()
        # self.top_up_plus()
        # #self.Equipment()
        self.Wirr()
        # #self.Equipment()
        # self.ConnectorPO()
        # self.Strategic()
        # self.Equipment()
        # #self.unit_wise_payout()
        # self.Total_PO_LAN_Wise()
        
        # self.Removing_columns()
        self.ME_Calculation()
        # self.split()

