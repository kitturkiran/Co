
import os
import pandas as pd
from data_calculation import Calculation
from data_massaging import Massaging
from data_summary import Summary


dma_df = pd.read_excel(r"C:\Users\kiran.k\Downloads\schema _scource code1 _may\CV consellor\scheme _4_ Medical\Input_File\Dump.xlsx")
master_mf=pd.read_excel(r"C:\Users\kiran.k\Downloads\schema _scource code1 _may\CV consellor\scheme _4\Input_File\Retainer Sheet unseclore.xlsx")
tagging_file=pd.read_excel(r"C:\Users\kiran.k\Downloads\schema _scource code1 _may\CV consellor\scheme _4_ Medical\Input_File\Input Sheet.xlsx")
summary_df=pd.read_excel(r"C:\Users\kiran.k\Downloads\schema _scource code1 _may\CV consellor\scheme _4_ Medical\Input_File\CV Consellor_SUMMARY_MAY2023.xlsx")

rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

obj1=Massaging(dma_df, rejected_df,master_mf,tagging_file)
obj1.execute()

obj2 =Calculation(obj1.df,summary_df)
obj2.execution()
obj3=Summary(obj2.df)
obj3.execute()
# obj4=Summary(obj2.with_connector)
# obj4.execute()

obj2.df.to_excel("output_CV Consellor_ME_FINAL_MAY2023.xlsx",index=False)
obj2.sf.to_excel("output_CV Consellor_ME_SUMMARY_FINAL_MAY2023.xlsx",index=False)
# obj2.with_connector.to_excel("output2_scheme_4_november_with_connector.xlsx")
obj1.rejection.to_excel("rejection_output_CV Consellor_ME_FINAL_MAY2023.xlsx",index=False)
obj3.df.to_excel("Summary_CV Consellor_ME_FINAL_MAY2023.xlsx",index=False)
# obj4.df.to_excel("Summary sheet1_with_connector.xlsx")



