import pandas as pd
import numpy as np
import math

class Summary:
    def __init__(self,dma_df:pd.DataFrame):
        self.dma_df=dma_df
        
    def structure(self):

        self.dma_df["CGST@4.5"]=0
        self.dma_df["CGST_1@4.5"]=0
        self.dma_df["SGST@4.5"]=0
        self.dma_df["SGST_1@4.5"]=0
        self.dma_df["IGST@9"]=0
        self.dma_df["IGST_1@9"]=0
        self.dma_df["REVISEDGROSSPO"]=0
        self.dma_df["TDSRATE"]=5.0
        self.dma_df["TDSAmount"]=0
        self.dma_df["NetPayout"]=0
        self.dma_df["ADVN2"]=0
        self.dma_df["CNCL2"]=0
        self.dma_df["PDD"]=0
        self.dma_df["OTHERDEBITS"]=0
        self.dma_df["FINALPAYOUTS"]=0
        self.dma_df["REMARKS"]=0
        self.dma_df["TDSCODE"]=0
        self.dma_df["DMA PAN"]=0
        self.dma_df["DMA ACCNO"]=0
        self.dma_df["DMA IFSC Code"]=0
        self.dma_df["DMA MODE OF PAYMENT"]=0
        self.dma_df["IBOX_IBOXID"]=0
        self.dma_df["IBOX_IBOXSTATUS"]=0
        self.dma_df["RCM/Non RCM"]=0
        self.dma_df["Channel GST"]=0
        
        
        
        
            
    def summary(self):
        # self.dma_df["FROM STATE"]=self.dma_df["FROM STATE"].str.lower()
        # self.dma_df["TO STATE"]=self.dma_df["TO STATE"].str.lower()
        # self.dma_df["TOTAL PAYOUT"]=round(self.dma_df["PO_AMT1"]-self.dma_df["CNCL"],3)
        # self.dma_df.loc[self.dma_df["NAME"].str.lower().str.startswith("branch"),"DMABROKERCODE"]=308404
        # self.dma_df["Sum of AMTFIN"]=self.dma_df.groupby(["DMABROKERCODE"])["AMTFIN"].transform(sum)
        grp=self.dma_df.groupby(["DMABROKERCODE","SAP CODE"])
        # for code,gdf in gdf:
        summary_df = pd.DataFrame(columns=["BROKERID","SAP CODE","DMA NAME","DMA/Counsellor/Connector Name","Narration","Month","Payout","Recovery","TOTAL PAYOUT","CGST@4.5","CGST_1@4.5","SGST@4.5","SGST_1@4.5","IGST@9","IGST_1@9","REVISEDGROSSPO","TDSRATE","TDSAmount","NetPayout","ADVN2","CNCL2","PDD","OTHERDEBITS","FINALPAYOUTS","Remarks","TAX Code","Branch","pan","ACCOUNT No","IFSC CODE","Mode","FROM STATE","RCM / NON RCM","VENDOR GST"]) 
        for code,gdf in grp:                           
            temp={}
            # temp["Ref No"]=""
            # temp["SAP CODE"]=[gdf["SAP CODE"].iloc[0]]
            temp["BROKERID"]=[gdf["DMABROKERCODE"].iloc[0]]
            temp["SAP CODE"]=[gdf["SAP CODE"].iloc[0]]
            temp["DMA NAME"]=[gdf["NAME"].iloc[0]]
            temp["DMA/Counsellor/Connector Name"]=[gdf["DMA/Counsellor/Connector Name"].iloc[0]]
            temp["Narration"]=[gdf["Narration"].iloc[0]]
            temp["Month"]=[gdf["Month"].iloc[0]]
            temp["Payout"]=[gdf["PO"].sum()]
            temp["Recovery"]=0.0
            temp["TOTAL PAYOUT"]=[gdf["PO"].sum()]
            temp["CGST@4.5"]=0.0
            temp["CGST_1@4.5"]=0.0
            temp["SGST@4.5"]=0.0
            temp["SGST_1@4.5"]=0.0
            temp["IGST@9"]=0.0
            temp["IGST_1@9"]=0.0
            temp["REVISEDGROSSPO"]=0.0
            temp["TDSRATE"]=5.0
            temp["TDSAmount"]=0.0
            temp["NetPayout"]=0.0
            temp["ADVN2"]=0
            temp["CNCL2"]=0
            temp["PDD"]=0
            temp["OTHERDEBITS"]=0
            temp["FINALPAYOUTS"]=0.0
            temp["Remarks"]=0
            temp["TAX Code"]=0
            temp["Branch"]=[gdf["BRANCHNM"].iloc[0]]
            temp["pan"]=0
            temp["ACCOUNT No"]=0
            temp["IFSC CODE"]=0
            temp["Mode"]=0
            temp["FROM STATE"]=[gdf["STATE_x"].iloc[0]]
            # temp["TO STATE"]=[gdf["TO STATE"].iloc[0]] 
            # temp["T/F"]=0 
            temp["RCM / NON RCM"]=0
            temp["VENDOR GST"]=0

         
        
        
        
            temp = pd.DataFrame(temp)
            summary_df = pd.concat([summary_df,temp], ignore_index=True)  
        print(summary_df.shape[0])  
        # self.dma_df["TOTAL PAYOUT"]=self.dma_df.groupby(["SAP CODE_1"])["TOTAL PAYOUT"].transform(sum)
        # self.dma_df["CNCL"]=0
        # self.dma_df["TOTAL PAYOUT"]=self.dma_df.groupby(["DMABROKERCODE"])["TOTAL PAYOUT"].transform(sum)
        # self.structure()
        # summary_df["Payout 80%"]=round(summary_df["final gross po"]*0.8)
        # summary_df["CGST@4.5"]=round(((summary_df["Payout 80%"]*4.5)/118),3)0
        summary_df["CGST@4.5"]=((summary_df["TOTAL PAYOUT"]*4.5)/118)
        summary_df["CGST_1@4.5"]=((summary_df["TOTAL PAYOUT"]*4.5)/118)
        summary_df["SGST@4.5"]=((summary_df["TOTAL PAYOUT"]*4.5)/118)
        summary_df["SGST_1@4.5"]=((summary_df["TOTAL PAYOUT"]*4.5)/118)
        
        # summary_df["T/F"]=np.where(summary_df["FROM STATE"].str.lower()==summary_df["TO STATE"].str.lower(),"True","False")
        # summary_df.loc[summary_df["T/F"]=="True","IGST@9"]=0
        # summary_df.loc[summary_df["T/F"]=="True","IGST_1@9"]=0
        # summary_df.loc[summary_df["T/F"]=="False","IGST@9"]=((summary_df["TOTAL PAYOUT"]*9.0)/118)
        # summary_df.loc[summary_df["T/F"]=="False","IGST_1@9"]=((summary_df["TOTAL PAYOUT"]*9.0)/118)
        # summary_df.loc[summary_df["T/F"]=="False","CGST@4.5"]=0
        # summary_df.loc[summary_df["T/F"]=="False","CGST_1@4.5"]=0
        # summary_df.loc[summary_df["T/F"]=="False","SGST@4.5"]=0
        # summary_df.loc[summary_df["T/F"]=="False","SGST_1@4.5"]=0
        def Round_off(row:pd.DataFrame):
                    
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            row["TOTAL PAYOUT"]=round_up(row["TOTAL PAYOUT"])
            row["CGST@4.5"]=round_up(row["CGST@4.5"])
            row["CGST_1@4.5"]=round_up(row["CGST_1@4.5"])
            row["SGST@4.5"]=round_up(row["SGST@4.5"])
            row["SGST_1@4.5"]=round_up(row["SGST_1@4.5"])
            row["IGST@9"]=round_up(row["IGST@9"])
            row["IGST_1@9"]=round_up(row["IGST_1@9"])

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)                
        summary_df["REVISEDGROSSPO"]=(summary_df["TOTAL PAYOUT"]-(summary_df["CGST@4.5"]+summary_df["CGST_1@4.5"]+summary_df["SGST@4.5"]+summary_df["SGST_1@4.5"]+summary_df["IGST@9"]+summary_df["IGST_1@9"]))
        summary_df["TDSAmount"]=summary_df["REVISEDGROSSPO"]*0.05
        def Round_off(row:pd.DataFrame):
                    
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
                    
            row["TDSAmount"]=round_up(row["TDSAmount"])
            return row        
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)                
        summary_df["NetPayout"]=(summary_df["REVISEDGROSSPO"]-summary_df["TDSAmount"])
        summary_df["FINALPAYOUTS"]=(summary_df["NetPayout"]-(summary_df["ADVN2"]+summary_df["CNCL2"]+summary_df["PDD"]+summary_df["OTHERDEBITS"]))
                # self.dma_df.rename(columns={"NAME":"DMA NAME"}, inplace=True)
                # self.dma_df=self.dma_df.drop(columns=["AGREEMENTID","AGREEMENTNO","AGREEMENTDATE","DISB_DATE","DISBURSALAMOUNT","DISB_AMT","AMTFIN","PRETAXIRR","LESSEEID","TENURE","EMI","FILENO","MODELNO","MANUFACTURERDESC","DEALERNAME","ADVANCEINSTL","PROCESSINGFEE","MFR_SUBVENTION_IN","MFR_SUBVENTION_PAID","DEALER_SUBVENTION","DMA_SUBVENTION","PROMOTIONDESC","MARGINMONEY","ADVANCE_EMI","EMPLOYERNAME","STATUS","MAKE","V_ASSET_CATG","PRODUCTFLAG","BRANCH_CODE","SCHEMECODE","PROMOTIONSCHEME","EFFRATE","MODELCODE","SUBMODELCODE","GROSS_LTV","NET_LTV","FINALSOURCE","FIRSTSOURCE","CUSTCATG","DMA_SUBVENTION_NOT_DED","EMPTYPE","EMPTYPE","STATE","CHANNELCODE","MANUFACTURERID","MANUFACTURERID","INFAVOUROF","CHEQUESTATUS","OSP_CODE","DME_NAME","DUMMY","CUSTOMER_NAME","Category","PO"])
                # self.dma_df=self.dma_df[~(self.dma_df["DMA NAME"].str.lower().str.startswith("branch"))]
                # self.dma_df=self.dma_df.loc[self.dma_df["DMABROKERCODE"].duplicated()==False]
                # self.dma_df=self.dma_df.loc[self.dma_df["DMABROKERCODE"].duplicated()==False]
                # self.dma_df["Remarks"]=0
                # self.dma_df["TAX Code"]=0
                # self.dma_df["pan"]=0
                # self.dma_df["ACCOUNT No"]=0
                # self.dma_df["IFSC CODE"]=0
                # self.dma_df["Mode"]=0
                # self.dma_df["RCM / NON RCM"]=0
                # self.dma_df["VENDOR GST"]=0
                # self.dma_df["Recovery"]=0
        # summary_df["TOTAL PAYOUT_1"]=summary_df["TOTAL PAYOUT"]-summary_df["Recovery"]
        # l=[]
        # for i in range(len(summary_df)):
        #     b=str(i)
        #     a="TWSE012300"+b
        #     l.append(a)
        # summary_df["Ref No"]=l
        # print(summary_df)
        # self.dma_df=summary_df
        summary_df.insert(0,"Ref No",range(3001,3001+summary_df.shape[0]))
        summary_df["Ref No"]=summary_df["Ref No"].apply(lambda x:"TWSE042"+str(x))
        self.dma_df=summary_df
        
        return self.dma_df
                
                
                # temp=self.dma_df[["Ref No","SAP CODE_1","DMABROKERCODE","DMA NAME","Narration","Month","TOTAL PAYOUT","Recovery","TOTAL PAYOUT_1","CGST@4.5","CGST_1@4.5","SGST@4.5","SGST_1@4.5","IGST@9","IGST_1@9","REVISEDGROSSPO","TDSRATE","TDSAmount","NetPayout","ADVN2","CNCL2","PDD","OTHERDEBITS","FINALPAYOUTS","Remarks","TAX Code","BRANCHNM","pan","ACCOUNT No","IFSC CODE","Mode","FROM STATE","TO STATE","T/F","RCM / NON RCM","VENDOR GST"]]
                # self.dma_df=temp
                # self.dma_df.rename(columns={"SAP CODE_1":"SAP CODE"},inplace=True)
                # self.dma_df.rename(columns={"DMABROKERCODE":"BROKERID"},inplace=True)
                # self.dma_df.rename(columns={"TOTAL PAYOUT":"Payout"},inplace=True)
                # self.dma_df.rename(columns={"TOTAL PAYOUT_1":"TOTAL PAYOUT"},inplace=True)
                # self.dma_df.rename(columns={"BRANCHNM":"Branch"},inplace=True)
                # self.dma_df.rename(columns={"T/F":"T/F"},inplace=True)
                # self.dma_df=self.dma_df.loc[self.dma_df["BROKERID"].duplicated()==False]

        
        
        
        
    def excute(self):
        
        self.summary()