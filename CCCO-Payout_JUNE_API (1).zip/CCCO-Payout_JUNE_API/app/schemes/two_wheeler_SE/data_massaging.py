from datetime import datetime
import pandas as pd

class DataMassaging:
    def __init__(self, dma_df:pd.DataFrame, rejected_df:pd.DataFrame, pfdc_df:pd.DataFrame, structure_po_df:pd.DataFrame,SE_confirment:pd.DataFrame,SE_confirment_1:pd.DataFrame,start_date,end_date):
        self.rejection_df = rejected_df
        self.dma_df = dma_df
        self.pfdc_df = pfdc_df
        self.structure_po_df = structure_po_df
        self.SE_confirment=SE_confirment
        self.SE_confirment_1=SE_confirment_1
        self.start_date=start_date
        self.end_date=end_date
        
        
        
    def RemoveStatusOtherThanA(self):
        
        temp = self.dma_df[self.dma_df["STATUS"] != 'A'].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Status Other Than A"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["STATUS"] == 'A']
    

    def RemoveBasedOnLan(self):
        temp = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LT") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("UT") == False)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Neither LT nor UT"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LT") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UT") == True)]
        
        
    def RemoveBranchAndDirect(self):
        # temp=self.dma_df[(self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola"))]
        # temp1=self.dma_df[~self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola")].copy()
        # temp1= temp1[temp1["NAME"].str.lower().str.contains("branch") | temp1["NAME"].str.lower().str.contains("direct")].copy()
        # temp = pd.DataFrame(temp)
        # temp1 = pd.DataFrame(temp1)
        # temp1["REMARK"] = "NAME with value BRANCH / Direct"
        # self.rejection_df = pd.concat([self.rejection_df, temp1], ignore_index=True)
        # temp3=self.dma_df[(self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola"))]
        # temp4=self.dma_df[~self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola")].copy()
        # temp4 = temp4[~(temp4["NAME"].str.lower().str.contains("branch") | temp4["NAME"].str.lower().str.contains("direct"))]
        # self.dma_df=pd.concat([temp3,temp4],ignore_index=True)
        
        temp= self.dma_df[self.dma_df["NAME"].str.lower().str.contains("branch") | self.dma_df["NAME"].str.lower().str.contains("direct")].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "NAME with value BRANCH / Direct"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["NAME"].str.lower().str.contains("branch") | self.dma_df["NAME"].str.lower().str.contains("direct"))]
        
        
        
        
        
    def RemoveAlternateChannel(self):
        temp = self.dma_df[self.dma_df["NAME"].str.lower().str.contains("alternate channel")].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "NAME with value Alternate Channel"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["NAME"].str.lower().str.contains("alternate channel"))]
        
        
    def RemoveTenure(self):
        temp = self.dma_df[(self.dma_df["TENURE"] < 18)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Tenure less than 18"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["TENURE"] < 18)]
       
            
    def RemoveOutsidePeriod(self):
        self.dma_df["DISB_DATE"] = pd.to_datetime(self.dma_df["DISB_DATE"],"%m/%d/%Y")
        # self.start_date = datetime.strptime("1-4-2023", "%d-%m-%Y")
        # self.end_date = datetime.strptime("30-4-2023", "%d-%m-%Y")
        temp = self.dma_df[((self.dma_df["DISB_DATE"] > self.end_date) == True) | ((self.dma_df["DISB_DATE"] < self.start_date) == True)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Outside the Period of Calculation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[((self.dma_df["DISB_DATE"] <= self.end_date) == True) & ((self.dma_df["DISB_DATE"] >= self.start_date) == True)]
  
        
    def MergePFDC(self):
        self.pfdc_df.rename(columns={"LAN_NO":"AGREEMENTNO"}, inplace=True)
        self.dma_df = pd.merge(self.dma_df, self.pfdc_df, on="AGREEMENTNO",how="left")
        

    def RemoveBasedOnDMABrokerCode(self):
        self.structure_po_df.dropna(subset=["DMA Code"],axis=0, inplace=True)
        dmaCodes = self.structure_po_df["DMA Code"].tolist()
        temp89=self.dma_df[~self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola")]
        temp = temp89[~temp89["DMABROKERCODE"].isin(dmaCodes)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "DMA Code not found in Structure PO"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        temp44=self.dma_df[(self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola"))]
        temp55=self.dma_df[~self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola")]
        temp77 = temp55[temp55["DMABROKERCODE"].isin(dmaCodes)]
        self.dma_df=pd.concat([temp44,temp77],ignore_index=True)
        
        
    def RoundingPercentage(self):
        # self.dma_df["PF+DC%"] = self.dma_df["PF+DC%"] * 100
        # self.dma_df["PF+DC%"] = self.dma_df["PF+DC%"].round(decimals=2)
        self.dma_df["PRETAXIRR"] = self.dma_df["PRETAXIRR"].round(decimals=2)
        

    def AdditionalColumn(self):
        # self.dma_df["PO%"] = 0.0
        # self.dma_df["PO_AMT"] = 0.0
        self.dma_df["REMARK_FLAG"] = False
        
    
    def CalculateNetLoanAndTotalApplicableDisbursement(self):
        self.dma_df["NET_LOAN"] = self.dma_df["AMTFIN"] - self.dma_df["ADVANCE_EMI"]
        self.dma_df["SUM_OF_AMTFIN"] = 0
        grp = self.dma_df.groupby("DMABROKERCODE")
        
        for code, grp_df in grp:
            self.dma_df.loc[self.dma_df["DMABROKERCODE"] == code, "SUM_OF_AMTFIN"] = grp_df["NET_LOAN"].sum()
            
    def merging(self):
        self.structure_po_df.rename(columns={" DMA ID/ CODE":"DMABROKERCODE"}, inplace=True)
        # self.structure_po_df.rename(columns={"STATE":"STATE1"}, inplace=True)
        self.structure_po_df
        self.dma_df=pd.merge(self.dma_df,self.structure_po_df,on="DMABROKERCODE")
        self.dma_df=self.dma_df[(self.dma_df["AGREEMENTNO"].duplicated()==False)]
        print(self.dma_df.shape[0])
                
    def MergingStructurePO(self):
        broker_code = self.structure_po_df["DMABROKERCODE"].tolist()
        
     
            
    
        
        Rejected_=self.dma_df[~(self.dma_df["DMABROKERCODE"].isin(broker_code))].copy()
        Rejected_=pd.DataFrame(Rejected_)
      
        Rejected_["REMARK"]="Broker code not present in SE Sheet"
   
        self.rejection_df=pd.concat([Rejected_,self.rejection_df],ignore_index=True)
       
        self.dma_df=self.dma_df[self.dma_df["DMABROKERCODE"].isin(broker_code)]
        
        self.dma_df=pd.merge(self.dma_df,self.structure_po_df[["DMABROKERCODE","SAP CODE"]],on="DMABROKERCODE")
        self.dma_df.rename(columns={"SAP CODE":"SAP CODE_1"},inplace=True)
        self.dma_df=pd.merge(self.dma_df,self.SE_confirment[["AGREEMENTNO","SAP CODE"]],on="AGREEMENTNO",how="left")
        self.dma_df.loc[(self.dma_df["SAP CODE"].isnull()==False),"remark_2"]=0
        self.dma_df.loc[(self.dma_df["remark_2"]==0),"SAP CODE_1"]=self.dma_df["SAP CODE"]
        self.dma_df.rename(columns={"SAP CODE":"SAP CODE_2"},inplace=True)
        # self.dma_df=pd.merge(self.dma_df,self.SE_confirment_1[["AGREEMENTNO","SAP CODE"]],on="AGREEMENTNO",how="left")
        # self.dma_df.loc[(self.dma_df["SAP CODE"].isnull()==False),"remark_2"]=0
        # self.dma_df.loc[(self.dma_df["remark_2"]==0),"SAP CODE_1"]=self.dma_df["SAP CODE"]
        # self.dma_df.rename(columns={"SAP CODE":"SAP CODE_3"},inplace=True)
        self.dma_df.rename(columns={"SAP CODE_1":"SAP CODE"},inplace=True)
        self.dma_df.loc[(self.dma_df["SAP CODE"].isnull()==True),"SAP CODE"]=self.dma_df["SAP CODE_2"]
        # self.dma_df=self.dma_df[(self.dma_df["AGREEMENTNO"].duplicated()==False)]
        # print(self.dma_df.shape[0])      
        # self.structure_po_df.rename(columns={" DMA ID/ CODE":"DMABROKERCODE"}, inplace=True)
        # print(self.structure_po_df["DMABROKERCODE"])
        # self.dma_df = pd.merge(self.dma_df,self.structure_po_df[["DMABROKERCODE","SAP CODE"]], on="DMABROKERCODE",how="left")
        # self.dma_df = pd.merge(self.dma_df,self.SE_confirment[["AGREEMENTNO","SAP CODE_1"]], on="AGREEMENTNO",how="left")
        self.dma_df = pd.merge(self.dma_df,self.SE_confirment_1[["AGREEMENTNO","REMARK"]], on="AGREEMENTNO",how="left")
        # self.dma_df.loc[(self.dma_df["SAP CODE_1"].isnull()==True),"remark_2"]=0
        # self.dma_df.loc[(self.dma_df["remark_2"]==0),"SAP CODE_1"]=self.dma_df["SAP CODE"]
        # self.structure_po_df.rename(columns={"SAP CODE":"SAP CODE_1"},inplace=True)
        print(self.dma_df["SAP CODE"])
        self.dma_df = pd.merge(self.dma_df,self.structure_po_df[["SAP CODE","DMA/Counsellor/Connector Name","SE Incentive Structure","Remark","STATE"]], on="SAP CODE",how="left")
        self.pfdc_df.rename(columns={"DMA Code":"DMABROKERCODE"}, inplace=True)
        # self.dma_df = pd.merge(self.dma_df,self.pfdc_df[["DMABROKERCODE","STATE1"]], on="DMABROKERCODE",how="left")
        # self.dma_df.rename(columns={"STATE":"STATE1"},inplace=True)
        self.dma_df=self.dma_df[(self.dma_df["AGREEMENTNO"].duplicated()==False)]
    def SAP_code(self):
        temp = self.dma_df[self.dma_df["REMARK"]=="HOLD"].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "rejected as per icic confirmation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df=self.dma_df.loc[(self.dma_df["REMARK"]!="HOLD")]
        
        temp = self.dma_df[self.dma_df["SE Incentive Structure"]=="HOLD"].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Kept on HOLD"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df=self.dma_df[self.dma_df["SE Incentive Structure"]!="HOLD"]
        
        temp = self.dma_df[self.dma_df["SAP CODE"]=="HOLD"].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Kept on HOLD"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df=self.dma_df[self.dma_df["SAP CODE"]!="HOLD"]
        # self.dma_df.dropna(subset=["SAP CODE"],inplace=True)
        
        # temp = self.dma_df[self.dma_df["Remark_1"]=="Not consider for payout"].copy()
        # temp = pd.DataFrame(temp)
        # temp["REMARK"] = "Not consider for payout"
        # self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        # self.dma_df=self.dma_df[self.dma_df["Remark_1"]!="Not consider for payout"]
        # self.dma_df=self.dma_df.loc[self.dma_df["AGREEMENTNO"].duplicated()==False]
        # self.rejection_df=self.rejection_df.loc[self.rejection_df["AGREEMENTNO"].duplicated()==False]

        

     
    def Month(self):
        self.dma_df["Month"]="APRIL-23"
        self.dma_df["Narration"]="TW SE PO APRIL-23"
        self.dma_df["CNCL"]=0
        
        
    def execute(self):
        self.RemoveStatusOtherThanA()
        self.RemoveBasedOnLan()
        self.RemoveBranchAndDirect()
        self.RemoveAlternateChannel()
        self.RemoveTenure()
        self.RemoveOutsidePeriod()
        # self.MergePFDC()
        # self.RemoveBasedOnDMABrokerCode()
        self.RoundingPercentage()
        self.AdditionalColumn()
        self.Month()
        self.CalculateNetLoanAndTotalApplicableDisbursement()
        # self.merging()
        self.MergingStructurePO()
        self.SAP_code()


