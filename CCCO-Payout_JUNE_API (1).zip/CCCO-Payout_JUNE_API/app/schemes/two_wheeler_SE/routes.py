import pandas as pd
from .data_calculation import Calculation
from .data_massaging import DataMassaging
from .data_summary import Summary
from fastapi import APIRouter,UploadFile,HTTPException,Body,Depends
from fastapi.responses import FileResponse
from fastapi.background import BackgroundTasks
from ...auth.auth_bearer import JWTBearer
import os
from datetime import datetime
import shutil

Tw_Weeler_SE=APIRouter()

@Tw_Weeler_SE.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
def calculation(dma_Df:UploadFile,Structure_file:UploadFile,SIP_CON:UploadFile,SIP_Bro:UploadFile,
                start_date:str=Body(...),end_date:str=Body(...),bg_task: BackgroundTasks = None):
    
    dma_df=pd.read_excel(dma_Df.file.read())
    Structure_df=Structure_file.file.read()
    structure_po_df=pd.read_excel(Structure_df,sheet_name="SE") 
    pf_dc_df=pd.read_excel(Structure_df,sheet_name="PO")
    SE_confirment=pd.read_excel(SIP_CON.file.read())
    SE_confirment_1=pd.read_excel(SIP_Bro.file.read())
    

    
    
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        structure_po_df.rename(columns={" DMA ID/ CODE":"DMABROKERCODE"}, inplace=True)
        obj = DataMassaging(dma_df, rejected_df, pf_dc_df, structure_po_df,SE_confirment,SE_confirment_1,start_date,end_date)
        obj.execute()
        
        obj1= Calculation(obj.dma_df)
        obj1.Excute()
        
        obj2=Summary(obj1.dma_df)
        obj2.excute()
        
        Summary_df1=obj2.dma_df
        Summary_df1=Summary_df1[["Ref No","BROKERID","SAP CODE","DMA/Counsellor/Connector Name","Month","TOTAL PAYOUT"]]
        obj1.dma_df.rename(columns={"DMABROKERCODE":"BROKERID"},inplace=True)
        summary_ref=pd.merge(obj1.dma_df,obj2.dma_df[["Ref No","BROKERID","SAP CODE"]],on=["BROKERID","SAP CODE"],how="left")
    except KeyError as missing_key:
        raise HTTPException(status_code=402,detail={"Missing Key": f"{missing_key.args[0]}"})
            
    except:
        raise HTTPException (status_code=500,detail="internal server error")
        
    file_name = f"TW_SE_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        obj1.dma_df.to_excel(writer,sheet_name="Tw_wheeler_SE",index=False)
        # obj.rejection_df.to_excel(writer,sheet_name="Rejected_file",index=False)
        obj2.dma_df.to_excel(writer,sheet_name="summary",index=False)
        Summary_df1.to_excel(writer,sheet_name="summary_pdf",index=False)
        summary_ref.to_excel(writer,sheet_name="summary_with_ref",index=False)
    bg_task.add_task(os.remove,file_path)
    return FileResponse(file_path, filename=file_name, background=bg_task)


@Tw_Weeler_SE.post("/save-scheme",dependencies=[Depends(JWTBearer())])
def save_scheme():
    today=datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/two_wheeler_SE"
    destination_dir = f"./backup/TWO_WHEELER_SE/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"   
    
    
    
        
        
        
        
        
    
    
    
     