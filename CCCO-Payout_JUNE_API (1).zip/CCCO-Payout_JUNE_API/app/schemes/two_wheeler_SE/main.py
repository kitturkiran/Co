import os

import pandas as pd
from data_massaging import DataMassaging
from data_calculation import Calculation
from data_summary import Summary
from datetime import datetime


dma_df = pd.read_excel(r"D:\schema _scource code1\TW DUMP\two _wheeler scheme 5_April SE\Input_File\TW Dump.xlsx")
structure_po_df = pd.read_excel(r"D:\schema _scource code1\TW DUMP\two _wheeler scheme 5_April SE\Input_File\TW DMA & SE Structure.xlsx", sheet_name="SE")
pf_dc_df = pd.read_excel(r"D:\schema _scource code1\TW DUMP\two _wheeler scheme 5_April SE\Input_File\TW DMA & SE Structure.xlsx", sheet_name="PO")
SE_confirment=pd.read_excel(r"D:\schema _scource code1\TW DUMP\two _wheeler scheme 5_April SE\Input_File\SE CASEWISE ALLOCATION Unseclore.xlsx")
SE_confirment_1=pd.read_excel(r"D:\schema _scource code1\TW DUMP\two _wheeler scheme 5_April SE\Input_File\SE LAN Confimation for Broker Id 258170 unseclore.xlsx")
# start_date=datetime.strptime("01-02-2023","%d-%m-%Y")
# end_date=datetime.strptime("28-02-2023","%d-%m-%Y")
rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
structure_po_df.rename(columns={" DMA ID/ CODE":"DMABROKERCODE"}, inplace=True)
obj = DataMassaging(dma_df, rejected_df, pf_dc_df, structure_po_df,SE_confirment,SE_confirment_1)
obj.execute()
# obj.dma_df.to_excel("output_sap.xlsx") 

obj1= Calculation(obj.dma_df)
obj1.Excute()
# obj.dma_df.to_excel("output_scheme5_final_SE.xlsx")
obj.rejection_df.to_excel("TW SE_REJECTED_FEB23.xlsx")
# obj2=Summary(obj1.dma_df)
# obj2.excute()
obj1.dma_df.to_excel("TW SE_OUTPUT_APRIL23.xlsx",index=False)
# obj.rejection_df.to_excel("rejection_scheme5_3.xlsx")
obj2=Summary(obj1.dma_df)
obj2.excute()
obj2.dma_df.to_excel("TW SE_SUMMARY_APRIL23.xlsx",index = False)
Summary_df1=obj2.dma_df
Summary_df1=Summary_df1[["Ref No","BROKERID","SAP CODE","DMA/Counsellor/Connector Name","Month","TOTAL PAYOUT"]]
Summary_df1.to_excel("TW SE_SUMMARY_PDF_APRIL23.xlsx",index = False)
obj1.dma_df.rename(columns={"DMABROKERCODE":"BROKERID"},inplace=True)
summary_ref=pd.merge(obj1.dma_df,obj2.dma_df[["Ref No","BROKERID","SAP CODE"]],on=["BROKERID","SAP CODE"],how="left")
summary_ref.to_excel("TW SE DMA_SUMMARY_REF_APRIL2023.xlsx",index=False)




# obj = DataMassaging(dma_df, rejected_df, pf_dc_df, structure_po_df)

# obj.execute()
# obj.dma_df.to_excel("output_TW.xlsx")
# obj.rejection_df.to_excel("REJECTION_TW.xlsx")