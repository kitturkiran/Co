import os

import pandas as pd
from data_massaging import DataMassaging
from data_calculation import Calculation
from data_summary import Summary
from datetime import datetime



dma_df = pd.read_excel(r"D:\schema _scource code1 _may\TW DUMP\two _wheeler scheme\Input_File\Dump.xlsx")
structure_po_df = pd.read_excel(r"D:\schema _scource code1 _may\TW DUMP\two _wheeler scheme\Input_File\Structure May 23 Unseclore.xlsx", sheet_name="PO")
pf_dc_df = pd.read_excel(r"D:\schema _scource code1 _may\TW DUMP\two _wheeler scheme\Input_File\PF+DC.xlsx", sheet_name="PF+DC", usecols=["LAN_NO", "PF+DC%", "PF+DC"])
cncl=pd.read_excel(r"D:\schema _scource code1 _may\TW DUMP\two _wheeler scheme\Input_File\Advance + Case Cancellation.xlsx",sheet_name="Sheet1")
start_date=datetime.strptime("01-05-2023","%d-%m-%Y")
end_date=datetime.strptime("31-05-2023","%d-%m-%Y")
rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

obj = DataMassaging(dma_df, rejected_df, pf_dc_df, structure_po_df,start_date,end_date)
obj.execute()

obj1= Calculation(obj.dma_df,cncl)
obj1.Excute()
obj1.dma_df1.to_excel("TW DMA_OUTPUT_MAY2023.xlsx",index=False)
obj.rejection_df.to_excel("TW DMA_REJECTED_MAY2023.xlsx",index=False)
obj2=Summary(obj1.dma_df)
obj2.excute()
# obj1.dma_df.to_excel("output_scheme5_16.xlsx")
# obj.rejection_df.to_excel("rejection_scheme5_3.xlsx")

obj2.dma_df.to_excel("TW DMA_SUMMARY_MAY2023.xlsx",index=False)
SUMMARY_PDF=obj2.dma_df
SUMMARY_PDF=SUMMARY_PDF[["Ref No","DMABROKERCODE","DMA NAME","Month","TOTAL PAYOUT"]]
SUMMARY_PDF.to_excel("TW DMA_SUMMARY_PDF_MAY2023.xlsx",index=False)
summary_ref=pd.merge(obj1.dma_df1,obj2.dma_df[["Ref No","DMABROKERCODE"]],on="DMABROKERCODE",how="left")
summary_ref.to_excel("TW DMA_SUMMARY_REF_MAY2023.xlsx",index=False)








