import pandas as pd
import numpy as np
import math

class Summary:
    def __init__(self,dma_df:pd.DataFrame):
        self.dma_df=dma_df
        
    def structure(self):

        self.dma_df["CGST@4.5"]=0
        self.dma_df["CGST_1@4.5"]=0
        self.dma_df["SGST@4.5"]=0
        self.dma_df["SGST_1@4.5"]=0
        self.dma_df["IGST@9"]=0
        self.dma_df["IGST_1@9"]=0
        self.dma_df["REVISEDGROSSPO"]=0
        self.dma_df["TDSRATE"]=5.0
        self.dma_df["TDSAmount"]=0
        self.dma_df["NetPayout"]=0
        self.dma_df["ADVN2"]=0
        self.dma_df["CNCL2"]=0
        self.dma_df["PDD"]=0
        self.dma_df["OTHERDEBITS"]=0
        self.dma_df["FINALPAYOUTS"]=0
        self.dma_df["REMARKS"]=0
        self.dma_df["TDSCODE"]=0
        self.dma_df["DMA PAN"]=0
        self.dma_df["DMA ACCNO"]=0
        self.dma_df["DMA IFSC Code"]=0
        self.dma_df["DMA MODE OF PAYMENT"]=0
        self.dma_df["IBOX_IBOXID"]=0
        self.dma_df["IBOX_IBOXSTATUS"]=0
        self.dma_df["RCM/Non RCM"]=0
        self.dma_df["Channel GST"]=0
        self.dma_df["DMA VENDOR CODE"]=""
        
        
        
        
            
    def summary(self):

        self.dma_df["Sum of AMTFIN"]=self.dma_df.groupby(["DMABROKERCODE"])["AMTFIN"].transform(sum)
        self.dma_df["TOTAL PAYOUT"]=self.dma_df.groupby(["DMABROKERCODE"])["PO_AMT1"].transform(sum)
        self.dma_df["Amount"]=self.dma_df.groupby(["DMABROKERCODE"])["Amount"].transform(sum)
        # self.dma_df["CNCL"]=0
        self.dma_df["GROSS PAYOUT"]=self.dma_df.groupby(["DMABROKERCODE"])["GROSS PAYOUT"].transform(sum)
        self.structure()
        
        self.dma_df["CGST@4.5"]=round((self.dma_df["GROSS PAYOUT"]*4.5)/118,3)
        self.dma_df["CGST_1@4.5"]=round((self.dma_df["GROSS PAYOUT"]*4.5)/118,3)
        self.dma_df["SGST@4.5"]=round((self.dma_df["GROSS PAYOUT"]*4.5)/118,3)
        self.dma_df["SGST_1@4.5"]=round((self.dma_df["GROSS PAYOUT"]*4.5)/118,3)

        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            row["GROSS PAYOUT"]=round_up(row["GROSS PAYOUT"])
            row["CGST@4.5"]=round_up(row["CGST@4.5"])
            row["CGST_1@4.5"]=round_up(row["CGST_1@4.5"])
            row["SGST@4.5"]=round_up(row["SGST@4.5"])
            row["SGST_1@4.5"]=round_up(row["SGST_1@4.5"])
            row["IGST@9"]=round_up(row["IGST@9"])
            row["IGST_1@9"]=round_up(row["IGST_1@9"])

            return row
        self.dma_df=self.dma_df.apply(lambda x:Round_off(x),axis=1)                
        self.dma_df["REVISEDGROSSPO"]=(self.dma_df["GROSS PAYOUT"]-(self.dma_df["CGST@4.5"]+self.dma_df["CGST_1@4.5"]+self.dma_df["SGST@4.5"]+self.dma_df["SGST_1@4.5"]+self.dma_df["IGST@9"]+self.dma_df["IGST_1@9"]))
        self.dma_df["TDSAmount"]=round(self.dma_df["REVISEDGROSSPO"]*0.05,3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["TDSAmount"]=round_up(row["TDSAmount"])
            return row        
        self.dma_df=self.dma_df.apply(lambda x:Round_off(x),axis=1)                
        self.dma_df["NetPayout"]=(self.dma_df["REVISEDGROSSPO"]-self.dma_df["TDSAmount"])
        self.dma_df["FINALPAYOUTS"]=(self.dma_df["NetPayout"]-(self.dma_df["ADVN2"]+self.dma_df["CNCL2"]+self.dma_df["PDD"]+self.dma_df["OTHERDEBITS"]))
        self.dma_df.rename(columns={"NAME":"DMA NAME"}, inplace=True)
        self.dma_df=self.dma_df.drop(columns=["AGREEMENTID","AGREEMENTNO","AGREEMENTDATE","DISB_DATE","DISBURSALAMOUNT","DISB_AMT","AMTFIN","PRETAXIRR","LESSEEID","TENURE","EMI","FILENO","MODELNO","MANUFACTURERDESC","DEALERNAME","ADVANCEINSTL","PROCESSINGFEE","MFR_SUBVENTION_IN","MFR_SUBVENTION_PAID","DEALER_SUBVENTION","DMA_SUBVENTION","PROMOTIONDESC","MARGINMONEY","ADVANCE_EMI","EMPLOYERNAME","STATUS","MAKE","V_ASSET_CATG","PRODUCTFLAG","BRANCH_CODE","SCHEMECODE","PROMOTIONSCHEME","EFFRATE","MODELCODE","SUBMODELCODE","GROSS_LTV","NET_LTV","FINALSOURCE","FIRSTSOURCE","CUSTCATG","DMA_SUBVENTION_NOT_DED","EMPTYPE","EMPTYPE","STATE","CHANNELCODE","MANUFACTURERID","MANUFACTURERID","INFAVOUROF","CHEQUESTATUS","OSP_CODE","DME_NAME","DUMMY","CUSTOMER_NAME","PF+DC","PF+DC%","PO%","NET_LOAN","Manufacture name","PO_AMT1"])
        self.dma_df=self.dma_df[~(self.dma_df["DMA NAME"].str.lower().str.startswith("branch"))]
        self.dma_df=self.dma_df.loc[self.dma_df["DMABROKERCODE"].duplicated()==False]
        self.dma_df.insert(0,"Ref No",range(30001,30001+self.dma_df.shape[0]))
        self.dma_df["Ref No"]=self.dma_df["Ref No"].apply(lambda x:"TWDM052"+str(x))
        self.dma_df["CNCL"]=self.dma_df["Amount"]
        self.dma_df=self.dma_df[["Ref No","DMABROKERCODE","Month","Narration","DMA VENDOR CODE","DMA NAME","Sum of AMTFIN","TOTAL PAYOUT","CNCL","GROSS PAYOUT","CGST@4.5","CGST_1@4.5","SGST@4.5","SGST_1@4.5","IGST@9","IGST_1@9","REVISEDGROSSPO","TDSRATE","TDSAmount","NetPayout","ADVN2","CNCL2","PDD","OTHERDEBITS","FINALPAYOUTS","REMARKS","TDSCODE","BRANCHNM","DMA PAN","DMA ACCNO","DMA IFSC Code","DMA MODE OF PAYMENT","IBOX_IBOXID","IBOX_IBOXSTATUS","RCM/Non RCM","Channel GST"]]
    def excute(self):
        
        self.summary()