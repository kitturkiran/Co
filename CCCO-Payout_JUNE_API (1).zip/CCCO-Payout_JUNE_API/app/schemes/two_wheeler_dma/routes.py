import os
import pandas as pd
from .data_massaging import DataMassaging
from .data_calculation import Calculation
from .data_summary import Summary
from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
from datetime import datetime
from fastapi.background import BackgroundTasks
import shutil

tw_router=APIRouter()
@tw_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(dma: UploadFile,
                                   structure: UploadFile,
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
    
    
    dma_df = pd.read_excel(dma.file.read()) 
    structure_file=structure.file.read()
    pf_dc_df = pd.read_excel(structure_file,sheet_name="PF + Dc",usecols=["LAN_NO", "PF+DC%", "PF+DC"])
    structure_po_df=pd.read_excel(structure_file,sheet_name="PO")
    
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

        obj = DataMassaging(dma_df, rejected_df, pf_dc_df, structure_po_df, start_date, end_date)
        obj.execute()

        obj1= Calculation(obj.dma_df)
        obj1.Excute()

        obj2=Summary(obj1.dma_df)
        obj2.excute()
        SUMMARY_PDF=obj2.dma_df
        SUMMARY_PDF=SUMMARY_PDF[["Ref No","DMABROKERCODE","DMA NAME","Month","TOTAL PAYOUT"]]
  
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"TW_scheme5_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        obj1.dma_df1.to_excel(writer, sheet_name="TW scheme5-Cases", index=False)
        obj.rejection_df.to_excel(writer, sheet_name="Rejected", index=False)
        obj2.dma_df.to_excel(writer, sheet_name="Summary", index=False)
        SUMMARY_PDF.to_excel(writer,sheet_name="summary_pdf",index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)
    
@tw_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/two _wheeler scheme 5"
    destination_dir = f"./backup/two _wheeler scheme 5/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"   
    
    
    