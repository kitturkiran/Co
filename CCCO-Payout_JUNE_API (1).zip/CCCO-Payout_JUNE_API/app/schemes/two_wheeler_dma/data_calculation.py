import pandas as pd
import math


class Calculation:
    def __init__(self,dma_df:pd.DataFrame,cn:pd.DataFrame):
        self.dma_df=dma_df
        self.dma_df1=None 
        self.cn=cn

    
    
    def structure5(self):
        self.dma_df["PRETAXIRR"]=round((self.dma_df["PRETAXIRR"]),2)
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=18.96) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2),"PO%"]=0
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"]))  & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]!="PUNJAB")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both"))& (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]!="PUNJAB")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=24.97) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"]))& (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=18.96) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=0
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"]))& (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both")) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) &(self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=24.97) & (self.dma_df["May-23 Structure"].isin(["Structure 5","Structure 1","Structure 3","Structure 4 (A)","Structure 4 (B)"])) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1),"PO%"]=5 

    
        
    def Structure_1(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(17.97,19.97,inclusive="left")) & (self.dma_df["May-23 Structure"]=="Structure 1") & (self.dma_df["TENURE"]>36) & (self.dma_df["PF+DC"]>=1150),"PO%"]=0 
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.97,inclusive="left")) & (self.dma_df["May-23 Structure"]=="Structure 1") & (self.dma_df["TENURE"]>36) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.01)+650)),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.97,inclusive="left")) & (self.dma_df["May-23 Structure"]=="Structure 1") & (self.dma_df["TENURE"]>36) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.015)+650)),"PO%"]=3
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>21.97) & (self.dma_df["May-23 Structure"]=="Structure 1") & (self.dma_df["TENURE"]>36) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.015)+650)),"PO%"]=4
        
    def Structure_3(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=17.97) & (self.dma_df["May-23 Structure"]=="Structure 3")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=0 
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 3")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 3") &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["May-23 Structure"]=="Structure 3") & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5    
    
    def Structure_4a(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(17.97,18.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4 (A)")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=0.75 
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4 (A)")  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4 (A)") &  (self.dma_df["PF+DC%"]>=2),"PO%"]=1.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4 (A)") &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["May-23 Structure"]=="Structure 4 (A)") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75  
        
    def Structure_4b(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4")  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1 
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4")  & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4") &  (self.dma_df["PF+DC%"]>=1.5),"PO%"]=2.50
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4") &  (self.dma_df["PF+DC%"]>=2),"PO%"]=3.50
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 4") &  (self.dma_df["PF+DC%"]>=2),"PO%"]=4.00
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=24.97) & (self.dma_df["May-23 Structure"]=="Structure 4") & (self.dma_df["PF+DC%"]>=2),"PO%"]=5.00 

        
        
    def structure_6(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(17.97,18.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==222353)&(self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==222353)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==222353) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==222353) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==222353) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=4
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==241664)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==241664)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==241664) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==241664) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["DMABROKERCODE"]==241664) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==222352)&(self.dma_df["PF+DC%"]>=2),"PO%"]=4
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==222352)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=5

        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.46,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==219181)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.47,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==219181)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==219181) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==219181) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==219181) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.46,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==239219)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.47,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==239219)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==239219) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==239219) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==239219) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(17.97,18.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==307007)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==307007)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==307007) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=1.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==307007) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==307007) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.46,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==283795)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.47,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==283795)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==283795) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==283795) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==283795) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(17.97,18.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==290614)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==290614)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,20.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==290614) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=1.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(20.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==290614) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["DMABROKERCODE"]==290614) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.75
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(11.47,12.95,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==222352)&(self.dma_df["PF+DC%"]>=2),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(12.96,15.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==222352)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=15.97) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==222352) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=4

        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")  & (self.dma_df["DMABROKERCODE"]==301021)&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["DMABROKERCODE"]==301021)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==301021) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure 6")& (self.dma_df["DMABROKERCODE"]==301021) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["DMABROKERCODE"]==301021) & (self.dma_df["May-23 Structure"]=="Structure 6") & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        
        
    def Hness(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(10.47,14.5,inclusive="left")) & (self.dma_df["HNESS Cases"]=="HNESS")&(self.dma_df["PF+DC%"]>=2),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(14.5,16.95,inclusive="left")) & (self.dma_df["HNESS Cases"]=="HNESS")&(self.dma_df["PF+DC%"]>=2),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=16.95) & (self.dma_df["HNESS Cases"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([239775,221939,293346,219262])) & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([217791,241981])) & (self.dma_df["PRETAXIRR"]>=12.97)  & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        # temp=self.dma_df[self.dma_df["HNESS"]=="HNESS"]
        # grf=temp.groupby(["DMABROKERCODE"])
        # k=[]
        # l=[]
        # w=[]
        # for code,gdf in grf:
        #     # if len(code)>3:
            
        #     if gdf.shape[0]>=7:
        #         k.append(code)
        #     if gdf.shape[0]<=14:
        #         l.append(code)
        #     if gdf.shape[0]>=15:
        #         w.append(code)

        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==285902) & (self.dma_df["PRETAXIRR"]>=10.96)  & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        
        # self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(11.47,12.95,inclusive="left")) & (self.dma_df["HNESS"]=="HNESS")  & (self.dma_df["DMABROKERCODE"]==222352)&(self.dma_df["PF+DC%"]>=2),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(12.96,15.96,inclusive="left")) & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["DMABROKERCODE"]==222352)  & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=15.97) & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["DMABROKERCODE"]==222352) &  (self.dma_df["PF+DC%"]>=2),"PO%"]=4
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([217877,219031,219519,264716,273380])) & (self.dma_df["PRETAXIRR"]<11.6) & (self.dma_df["HNESS"]=="HNESS"),"PO%"]=0
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([217877,219031,219519,264716,273380])) & (self.dma_df["PRETAXIRR"].between(11.6,14.50,inclusive="left")) & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([217877,219031,219519,264716,273380])) & (self.dma_df["PRETAXIRR"].between(14.50,16.95,inclusive="left")) & (self.dma_df["HNESS"]=="HNESS") & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([217791])) & (self.dma_df["PRETAXIRR"]>=12.97)  & (self.dma_df["HNESS Cases"]=="HNESS") & (self.dma_df["PF+DC%"]>=3),"PO%"]=2
        # Structure for premium bikes
    def Structure_premium_bike(self):
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(12.75,13.50,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"].between(150000,300000,inclusive="left"))  & (self.dma_df["PF+DC%"]>=1),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(13.51,14.50,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"].between(150000,300000,inclusive="left"))  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(14.51,15.5,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"].between(150000,300000,inclusive="left"))  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(15.51,16.5,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"].between(150000,300000,inclusive="left"))  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=16.51) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"].between(150000,300000,inclusive="left"))  & (self.dma_df["PF+DC%"]>=1),"PO%"]=2

        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(10.75,11,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"]>=300000)  & (self.dma_df["PF+DC%"]>=1),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(11.01,11.75,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"]>=300000)  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(11.76,12.5,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"]>=300000)  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(12.51,13.0,inclusive="both")) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"]>=300000)  & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.75
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=13.01) & (self.dma_df["May-23 Structure"]=="Structure for premium bikes")   & (self.dma_df["NET_LOAN"]>=300000)  & (self.dma_df["PF+DC%"]>=1),"PO%"]=2        
        
      
    def OlaCases(self):
        self.dma_df.loc[(self.dma_df["MANUFACTURERDESC"].str.lower().str.contains("ola")),"PO%"]=2.25
        
    def MP_scheme(self):
        self.dma_df.loc[(self.dma_df["MANUFACTURERDESC"]=="HERO MOTOCORP LTD") & (self.dma_df["MAKE"]=="DESTINI") & 
                        (self.dma_df["STATE1"]=="MADHYA PRADESH") & (self.dma_df["PRETAXIRR"]>=14.97) ,"PO%"]=1
        self.dma_df.loc[(self.dma_df["MANUFACTURERDESC"]=="HERO MOTOCORP LTD") & (self.dma_df["MAKE"]=="MAESTRO") & 
                        (self.dma_df["STATE1"]=="MADHYA PRADESH") & (self.dma_df["PRETAXIRR"]>=14.97) ,"PO%"]=1
        self.dma_df.loc[(self.dma_df["MANUFACTURERDESC"]=="HERO MOTOCORP LTD") & (self.dma_df["MAKE"]=="PLEASURE") & 
                        (self.dma_df["STATE1"]=="MADHYA PRADESH") & (self.dma_df["PRETAXIRR"]>=14.97) ,"PO%"]=1
        
    def Remark_Structure(self):

        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >= 16.97%") & (self.dma_df["Remark 2"]=="PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >= 16.97% , PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >= 17.47% , PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=17.47) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >= 17.97%, PF+DC 1.5%") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=14.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=14.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=12.47%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=12.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=14.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=14.97) & (self.dma_df["PF+DC%"]>=1)&(self.dma_df["DMABROKERCODE"].isin([228028])),"PO%"]=3
        
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.47 , PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=16.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]=2.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97 , PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF 1% , Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=1
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["DMABROKERCODE"].isin([287573,316475])),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=3
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.50),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.50)& (self.dma_df["DMABROKERCODE"].isin([252135])),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.50)& (self.dma_df["DMABROKERCODE"].isin([321581])),"PO%"]=3.50
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.50)& (self.dma_df["DMABROKERCODE"].isin([252135])),"PO%"]=2.25
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=16.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC%"]>=1.50)& (self.dma_df["DMABROKERCODE"].isin([272698,273012])),"PO%"]=3
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=17.97 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=17.97 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=17.97 , PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=18.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%") & (self.dma_df["Remark 2"]=="PF+DC 1.5%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=2        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%") & (self.dma_df["Remark 2"]=="PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%") & (self.dma_df["Remark 2"]=="PF+DC 1.5%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5) & (self.dma_df["DMABROKERCODE"].isin([249253,291271])),"PO%"]=1.75
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1),"PO%"]=3
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["DMABROKERCODE"].isin([287573])),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=18.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=18.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=1.50),"PO%"]=1              
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.47%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.47) & (self.dma_df["PF+DC%"]>=1.50),"PO%"]=2              
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.72%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=19.72) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2                 
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2              
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.25)& (self.dma_df["DMABROKERCODE"].isin([323124,257070])),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.25)& (self.dma_df["DMABROKERCODE"].isin([257703,258110])),"PO%"]=2.5
        
        
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([252135])),"PO%"]=2.25              
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.30%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.3),"PO%"]=1.5  
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=2 
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([248774,255577,283866,295474,314093])),"PO%"]=1.5 
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([258557])),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([245872,255576,261947,272644,291271,307070])),"PO%"]=3 
        
        
        
        
        
        
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([227153])),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 1.75%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.75),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=19.97%, PF+DC 2.00%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
               
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.47 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=20.47) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.47%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=20.47) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.47%, PF+DC 2.00%") & (self.dma_df["PRETAXIRR"]>=20.47) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.47%, PF+DC 2.00%") & (self.dma_df["PRETAXIRR"]>=20.47) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["DMABROKERCODE"].isin([222762])),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.97 % , PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2.25
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.97 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.47%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.97%, PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=20.97%, PF+DC 2.00%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=21.97%, PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=21.47 % , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=21.47) & (self.dma_df["PF+DC%"]>=2),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=21.97 , PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=21.97%, PF+DC 1.50%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.50),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=21.97%, PF+DC 2%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=4
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR >=22.47 % , PF+DC 1.25%") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=1.25),"PO%"]=2.5
        
        
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=18.97%, PF 1.50%") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=18.97%, PF 2.50% , Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=3.5
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=18.97%, PF 2.50% , Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=19.97%, PF 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=19.97%, PF 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5)& (self.dma_df["DMABROKERCODE"].isin([274937])),"PO%"]=3.5
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.60%,  IRR >= 21.97%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.6),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.60%,  IRR >= 21.97%") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.6)& (self.dma_df["DMABROKERCODE"].isin([306517])),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.60%,  IRR >= 22.47%") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=1.6),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=2.50%,  IRR >= 22.97%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=22.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=3%,  IRR >= 17.97%") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=3),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PF>=4%,  IRR >= 20.97%") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=4),"PO%"]=5
        
        
        
        
        
        
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR 20.97%, PF 2% & DC 650/-") & (self.dma_df["PRETAXIRR"]>=20.97) & ((self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650))),"PO%"]=3.5
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=18.97%, PF 1.50%") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=4
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="IRR>=19.97%, PF 1.50%") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5),"PO%"]=4
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.60%,  IRR >= 21.97%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.6),"PO%"]=3
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.60%,  IRR >= 21.97%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.6) & (self.dma_df["DMABROKERCODE"].isin([283904])) ,"PO%"]=2.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.70%,  IRR >= 21.97%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=1.7),"PO%"]=3.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=1.70%,  IRR >= 22.47%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=1.7),"PO%"]=3.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=2%,  IRR >= 21.97%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=2%,  IRR >= 23.47%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=23.47) & (self.dma_df["PF+DC%"]>=2),"PO%"]=5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=2.5%,  IRR >= 23%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=23) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=3
        # self.dma_df.loc[(self.dma_df["Remark"]=="PF>=2.50%,  IRR >= 22.47%, Tenure >= 18") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 3% For IRR >= 17.98%, PO 4% For IRR >= 19.97%") & (self.dma_df["PRETAXIRR"]>=17.98),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 3% For IRR >= 17.98%, PO 4% For IRR >= 19.97%") & (self.dma_df["PRETAXIRR"]>=19.97),"PO%"]=4                  
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 18.47%") & (self.dma_df["PRETAXIRR"]>=18.47),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5 
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.97% , PO 4.25% FOR IRR >=23.97") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.97% , PO 4.25% FOR IRR >=23.97") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=4.25 
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 23.97%, PO 3.00% For IRR >= 22.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 23.97%, PO 3.00% For IRR >= 22.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=4
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.47%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=4.25
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.47%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=23.47),"PO%"]=4.5
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.47%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.98%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=22.98),"PO%"]=4.25
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.98%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=23.47),"PO%"]=4.5
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 22.98%, PO 4.50% For IRR >= 23.47%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% FOR IRR >=22.97") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=4.25
        
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 5.00% if IRR >=21.97% & PO 4.00% if IRR 20.97% , PF 3%") & (self.dma_df["PRETAXIRR"]>=20.97),"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark"]=="PO 5.00% if IRR >=21.97% & PO 4.00% if IRR 20.97% , PF 3%") & (self.dma_df["PRETAXIRR"]>=21.97),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IF IRR >=14.97% PO 2% & IF IRR >=16.97 PO 4%  , PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=14.97)& (self.dma_df["PF+DC%"]>=1),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IF IRR >=14.97% PO 2% & IF IRR >=16.97 PO 4%  , PF+DC 1%") & (self.dma_df["PRETAXIRR"]>=16.97)& (self.dma_df["PF+DC%"]>=1),"PO%"]=4
        
        self.dma_df.loc[(self.dma_df["Remark"]=="IF IRR >=14.97%  PO 2%  PF+DC 1% & IF IRR >= 16.97 PO 3% PF+DC 1.5%") & (self.dma_df["PRETAXIRR"]>=14.97)& (self.dma_df["PF+DC%"]>=1),"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark"]=="IF IRR >=14.97%  PO 2%  PF+DC 1% & IF IRR >= 16.97 PO 3% PF+DC 1.5%") & (self.dma_df["PRETAXIRR"]>=16.97)& (self.dma_df["PF+DC%"]>=1.5),"PO%"]=3
        self.dma_df.loc[(self.dma_df["May-23 Structure"]=="Structure 5 / 2%") & (self.dma_df["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=2
        
        lst=[
            285849,
            288542,
            303183,
            307175,
            307176,
            308329,
            309121,
            310035,
            315938,
            318741,
            318875,
            322394,

            ]
        
        
        for i in lst:   
            temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i),"PO%"].shape[0]
            if temp>=7:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=18.47),"PO%"]=3
            else:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=18.47),"PO%"]=0
                
        # lst1=[309657,
        #     321575]
        # for i in lst1:   
        #     temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i),"PO%"].shape[0]
        #     if temp>=11:
        #         self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=3 
        #     temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i),"PO%"].shape[0]
        #     if temp>=11:
        #         self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5 
        
        lst2=[
                271688,
                273125,
                274788,
                284636,
                284638,
                284921,
                298782,
                298780,
                301144,
                302909,
                304156,
                307178,
                307333,
                309657,
                315511,
                315513,
                318878,
                320054,
                321485,
                321575,
                321577,
                321573,

            ]
        
        
        for i in lst2:   
            temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i),"PO%"].shape[0]
            if temp>=11:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=4
            else:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=0
                
            
            temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i),"PO%"].shape[0]
            if temp>=11:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
            else:
                self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==i) & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=0
                
        
        
        # temp=self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"].shape[0]                       
        # if temp>=11:
        #     self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=3
            
        # temp=self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"].shape[0]
        # if temp>=11:
        #     self.dma_df.loc[(self.dma_df["Remark"]=="PO 3.00% For IRR >= 22.97%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
            
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.47%") & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=4
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=4
        # # temp=self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"].shape[0]
        # # if temp>=11:
        # #     self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=22.47),"PO%"]=4
            
        
        # # temp=self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"].shape[0]
        # # if temp>=11:
        # #     self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 22.47%, PO 5.00% For IRR >= 23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5
            
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 23.97%, PO 3.00% For IRR >= 22.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=3
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.00% For IRR >= 23.97%, PO 3.00% For IRR >= 22.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=4
        
        
        
        
        # # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.97%, PO 5% For IRR >=24.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=4
        # # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4% For IRR >=22.97%, PO 5% For IRR >=24.97%") & (self.dma_df["PRETAXIRR"]>=24.97),"PO%"]=5   
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 21.98%, PO 4.50% For IRR >= 22.97%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=21.98),"PO%"]=4.25
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 21.98%, PO 4.50% For IRR >= 22.97%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=22.97),"PO%"]=4.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.25% For IRR >= 21.98%, PO 4.50% For IRR >= 22.97%, PO 5% For IRR >=23.97%") & (self.dma_df["PRETAXIRR"]>=23.97),"PO%"]=5   
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 5.00% if IRR >=21.97% & PO 4.00% if IRR 20.97% , PF 3%") & (self.dma_df["PRETAXIRR"]>=20.97),"PO%"]=4
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 5.00% if IRR >=21.97% & PO 4.00% if IRR 20.97% , PF 3%") & (self.dma_df["PRETAXIRR"]>=21.97),"PO%"]=5        
        
        # temp=self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4%  PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"].shape[0]
        # if temp<=10:
        
        #     self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4%  PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=3        
        # else:
        #     self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4%  PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=4
        
        
        # temp=self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4% PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"].shape[0]
        # if temp<=10:
        
        #     self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4% PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=3        
        # else:
        #     self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 10 files he will get 3% PO , If cases are  > 10 files he will get 4% PO") & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=4
        
        
        temp=self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 25 files he will get 2% PO , If cases are  > 50 files he will get 2.50%  PO") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=2),"PO%"].shape[0]
        if temp>=25:
        
            self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 25 files he will get 2% PO , If cases are  > 50 files he will get 2.50%  PO") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2        
        if temp>50:
            self.dma_df.loc[(self.dma_df["Remark"]=="If cases are  = < 25 files he will get 2% PO , If cases are  > 50 files he will get 2.50%  PO") & (self.dma_df["PRETAXIRR"]>=17.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2.5
        
        
        
        
        
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.50% For IRR >=23.47%, PO 5% For IRR >= 23.97%, PF+DC 2.50%") & (self.dma_df["PRETAXIRR"]>=23.47)& (self.dma_df["PF+DC%"]>=2.5),"PO%"]=4.5
        # self.dma_df.loc[(self.dma_df["Remark"]=="PO 4.50% For IRR >=23.47%, PO 5% For IRR >= 23.97%, PF+DC 2.50%") & (self.dma_df["PRETAXIRR"]>=23.97)& (self.dma_df["PF+DC%"]>=2.5),"PO%"]=5
        # self.dma_df.loc[(self.dma_df["Remark"]=="For Honda PO 5% IRR >= 23.47%, For Ather PO 3% IRR >= 19.97%, PF>=2%,  Tenure >= 18") & (self.dma_df["MANUFACTURERDESC"]=="HONDA MOTORCYLE SCOOTER INDIA P LTD") & (self.dma_df["PRETAXIRR"]>=23.47) & (self.dma_df["PF+DC%"]>=2),"PO%"]=5
        # self.dma_df.loc[(self.dma_df["Remark"]=="For Honda PO 5% IRR >= 23.47%, For Ather PO 3% IRR >= 19.97%, PF>=2%,  Tenure >= 18") & (self.dma_df["MANUFACTURERDESC"]=="ATHER ENERGY PVT LTD") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2),"PO%"]=3
        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([253114.269410])) & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]
        # num=temp.shape[0]
        # if num>10:
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([253114.269410])) & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=4
            
        # else:
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin([253114.269410])) & (self.dma_df["PRETAXIRR"]>=18.47) & (self.dma_df["PF+DC"]>=2500),"PO%"]=3



        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==227763) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.50),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==227763) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.50),"PO%"]=4.50
        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==227763) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.50),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==227763) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.50),"PO%"]=5
        
        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==248104) & (self.dma_df["PRETAXIRR"]>=12.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]
        # num=temp.shape[0]
        # print(num)
        # if num>=7:
        #     print("kiran")
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==248104) & (self.dma_df["PRETAXIRR"]>=12.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]=1.5
            

        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==302357) & (self.dma_df["PRETAXIRR"]>=12.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]
        # num=temp.shape[0]
        # if num>=20:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==302357) & (self.dma_df["PRETAXIRR"]>=12.47) & (self.dma_df["PF+DC%"]>=1),"PO%"]=2    
        
        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316180) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316180) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=4.5
            
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316180) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316183) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=5             

        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316183) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316183) & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=4.5
            
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316183) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]
        # num=temp.shape[0]
        # if num>=30:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==316183) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=5        
        
        
        # temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322037) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]
        # num=temp.shape[0]
        # if num>=10:
                
        #     self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322037) & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.5),"PO%"]=5
        
        
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==217877),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==217877),"PO%"]=0 

#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219031),"PO%"]
#         num=temp.shape[0]
#         if num<10:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219031),"PO%"]=0 
            
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219116),"PO%"]
#         num=temp.shape[0]
#         if num<10:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219116),"PO%"]=0
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219519),"PO%"]
#         num=temp.shape[0]
#         if num<8:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==219519),"PO%"]=0
        
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==225759),"PO%"]
#         num=temp.shape[0]
#         if num<10:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==225759),"PO%"]=0
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==239015),"PO%"]
#         num=temp.shape[0]
#         if num<10:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==239015),"PO%"]=0
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==254646),"PO%"]
#         num=temp.shape[0]
#         if num<20:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==254646),"PO%"]=0

#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==264716),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==264716),"PO%"]=0
       
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==273711),"PO%"]
#         num=temp.shape[0]
#         if num<20:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==273711),"PO%"]=0

#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==296164),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==296164),"PO%"]=0 
        
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==297827),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==297827),"PO%"]=0
            
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==298609),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==298609),"PO%"]=0
            
            
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==300697),"PO%"]
#         num=temp.shape[0]
#         if num<20:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==300697),"PO%"]=0                  

#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==309523),"PO%"]
#         num=temp.shape[0]
#         if num<5:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==309523),"PO%"]=0                                    
# # HNESS
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==309905),"PO%"]
#         num=temp.shape[0]
#         if num<15:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==309905),"PO%"]=0                                    

#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322027),"PO%"]
#         num=temp.shape[0]
#         if num<8:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322027),"PO%"]=0                                            
               
#         temp=self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322037),"PO%"]
#         num=temp.shape[0]
#         if num<10:
                
#             self.dma_df.loc[(self.dma_df["DMABROKERCODE"]==322037),"PO%"]=0 
        
        
        
        

        
        
        
    def Remark_struture_1(self):
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 21") & (self.dma_df["PRETAXIRR"]>=22.97) & (self.dma_df["PF+DC%"]>=2.5) & (self.dma_df["TENURE"]>=18) ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 22") & (self.dma_df["PRETAXIRR"]>=15.97) & (self.dma_df["PF+DC%"]>=1) & (self.dma_df["TENURE"]>=18) ,"PO%"]=1
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 23") & (self.dma_df["PRETAXIRR"]>=18.02) & (self.dma_df["PF+DC%"]>=1.25) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 24") & (self.dma_df["PRETAXIRR"]>=19.22) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 25") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=2) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 26") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 26") & (self.dma_df["PRETAXIRR"]>=19.97) & (self.dma_df["PF+DC%"]>=1.5) & (self.dma_df["DMABROKERCODE"].isin([261407,305495])) ,"PO%"]=1.5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 27") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 28") & (self.dma_df["PRETAXIRR"]>=21.97) ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 29") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650)) ,"PO%"]=4
        temp=self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 30") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650))]
        grf=temp.groupby(["DMABROKERCODE"])
        k=[]
        
        for code,gdf in grf:
            # if len(code)>3:
            
            if gdf.shape[0]>=17:
                k.append(code)
            
        self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin(k)) & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650)) ,"PO%"]=4
        
        temp2=self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 31") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650))]
        grf2=temp2.groupby(["DMABROKERCODE"])
        l=[]
        
        for code,gdf in grf2:
            # if len(code)>3:
            
            if gdf.shape[0]>=17:
                l.append(code)
        self.dma_df.loc[(self.dma_df["DMABROKERCODE"].isin(l)) & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650)) ,"PO%"]=4
        
        
        
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 32") & (self.dma_df["PRETAXIRR"]>=22.47) ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 33") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 34") & (self.dma_df["PRETAXIRR"]>=22.47) & (self.dma_df["PF+DC%"]>=2.5) ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 35") & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 36") & (self.dma_df["PRETAXIRR"]>=14.47) & (self.dma_df["PF+DC%"]>=1) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 37") & (self.dma_df["PRETAXIRR"]>=18.97) & (self.dma_df["PF+DC%"]>=0.5) ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 38") & (self.dma_df["PRETAXIRR"]>=16.96) & (self.dma_df["PF+DC%"]>=1) ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 38") & (self.dma_df["PRETAXIRR"]>=16.96) & (self.dma_df["PF+DC%"]>=1) & (self.dma_df["DMABROKERCODE"]==287573) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 38") & (self.dma_df["PRETAXIRR"]>=16.47) & (self.dma_df["MAKE"].isin(["METEOR 350","CLASSIC 350","GT 650","HUNTER 350","HIMALAYAN","INTERCEPTOR"])) & (self.dma_df["PF+DC%"]>=1) ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 39") & (self.dma_df["PRETAXIRR"]>=16.96) & (self.dma_df["PF+DC%"]>=1.5) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 39") & (self.dma_df["PRETAXIRR"]>=16.96) & (self.dma_df["PF+DC%"]>=1.5) & (self.dma_df["DMABROKERCODE"]==((228028)or(273012))) ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 40") & (self.dma_df["PRETAXIRR"]>=16.96) & (self.dma_df["PF+DC%"]>=1.25)  ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 40") & (self.dma_df["PRETAXIRR"]>=16.47) & (self.dma_df["MAKE"].isin(["CLASSIC 350","METEOR 350","GT 650"])) & (self.dma_df["PF+DC%"]>=1.25)  ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 41") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["PF+DC"]>=((self.dma_df["AMTFIN"]*0.02)+650)) ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 42") & (self.dma_df["PRETAXIRR"].between(18.97,20.97,inclusive="left")) & (self.dma_df["PF+DC"]>=1250)  ,"PO%"]=2
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 42") & (self.dma_df["PRETAXIRR"]>=20.97) & (self.dma_df["PF+DC"]>=1600)  ,"PO%"]=3
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 43") & (self.dma_df["PRETAXIRR"].between(20.97,21.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2)  ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 43") & (self.dma_df["PRETAXIRR"]>=21.97) & (self.dma_df["PF+DC%"]>=2)  ,"PO%"]=5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 44") & (self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) & (self.dma_df["PF+DC%"]>=2.25)  ,"PO%"]=4
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 44") & (self.dma_df["PRETAXIRR"]>=24.97) & (self.dma_df["PF+DC%"]>=2.25)  ,"PO%"]=5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 45") & (self.dma_df["PRETAXIRR"].between(23.47,23.97,inclusive="left")) & (self.dma_df["PF+DC%"]>=2.25)  ,"PO%"]=4.5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 45") & (self.dma_df["PRETAXIRR"]>=23.97) & (self.dma_df["PF+DC%"]>=2.25)  ,"PO%"]=5
        self.dma_df.loc[(self.dma_df["Remark 1a"]=="Remark 48"),"PO%"]=0
        self.dma_df.loc[(self.dma_df["Remark 2a"]=="Remark 47") & (self.dma_df["PRETAXIRR"]>=16.47)  & (self.dma_df["MAKE"].isin(["METEOR 350","CLASSIC 350","GT 650"])),"PO%"]=3
    
    def Royal_enfield_cases(self):
        self.dma_df.loc[(self.dma_df["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"]))  & (self.dma_df["May-23 Structure"]!="Structure 5"),"PO%"]=2
        
    def Structure_5(self):
        self.dma_df.loc[(self.dma_df["Remark"].isnull()==False) & (self.dma_df["PRETAXIRR"]>=16.98) & (self.dma_df["PO%"]==0.0) & (self.dma_df["Manufacture name"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=2
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=18.96) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=0
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB")  & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB")  & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=24.97) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]!="PUNJAB") & (self.dma_df["PF+DC%"]>=2)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=5
        
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=18.96) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=0
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(18.97,19.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=0.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(19.97,21.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=1
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(21.97,22.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=2
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(22.97,23.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=2.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"].between(23.97,24.96,inclusive="both")) & (self.dma_df["PO%"]==0.0) & (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=3.5
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]>=24.97) &(self.dma_df["PO%"]==0.0)& (self.dma_df["STATE1"]=="PUNJAB") & (self.dma_df["PF+DC%"]>=1)& (self.dma_df["HNESS Cases"]!="HNESS"),"PO%"]=5
        
     
     
    def NIL(self):
        self.dma_df.loc[(self.dma_df["May-23 Structure"]=="NIL"),"PO%"]=0.0
      
    
    def basic_structure(self):
        self.dma_df.loc[(self.dma_df["May-23 Structure"]==0.01)&(self.dma_df["PO%"]==0),"PO%"]=1
        self.dma_df.loc[(self.dma_df["May-23 Structure"]==0.02)&(self.dma_df["PO%"]==0),"PO%"]=2
    
    def Caluation(self):
        self.dma_df["PO_AMT1"]=(self.dma_df["NET_LOAN"]*((self.dma_df["PO%"]/100)))
        # self.dma_df["GROSS PAYOUT"]=(self.dma_df["PO_AMT1"]-self.dma_df["CNCL"])
        self.dma_df["Final Payout_after cancellation"]=self.dma_df["PO_AMT1"]
        self.cn.rename(columns={"Broker ID":"DMABROKERCODE"},inplace=True)
        self.cn.rename(columns={"Recovery":"Amount"},inplace=True)
        # self.cn.drop()
        # dit=self.cn.to_dict()
        temp=self.cn["DMABROKERCODE"].to_list()
        temp1=self.cn["Amount"].to_list()
        dit={"Code":"Amount"}
        for i in range(0,len(temp1)):
            dit[temp[i]]=temp1[i]
            # for j in temp1:
                
                
                
        self.dma_df=pd.merge(self.dma_df,self.cn,on="DMABROKERCODE",how="left")
        self.dma_df["Amount"].fillna(0,inplace=True)
        self.dma_df.loc[(self.dma_df["DMABROKERCODE"].duplicated()==True),"Amount"]=0
        self.dma_df=self.dma_df.apply(lambda row: self.cancel(row,dit,temp),axis=1)
        self.dma_df["GROSS PAYOUT"]=self.dma_df["Final Payout_after cancellation"]
        #self.dma_df=self.dma_df.round({"PO_AMT1":2})
        
    # def round_up(n,decimals=0):
    #     multiplier=10**decimals
    #     return math.floor(n*multiplier + 0.5)/multiplier
        
    def Removing_columns(self):

        
        self.dma_df["PO_AMT1"]=round(self.dma_df["PO_AMT1"],3)
        self.dma_df["GROSS PAYOUT"]=round(self.dma_df["GROSS PAYOUT"],3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["PO_AMT1"]=round_up(row["PO_AMT1"])
            row["GROSS PAYOUT"]=round_up(row["GROSS PAYOUT"])
            return row
        self.dma_df=self.dma_df.apply(lambda x:Round_off(x),axis=1)

        self.dma_df=self.dma_df.drop(columns=["PO_AMT","REMARK_FLAG","SUM_OF_AMTFIN","Remark 2"])  
        
    def Removing_columns1(self):
        self.dma_df1=self.dma_df
        self.dma_df1=self.dma_df1.drop(columns=["STATE1","Month","Narration","CNCL","GROSS PAYOUT"])  
        
          
    def greater_than(self):
        temp=self.dma_df[~(self.dma_df["Remark"].isnull()==False)]
        temp1=self.dma_df[self.dma_df["Remark"].isnull()==False]
        temp=pd.DataFrame(temp)
        temp1=pd.DataFrame(temp1)
        temp.loc[(temp["May-23 Structure"]==0.02) & (temp["PO%"].between(0.5,10,inclusive="both")),"PO%"]=2
        temp.loc[(temp["May-23 Structure"].isin(["Structure 5",0.02])) & (temp["PRETAXIRR"]>=16.98)  &  (temp["Manufacture name"].str.contains("ROYAL ENFIELD")),"PO%"]=2
        temp.loc[(temp["May-23 Structure"].isin(["Structure 5",0.02])) & (temp["PRETAXIRR"]>=16.98)  &  (temp["Manufacture name"].str.contains("CLASSIC LEGENDS PVT LTD")),"PO%"]=2
        temp.loc[(temp["May-23 Structure"].isin(["Structure 5",0.02])) & (temp["PRETAXIRR"]<=16.97) & (temp["Manufacture name"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=0  
        temp.loc[(temp["May-23 Structure"]==0.03),"PO%"]=3
        temp1.loc[(temp1["May-23 Structure"]==0.02) & (temp1["PO%"].between(2,10,inclusive="both")),"PO%"]=2
        # temp1.loc[(temp1["PRETAXIRR"]<=16.97)  & (["Remark 2a"]!="Remark 47") & (temp1["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=0 
        # temp1.loc[(temp1["PRETAXIRR"]>=16.98) & (temp1["PO%"]==0) & (temp1["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=2
        
        self.dma_df=pd.concat([temp,temp1],ignore_index=True)
        self.dma_df.loc[(self.dma_df["PRETAXIRR"]<=16.97)  & (self.dma_df["Manufacture name"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=0
        # self.dma_df.loc[(self.dma_df["Remark"]=="Structure 5 / 2%") & (self.dma_df["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])),"PO%"]=2
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["PRETAXIRR"].between(16.97,19.96,inclusive="both")) & (self.dma_df["PF+DC%"]>=3) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("jawa")) & (self.dma_df["PRETAXIRR"].between(16.37,16.96,inclusive="both")) & (self.dma_df["PF+DC%"]>=3) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("jawa")) & (self.dma_df["PRETAXIRR"].between(16.37,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=24) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("jawa")) & (self.dma_df["PRETAXIRR"].between(16.31,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=30) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("jawa")) & (self.dma_df["PRETAXIRR"].between(16.2,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=36) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("yezdi")) & (self.dma_df["PRETAXIRR"].between(16.37,16.96,inclusive="both")) & (self.dma_df["PF+DC%"]>=3) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("yezdi")) & (self.dma_df["PRETAXIRR"].between(16.37,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=24) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("yezdi")) & (self.dma_df["PRETAXIRR"].between(16.31,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=30) & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UT")==True) & (self.dma_df["MAKE"].str.lower().str.contains("yezdi")) & (self.dma_df["PRETAXIRR"].between(16.2,16.96,inclusive="both")) & (self.dma_df["TENURE"]>=36)  & (self.dma_df["PF+DC%"]>=2) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        
        # self.dma_df.loc[(self.dma_df["Category"]=="ATHER") & (self.dma_df["PRETAXIRR"]>=15.96) & (self.dma_df["PF+DC%"]>=3) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
        # self.dma_df.loc[(self.dma_df["Category"]=="ATHER") & (self.dma_df["PRETAXIRR"]>=16.97) & (self.dma_df["CHANNELCODE"]=="TW-Assessed Income Program") & (self.dma_df["PF+DC%"]>=3) & (self.dma_df["PO%"].between(0,1,inclusive="both")),"PO%"]=1
    def structure_55(self):
        self.dma_df.loc[(self.dma_df["May-23 Structure"]=="Structure 5") & (self.dma_df["PRETAXIRR"]>=18.96) & (self.dma_df["MANUFACTURERDESC"].isin(["ROYAL ENFIELD","CLASSIC LEGENDS PVT LTD"])) & (self.dma_df["PF+DC%"]>=2),"PO%"]=2
        # self.cn.rename(columns={"Code":"DMABROKERCODE"},inplace=True)
        # # self.cn.drop()
        # # dit=self.cn.to_dict()
        # temp=self.cn["DMABROKERCODE"].to_list()
        # temp1=self.cn["Amount"].to_list()
        # dit={"Code":"Amount"}
        # for i in range(0,len(temp1)):
        #     dit[temp[i]]=temp1[i]
        #     # for j in temp1:
                
                
                
        # self.dma_df=pd.merge(self.dma_df,self.cn,on="DMABROKERCODE",how="left")
        # self.dma_df["Amount"].fillna(0,inplace=True)
        # self.dma_df.loc[(self.dma_df["DMABROKERCODE"].duplicated()==True),"Amount"]=0
        # self.dma_df=self.dma_df.apply(lambda row: self.cancel(row,dit,temp),axis=1)
        
    def cancel(self,row,dit,temp):
        for code in temp:
            if(row["DMABROKERCODE"]==code):
                if(row["Final Payout_after cancellation"]>dit[code]):


                    row["Final Payout_after cancellation"]=row["Final Payout_after cancellation"]-dit[code]

                    row["Amount"]=dit[code]
                    dit[code]=0
            
                else:
                    # row["Final Payout"]=0
                    dit[code]=dit[code]-row["Final Payout_after cancellation"]
                    row["Amount"]=row["Final Payout_after cancellation"]
                    row["Final Payout_after cancellation"]=0
  
        return row
    def Excute(self):
        self.structure5()
        # self.Royal_enfield_cases()
        # self.Structure_1()
        self.Structure_3()
        self.Structure_4b()
        # self.structure_6()
        # self.Hness()
        # self.OlaCases()
        # self.MP_scheme()
        self.Structure_premium_bike()
        # self.Hness()
        self.Remark_Structure()
        # self.Hness()
        # self.Remark_struture_1()
        self.Structure_5()
        self.Hness()
        self.greater_than()
        self.NIL()
        self.Caluation()
        self.Removing_columns()
        self.Removing_columns1()
        
        
        


   
        
       
        
        
        