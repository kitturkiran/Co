import os
import pandas as pd
from data_calculation import DataCalculation
from po_summary import generateSummary,generateSummary1 
from data_massaging import DataMassaging



dma_df = pd.read_excel(r"D:\schema _scource code\cv_ce_dma\CV Dump_March_ Booster\input\Dump.xlsx")
tagging_df=pd.read_excel(r"D:\schema _scource code\cv_ce_dma\CV Dump_March_ Booster\input\Input Sheet.xlsx")
booster=pd.read_excel(r"D:\schema _scource code\cv_ce_dma\CV Dump_March_ Booster\input\Booster Target Sept Oct 22.xlsx")
rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

obj1 = DataMassaging(dma_df, rejected_df,tagging_df,"1-03-2023","31-03-2023")
obj1.execute()

data_calculation1 = DataCalculation(obj1.dma_df,tagging_df,obj1.rejection_df,booster)
data_calculation1.execute()

data_calculation1.rejected_df.to_excel("Rejected.xlsx")
data_calculation1.df.to_excel("CV_CE DMA_BOOSTER_OUTPUT_FEB23.xlsx",index=False)
# data_calculation1.without_connector.to_excel("output_without connetor_cases.xlsx")
summary_df = generateSummary(data_calculation1.df)
summary_df.to_excel("CV_CE DMA_BOOSTER_SUMMARY_FEB23.xlsx",index=False)
# summary_df1 = generateSummary1(data_calculation1.df)
# summary_df1.to_excel("summary_with_connector.xlsx")
