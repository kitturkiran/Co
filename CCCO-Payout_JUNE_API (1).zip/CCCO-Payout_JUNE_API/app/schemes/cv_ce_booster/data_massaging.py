from datetime import datetime
import pandas as pd

class DataMassaging:
    def __init__(self, df:pd.DataFrame, rejection_df:pd.DataFrame,tagging_df:pd.DataFrame, start_date: str, end_date: str):
        self.dma_df = df
        self.rejection_df = rejection_df
        self.tagging=tagging_df
        self.startDate = start_date
        self.endDate = end_date


    def NewAndRefinanace(self):
        temp = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == False) & (self.dma_df["AGREEMENTNO"].str.startswith(
            "UV") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "LAN not as per Process note"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == True) | (self.dma_df["AGREEMENTNO"].str.startswith(
            "UV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == True)]

        self.dma_df["NEW/REFINANCE_OP"] = ""
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == True), "NEW/REFINANCE_OP"] = "NEW"
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == True), "NEW/REFINANCE_OP"] = "REFINANCE"

    def RemoveOtherThanA(self):
        temp = self.dma_df[self.dma_df["STATUS"] != 'A'].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Status Other Than A"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["STATUS"] == 'A']

    def RemoveValuesWithBranch_Direct(self):
        temp = self.dma_df[(self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "DMA Name Contains BRANCH, DIRECT, MAGMA"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True))]

    def RemoveFromPromotionDescription(self):
        temp = self.dma_df[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Promotion desc with values death of app / nabard subsidy"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy"))]

    def RemoveBasedOnTenure(self):
        temp = self.dma_df[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18))].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "New Car Tenure <= 24/Refinance CV CE <= 18"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18)))]
        
    def RemoveOutsidePeriod(self):
        self.dma_df["DISBURSALDATE"] = pd.to_datetime(self.dma_df["DISBURSALDATE"])
        temp = self.dma_df[(((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Outside the Period of Calculation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False))]

    def RBKCases(self):
        temp = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "File No. Contain RBK"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk") == False]
        
    def AddColumnBasedOnPromotionDesc(self):
        self.dma_df["Strategic/FTU/Retail_OP"] = "NA"
        self.dma_df.loc[((self.dma_df["PROMOTIONDESC"].str.lower().str.contains("strategic") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("str") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("stg") == True)), "Strategic/FTU/Retail_OP"] = "STRATEGIC"
      
        condition = ((self.dma_df["PROMOTIONDESC"].str.lower().str.contains("ftu") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("ftb") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("first time user") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("first time buyer") == True) | (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("first") == True))
        self.dma_df.loc[condition, "Strategic/FTU/Retail_OP"] = "FTU"
        
        
        self.dma_df.loc[(self.dma_df["Strategic/FTU/Retail_OP"] == "NA"), "Strategic/FTU/Retail_OP"] = "RETAIL"
        self.dma_df.loc[(self.dma_df["PROMOTIONDESC"]=="ONE EQUIPMENT OWNER HIRER"),"Strategic/FTU/Retail_OP"]="FTU"
        self.dma_df.loc[(self.dma_df["PROMOTIONDESC"]=="ONE EQUIPMENT OWNER"),"Strategic/FTU/Retail_OP"]="FTU"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093438"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093393"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093383"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093387"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093333"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093317"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093346"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093341"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093367"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093327"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        # self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="LQJMR00047093434"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.dma_df.loc[(self.dma_df["PROMOTIONDESC"].str.lower().str.contains("one equipment owner")),"Strategic/FTU/Retail_OP"]="FTU"
    def SetMinLoginRate(self):
        self.dma_df["IRR"] = self.dma_df["IRR"].round(2)
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["Strategic/FTU/Retail_OP"] == "STRATEGIC")), "MIN_LOGIN_RATE"] = 9.60
        
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["Strategic/FTU/Retail_OP"] == "RETAIL")), "MIN_LOGIN_RATE"] = 10.35
        
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["Strategic/FTU/Retail_OP"] == "FTU")), "MIN_LOGIN_RATE"] = 13.35
        
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["Strategic/FTU/Retail_OP"] == "STRATEGIC")), "MIN_LOGIN_RATE"] = 10.60
        
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["Strategic/FTU/Retail_OP"] == "RETAIL")), "MIN_LOGIN_RATE"] = 11.35
        
        self.dma_df.loc[((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["Strategic/FTU/Retail_OP"] == "FTU")), "MIN_LOGIN_RATE"] = 14.35
    
    def Removing_FTU_cases(self):
        temp = self.dma_df.loc[self.dma_df["Strategic/FTU/Retail_OP"]=="FTU"].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "FTU CASES"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df=self.dma_df.loc[(self.dma_df["Strategic/FTU/Retail_OP"]!="FTU")]
        
    def Removing_Connector(self):
        self.tagging = self.tagging[["AGREEMENTNO", "Chassis / Body / CE", "Category", "DSA/ Direct/ Connector", "State as per CB Product", "Novation Scheme Code", "Equipment","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)"]]
        self.dma_df = pd.merge(self.dma_df, self.tagging, on="AGREEMENTNO")
        temp = self.dma_df.loc[self.dma_df["DSA/ Direct/ Connector"]=="CONNECTOR"].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Connector CASES"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df=self.dma_df.loc[(self.dma_df["DSA/ Direct/ Connector"]!="CONNECTOR")]
        
    def execute(self):
        self.NewAndRefinanace()
        self.RemoveOtherThanA()
        self.RemoveValuesWithBranch_Direct()
        self.RemoveFromPromotionDescription()
        self.RemoveBasedOnTenure()
        self.RemoveOutsidePeriod()
        self.RBKCases()
        self.AddColumnBasedOnPromotionDesc()
        self.SetMinLoginRate()
        self.Removing_FTU_cases()
        self.Removing_Connector()
        
        