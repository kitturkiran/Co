import pandas as pd
import numpy as np
import math

def generateSummary(df:pd.DataFrame):
    
    df["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"]=df["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"].str.lower()
    df["To State ( Business Branch Location Captured)"]=df["To State ( Business Branch Location Captured)"].str.lower()
    grp = df.groupby(["DMA_BROKER_ID","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)","Product"])

    summary_df = pd.DataFrame(columns=["Broker ID","TYPE", "Dma Name", "Loan Amt", "Strategic Payout", "Retail Payout", "ADDTIONL PO", "TOTAL BOOSTER","CGST@4.5","CGST1@4.5","SGST@4.5",
                                       "SGST1@4.5","IGST@9","IGST1@9","Revised BOOSTER payout","Tds %",
                                       "Tds Amt","Final BOOSTER Payout","from location","To State"])

    for code, gdf in grp:
        temp = {}
        temp["Broker ID"] = [code[0]]
        # temp["State"] = [gdf["State as per CB Product"].iloc[0]]
        temp["TYPE"]=[gdf["Product"].iloc[0]]
        temp["Dma Name"] = [gdf["DMA_NAME"].iloc[0]]
        # temp["Count"] = [gdf.shape[0]]
        # temp["AMTFIN"] = [gdf["AMTFIN"].sum()]
        # temp["ADV_EMI"] = [gdf["ADVANCE_EMI"].sum()]
        temp["Loan Amt"] = [gdf["LOAN_AMT"].sum()]
        temp["Strategic Payout"] = [gdf["PO for Strategic"].sum()]
        temp["Retail Payout"] = [gdf["PO for Retails"].sum()]
        temp["ADDTIONL PO"] = [gdf["PO for Both"].sum()]
        # temp["retail_refinance_po"] = [gdf["RETAIL_REFINANCE_LAN_PO"].sum()]
        # temp["ftu_new_po"] = [gdf["FTU_NEW_LAN_PO"].sum()]
        # temp["ftu_refinance_po"] = [gdf["FTU_REFINANCE_LAN_PO"].sum()]
        # temp["retail_vol_po(NON FTU)"] = [gdf["RETAIL_VOL_PO"].sum()]
        # temp["retail_vol_po(FTU)"] = [gdf["FTU_VOL_PO"].sum()]
        # temp["startegic_vol_po"] = [gdf["STRATEGIC_VOL_PO"].sum()]
        # temp["BHL Crane Excavator PO"] = [gdf["Asset_PO"].sum()]
        # temp["Connector PO"] = [gdf["CONNECTOR PO"].sum()]
        # temp["Gross_payout"] = [gdf["PAYOUT"].sum()]
        # temp["Non PSL 0.10"] = [gdf["NON_PSL_Percentage"].sum()]
        # temp["Non PSL Cases 0.10 deducted"] = [gdf["NON_PSL_VALUE"].sum()]
        temp["TOTAL BOOSTER"] = [gdf["total_payout"].sum()]
        # temp["Payout 80%"]=0.0
        temp["CGST@4.5"]=0.0
        temp["CGST1@4.5"]=0.0
        temp["SGST@4.5"]=0.0
        temp["SGST1@4.5"]=0.0
        temp["IGST@9"]=0.0
        temp["IGST1@9"]=0.0
        temp["Revised BOOSTER payout"]=0.0
        temp["Tds %"]=5.0
        temp["Tds Amt"]=0.0
        # temp["Advance"]=0.0
        # temp["Pdd Debit"]=0.0
        # temp["Other Debit"]=0.0
        temp["Final BOOSTER Payout"]=0.0
        # temp["Payout 20%"]=0.0
        # temp["CGST0@4.5"]=0.0
        # temp["CGST01@4.5"]=0.0
        # temp["SGST0@4.5"]=0.0
        # temp["SGST01@4.5"]=0.0
        # temp["IGST0@9"]=0.0
        # temp["IGST01@9"]=0.0
        # temp["Revised Gross 20%"]=0.0
        # temp["Tds1 %"]=5.0
        # temp["20% Tds Amt"]=0.0
        # temp["Advance1"]=0.0
        # temp["Pdd Debit1"]=0.0
        # temp["Other Debit1"]=0.0
        # temp["Final 20% Payout"]=0.0
        # temp["Remarks"]=0.0
        # temp["Tds code"]=0.0
        # temp["SAP Vendor Code"]=0
        # temp["PAN"]=0
        # temp["ACCOUNT NO"]=0
        # temp["IFSC CODE"]=0
        # temp["Payout Mode"]=0    
        # temp["GL Code"]=0
        # temp["I Box ID"]=0
        # temp["I-Box Status"]=0
        # temp["Ref. No 80per"]=0
        # temp["Ref. No 20per"]=0
        temp["from location"]=[gdf["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"].iloc[0]]
        temp["To State"]=[gdf["To State ( Business Branch Location Captured)"].iloc[0]]
        # temp["RCM / NON RCM"]=0
        # temp["Cost C"]=0

        
        
        

        
        
        # temp["Payout 80%"] = (temp["final gross po"] *0.8)
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True) 
        # summary_df["Payout 80%"]=round(summary_df["final gross po"]*0.8)
        summary_df["CGST@4.5"]=round(((summary_df["TOTAL BOOSTER"]*4.5)/118),3)
        summary_df["CGST1@4.5"]=round(((summary_df["TOTAL BOOSTER"]*4.5)/118),3)
        summary_df["SGST@4.5"]=round(((summary_df["TOTAL BOOSTER"]*4.5)/118),3)
        summary_df["SGST1@4.5"]=round(((summary_df["TOTAL BOOSTER"]*4.5)/118),3)
        summary_df["checking"]=np.where(summary_df["from location"].str.lower()==summary_df["To State"].str.lower(),"True","False")
        summary_df.loc[summary_df["checking"]=="True","IGST@9"]=0
        summary_df.loc[summary_df["checking"]=="True","IGST1@9"]=0
        summary_df.loc[summary_df["checking"]=="False","IGST@9"]=round(((summary_df["TOTAL BOOSTER"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","IGST1@9"]=round(((summary_df["TOTAL BOOSTER"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","CGST@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","CGST1@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST1@4.5"]=0
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["CGST@4.5"]=round_up(row["CGST@4.5"])
            row["CGST1@4.5"]=round_up(row["CGST1@4.5"])
            row["SGST@4.5"]=round_up(row["SGST@4.5"])
            row["SGST1@4.5"]=round_up(row["SGST1@4.5"])
            row["IGST@9"]=round_up(row["IGST@9"])
            row["IGST1@9"]=round_up(row["IGST1@9"])

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)
        summary_df["Revised BOOSTER payout"]=((summary_df["TOTAL BOOSTER"])-(summary_df["CGST@4.5"]+summary_df["CGST1@4.5"]+summary_df["SGST@4.5"]+summary_df["SGST1@4.5"]+summary_df["IGST@9"]+summary_df["IGST1@9"]))
        summary_df["Tds Amt"]=round((summary_df["Revised BOOSTER payout"]*0.05),3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["Tds Amt"]=round_up(row["Tds Amt"])
 

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)        
        summary_df["Final BOOSTER Payout"]=((summary_df["Revised BOOSTER payout"])-(summary_df["Tds Amt"]))
        
        # summary_df["Payout 20%"]=round(summary_df["final gross po"]*0.2)
        # summary_df["CGST0@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        # summary_df["CGST01@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        # summary_df["SGST0@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        # summary_df["SGST01@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        # # summary_df["checking"]=np.where(summary_df["from location"].str.lower()==summary_df["To State"].str.lower(),"True","False")
        # summary_df.loc[summary_df["checking"]=="True","IGST0@9"]=0
        # summary_df.loc[summary_df["checking"]=="True","IGST01@9"]=0
        # summary_df.loc[summary_df["checking"]=="False","IGST0@9"]=round(((summary_df["Payout 20%"]*9.0)/118),3)
        # summary_df.loc[summary_df["checking"]=="False","IGST01@9"]=round(((summary_df["Payout 20%"]*9.0)/118),3)
        # summary_df.loc[summary_df["checking"]=="False","CGST0@4.5"]=0
        # summary_df.loc[summary_df["checking"]=="False","CGST01@4.5"]=0
        # summary_df.loc[summary_df["checking"]=="False","SGST0@4.5"]=0
        # summary_df.loc[summary_df["checking"]=="False","SGST01@4.5"]=0
        # def Round_off(row:pd.DataFrame):
            
        #     def round_up(n,decimals=0):
        #         multiplier=10**decimals
        #         return math.floor(n*multiplier + 0.5)/multiplier
            
        #     row["CGST0@4.5"]=round_up(row["CGST0@4.5"])
        #     row["CGST01@4.5"]=round_up(row["CGST01@4.5"])
        #     row["SGST0@4.5"]=round_up(row["SGST0@4.5"])
        #     row["SGST01@4.5"]=round_up(row["SGST01@4.5"])
        #     row["IGST0@9"]=round_up(row["IGST0@9"])
        #     row["IGST01@9"]=round_up(row["IGST01@9"])

        #     return row
        # summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)        
        # summary_df["Revised Gross 20%"]=round((summary_df["Payout 20%"])-((summary_df["CGST0@4.5"])+(summary_df["CGST01@4.5"])+(summary_df["SGST0@4.5"])+(summary_df["SGST01@4.5"])+(summary_df["IGST0@9"])+(summary_df["IGST01@9"])))
        # summary_df["20% Tds Amt"]=round((summary_df["Revised Gross 20%"]*0.05),3)
        # def Round_off(row:pd.DataFrame):
            
        #     def round_up(n,decimals=0):
        #         multiplier=10**decimals
        #         return math.floor(n*multiplier + 0.5)/multiplier
            
        #     row["20% Tds Amt"]=round_up(row["20% Tds Amt"])
 

        #     return row
        # summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)                

        # summary_df["Final 20% Payout"]=((summary_df["Revised Gross 20%"])-(summary_df["20% Tds Amt"]+summary_df["Advance1"]+summary_df["Pdd Debit1"]+summary_df["Other Debit1"]))
    return summary_df



    
def generateSummary1(df:pd.DataFrame):
    df=df[df["DSA/ Direct/ Connector"].str.lower()=="connector"]
    df["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"]=df["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"].str.lower()
    df["To State ( Business Branch Location Captured)"]=df["To State ( Business Branch Location Captured)"].str.lower()
        
    # df=df.drop(["VOL_LOAN_AMT","LAN_WISE_RATE","Total_Disbursement_Amount","VOL_WISE_RATE","STRATEGIC_NEW_LAN_PO","RETAIL_NEW_LAN_PO","FTU_NEW_LAN_PO","STRATEGIC_REFINANCE_LAN_PO","RETAIL_REFINANCE_LAN_PO","FTU_REFINANCE_LAN_PO","STRATEGIC_VOL_PO","RETAIL_VOL_PO","FTU_VOL_PO"],axis=1)
    grp = df.groupby(["DMA_BROKER_ID","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)","Product"])

    summary_df = pd.DataFrame(columns=["Broker", "State", "Count", "PRODUCT", "DMA_Name", "AMTFIN", "ADV_EMI", 
                                       "Net_loan", "Strategic_new_po", "Strategic_refinance_po", 
                                       "retail_new_po", "retail_refinance_po", "ftu_new_po", 
                                       "ftu_refinance_po", "retail_vol_po(NON FTU)", "retail_vol_po(FTU)", 
                                       "startegic_vol_po", "BHL Crane Excavator PO", "Connector PO", 
                                       "Gross_payout", "Non PSL 0.10", "Non PSL Cases 0.10 deducted", 
                                       "final gross po","Payout 80%","CGST@4.5","CGST1@4.5","SGST@4.5",
                                       "SGST1@4.5","IGST@9","IGST1@9","Revised Gross 80%","Tds %",
                                       "80% Tds Amt","Advance","Pdd Debit","Other Debit","Final 80% Payout",
                                       "Payout 20%","CGST0@4.5","CGST01@4.5","SGST0@4.5","SGST01@4.5",
                                       "IGST0@9","IGST01@9","Revised Gross 20%","Tds1 %","20% Tds Amt",
                                       "Advance1","Pdd Debit1","Other Debit1","Final 20% Payout",
                                       "Remarks","Tds code","SAP Vendor Code","PAN","ACCOUNT NO",
                                       "IFSC CODE","Payout Mode","GL Code","I Box ID","I-Box Status",
                                       "Ref. No 80per","Ref. No 20per","from location","To State","RCM / NON RCM","Cost C"])

    for code, gdf in grp:
        temp = {}
        temp["Broker"] = [code[0]]
        temp["State"] = [gdf["State as per CB Product"].iloc[0]]
        temp["DMA_Name"] = [gdf["DMA_NAME"].iloc[0]]
        temp["Product"]=[gdf["Product"].iloc[0]]
        temp["Count"] = [gdf.shape[0]]
        temp["AMTFIN"] = [gdf["AMTFIN"].sum()]
        temp["ADV_EMI"] = [gdf["ADVANCE_EMI"].sum()]
        temp["Net_loan"] = [gdf["LOAN_AMT"].sum()]
        temp["Strategic_new_po"] = [gdf["STRATEGIC_NEW_LAN_PO"].sum()]
        temp["Strategic_refinance_po"] = [gdf["STRATEGIC_REFINANCE_LAN_PO"].sum()]
        temp["retail_new_po"] = [gdf["RETAIL_NEW_LAN_PO"].sum()]
        temp["retail_refinance_po"] = [gdf["RETAIL_REFINANCE_LAN_PO"].sum()]
        temp["ftu_new_po"] = [gdf["FTU_NEW_LAN_PO"].sum()]
        temp["ftu_refinance_po"] = [gdf["FTU_REFINANCE_LAN_PO"].sum()]
        temp["retail_vol_po(NON FTU)"] = [gdf["RETAIL_VOL_PO"].sum()]
        temp["retail_vol_po(FTU)"] = [gdf["FTU_VOL_PO"].sum()]
        temp["startegic_vol_po"] = [gdf["STRATEGIC_VOL_PO"].sum()]
        temp["BHL Crane Excavator PO"] = [gdf["Asset_PO"].sum()]
        temp["Connector PO"] = [gdf["CONNECTOR PO"].sum()]
        temp["Gross_payout"] = [gdf["PAYOUT"].sum()]
        temp["Non PSL 0.10"] = [gdf["NON_PSL_Percentage"].sum()]
        temp["Non PSL Cases 0.10 deducted"] = [gdf["NON_PSL_VALUE"].sum()]
        temp["final gross po"] = [gdf["Final Payout"].sum()]
        temp["Payout 80%"]=0.0
        temp["CGST@4.5"]=0.0
        temp["CGST1@4.5"]=0.0
        temp["SGST@4.5"]=0.0
        temp["SGST1@4.5"]=0.0
        temp["IGST@9"]=0.0
        temp["IGST1@9"]=0.0
        temp["Revised Gross 80%"]=0.0
        temp["Tds %"]=5.0
        temp["80% Tds Amt"]=0.0
        temp["Advance"]=0.0
        temp["Pdd Debit"]=0.0
        temp["Other Debit"]=0.0
        temp["Final 80% Payout"]=0.0
        temp["Payout 20%"]=0.0
        temp["CGST0@4.5"]=0.0
        temp["CGST01@4.5"]=0.0
        temp["SGST0@4.5"]=0.0
        temp["SGST01@4.5"]=0.0
        temp["IGST0@9"]=0.0
        temp["IGST01@9"]=0.0
        temp["Revised Gross 20%"]=0
        temp["Tds1 %"]=5.0
        temp["20% Tds Amt"]=0.0
        temp["Advance1"]=0.0
        temp["Pdd Debit1"]=0
        temp["Other Debit1"]=0
        temp["Final 20% Payout"]=0.0
        temp["Remarks"]=0
        temp["Tds code"]=0
        temp["SAP Vendor Code"]=0
        temp["PAN"]=0
        temp["ACCOUNT NO"]=0
        temp["IFSC CODE"]=0
        temp["Payout Mode"]=0    
        temp["GL Code"]=0
        temp["I Box ID"]=0
        temp["I-Box Status"]=0
        temp["Ref. No 80per"]=0
        temp["Ref. No 20per"]=0
        temp["from location"]=[gdf["From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state"].iloc[0]]
        temp["To State"]=[gdf["To State ( Business Branch Location Captured)"].iloc[0]]
        temp["RCM / NON RCM"]=0
        temp["Cost C"]=0

        
        
        

        
        
        # temp["Payout 80%"] = (temp["final gross po"] *0.8)
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True) 
        summary_df["Payout 80%"]=round(summary_df["final gross po"]*0.8,3)
        summary_df["CGST@4.5"]=round(((summary_df["Payout 80%"]*4.5)/118),3)
        summary_df["CGST1@4.5"]=round(((summary_df["Payout 80%"]*4.5)/118),3)
        summary_df["SGST@4.5"]=round(((summary_df["Payout 80%"]*4.5)/118),3)
        summary_df["SGST1@4.5"]=round(((summary_df["Payout 80%"]*4.5)/118),3)
        summary_df["checking"]=np.where(summary_df["from location"].str.lower()==summary_df["To State"].str.lower(),"True","False")
        summary_df.loc[summary_df["checking"]=="True","IGST@9"]=0
        summary_df.loc[summary_df["checking"]=="True","IGST1@9"]=0
        summary_df.loc[summary_df["checking"]=="False","IGST@9"]=round(((summary_df["final gross po"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","IGST1@9"]=round(((summary_df["final gross po"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","CGST@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","CGST1@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST1@4.5"]=0
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["CGST@4.5"]=round_up(row["CGST@4.5"])
            row["CGST1@4.5"]=round_up(row["CGST1@4.5"])
            row["SGST@4.5"]=round_up(row["SGST@4.5"])
            row["SGST1@4.5"]=round_up(row["SGST1@4.5"])
            row["IGST@9"]=round_up(row["IGST@9"])
            row["IGST1@9"]=round_up(row["IGST1@9"])

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)        
        
        summary_df["Revised Gross 80%"]=((summary_df["Payout 80%"])-(summary_df["CGST@4.5"]+summary_df["CGST1@4.5"]+summary_df["SGST@4.5"]+summary_df["SGST1@4.5"]+summary_df["IGST@9"]+summary_df["IGST1@9"]))
        summary_df["80% Tds Amt"]=round((summary_df["Revised Gross 80%"]*0.05),3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["80% Tds Amt"]=round_up(row["80% Tds Amt"])
 

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)        
        
        summary_df["Final 80% Payout"]=((summary_df["Revised Gross 80%"])-(summary_df["80% Tds Amt"]+summary_df["Advance"]+summary_df["Pdd Debit"]+summary_df["Other Debit"]))
        
        summary_df["Payout 20%"]=round(summary_df["final gross po"]*0.2,3)
        summary_df["CGST0@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        summary_df["CGST01@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        summary_df["SGST0@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        summary_df["SGST01@4.5"]=round(((summary_df["Payout 20%"]*4.5)/118),3)
        # summary_df["checking"]=np.where(summary_df["from location"].str.lower()==summary_df["To State"].str.lower(),"True","False")
        summary_df.loc[summary_df["checking"]=="True","IGST0@9"]=0
        summary_df.loc[summary_df["checking"]=="True","IGST01@9"]=0
        summary_df.loc[summary_df["checking"]=="False","IGST0@9"]=round(((summary_df["final gross po"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","IGST01@9"]=round(((summary_df["final gross po"]*9.0)/118),3)
        summary_df.loc[summary_df["checking"]=="False","CGST0@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","CGST01@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST0@4.5"]=0
        summary_df.loc[summary_df["checking"]=="False","SGST01@4.5"]=0
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["CGST0@4.5"]=round_up(row["CGST0@4.5"])
            row["CGST01@4.5"]=round_up(row["CGST01@4.5"])
            row["SGST0@4.5"]=round_up(row["SGST0@4.5"])
            row["SGST01@4.5"]=round_up(row["SGST01@4.5"])
            row["IGST0@9"]=round_up(row["IGST0@9"])
            row["IGST01@9"]=round_up(row["IGST01@9"])

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)          
        
        
        summary_df["Revised Gross 20%"]=((summary_df["Payout 20%"])-((summary_df["CGST0@4.5"])+(summary_df["CGST01@4.5"])+(summary_df["SGST0@4.5"])+(summary_df["SGST01@4.5"])+(summary_df["IGST0@9"])+(summary_df["IGST01@9"])))
        summary_df["20% Tds Amt"]=round((summary_df["Revised Gross 20%"]*0.05),3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["20% Tds Amt"]=round_up(row["20% Tds Amt"])
 

            return row
        summary_df=summary_df.apply(lambda x:Round_off(x),axis=1)                        
        # summary_df["20% Tds Amt"]=round(summary_df["20% Tds Amt"])
        summary_df["Final 20% Payout"]=((summary_df["Revised Gross 20%"])-(summary_df["20% Tds Amt"]+summary_df["Advance1"]+summary_df["Pdd Debit1"]+summary_df["Other Debit1"]))
    return summary_df
