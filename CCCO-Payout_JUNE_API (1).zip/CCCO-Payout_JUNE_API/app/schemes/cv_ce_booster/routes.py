from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .data_calculation import DataCalculation
from .data_massaging import DataMassaging
from .po_summary import generateSummary
from .po_summary import generateSummary1
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil

cv_ce_router_booster = APIRouter()

@cv_ce_router_booster.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(dma: UploadFile, 
                                   tagging: UploadFile,
                                   booster: UploadFile,
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
        
    
    dma_df = pd.read_excel(dma.file.read())
    tagging_df = pd.read_excel(tagging.file.read())
    booster = pd.read_excel(booster.file.read())
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        
        obj1 = DataMassaging(dma_df, rejected_df,tagging_df,start_date,end_date)
        obj1.execute()

        data_calculation1 = DataCalculation(obj1.dma_df,tagging_df,obj1.rejection_df,booster)
        data_calculation1.execute() 
             
        # data_calculation1.rejected_df.to_excel("Rejected.xlsx")
        # data_calculation1.df.to_excel("output_Booster_CV_CE.xlsx")
        
        summary_df = generateSummary(data_calculation1.df)
        
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"cv_ce_dma_booster_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        data_calculation1.df.to_excel(writer, sheet_name="output_Booster_CV_CE", index=False)
        data_calculation1.rejected_df.to_excel(writer, sheet_name="Rejected", index=False)
        
        summary_df.to_excel(writer, sheet_name="Summary_CV_CE_BOOSTER", index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)


@cv_ce_router_booster.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/cv_ce_booster"
    destination_dir = f"./backup/CV_CE_BOOSTER/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"