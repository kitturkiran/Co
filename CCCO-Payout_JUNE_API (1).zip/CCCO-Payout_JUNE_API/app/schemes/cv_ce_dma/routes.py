from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .data_calculation import DataCalculation
from .data_massaging import DataMassaging
from .po_summary import generateSummary
from .po_summary import generateSummary1
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil

cv_ce_router = APIRouter()
print("hello")
@cv_ce_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(dma: UploadFile, 
                                   tagging: UploadFile,
                                   cncl:UploadFile,
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
        
    print("starting")
    dma_df = pd.read_excel(dma.file.read())
    tagging_df = pd.read_excel(tagging.file.read())
    cncl = pd.read_excel(cncl.file.read())
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        print("massaging")
        dm_obj = DataMassaging(dma_df, rejected_df,tagging_df, start_date, end_date)
        print("f")
        dm_obj.execute()
        print("Calculation")
        dc_obj = DataCalculation(dm_obj.dma_df, tagging_df, dm_obj.rejection_df,cncl)
        dc_obj.execute()
        
        summary_df = generateSummary(dc_obj.df)
        summary_df1 = generateSummary1(dc_obj.df)
        
        dc_obj.without_connector1=dc_obj.without_connector
        dc_obj.without_connector1.rename({"DMA_BROKER_ID":"Broker"},axis=1,inplace=True)
        dc_obj.without_connector1.rename({"From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state":"from location"},axis=1,inplace=True)
        dc_obj.without_connector1.rename({"To State ( Business Branch Location Captured)":"To State"},axis=1,inplace=True)
        dc_obj.without_connector1.rename({"Product":"Product"},axis=1,inplace=True)
        dc_obj.without_connector1["from location"]=dc_obj.without_connector1["from location"].str.lower()
        dc_obj.without_connector1["To State"]=dc_obj.without_connector1["To State"].str.lower()
        # summary_df=summary_df[["Ref No 80%","Ref No 20%","Broker","from location","To State","Product"]]
        summary_ref=pd.merge(dc_obj.without_connector1,summary_df[["Ref No 80%","Ref No 20%","Broker","from location","To State","Product"]],on=["Broker","from location","To State","Product"],how="left")
        
        
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"cv_ce_dma_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        dc_obj.without_connector.to_excel(writer, sheet_name="CV-CE-DMA_without_connector-Pay-Cases", index=False)
        dc_obj.with_connector.to_excel(writer, sheet_name="CV-CE-DMA_with_connector-Pay-Cases", index=False)
        
        dc_obj.rejected_df.to_excel(writer, sheet_name="Rejected", index=False)
        summary_df.to_excel(writer, sheet_name="Summary_without_connector", index=False)
        summary_df1.to_excel(writer, sheet_name="Summary_with_connector", index=False)
        summary_ref.to_excel(writer, sheet_name="Summary_without_ref_connector", index=False)
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)


@cv_ce_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/cv_ce_dma"
    destination_dir = f"./backup/CV_CE_DMA/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"