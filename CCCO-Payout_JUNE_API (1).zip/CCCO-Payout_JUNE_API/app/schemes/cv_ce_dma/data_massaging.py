from datetime import datetime
import pandas as pd

class DataMassaging:
    def __init__(self, df:pd.DataFrame, rejection_df:pd.DataFrame, tagging_df:pd.DataFrame,start_date, end_date):
        self.dma_df = df
        self.rejection_df = rejection_df
        self.startDate = start_date
        self.endDate = end_date
        self.tagging_df=tagging_df
        
    def merging_tagging(self):
        self.tagging_df = self.tagging_df[["AGREEMENTNO", "Chassis / Body / CE", "Category", "DSA/DDSA/CONNECTOR/DIRECT/BRANCH", "State as per CB Product", "Novation Scheme Code", "Equipment","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)"]]
        self.dma_df = pd.merge(self.dma_df, self.tagging_df, on="AGREEMENTNO",how="left")
    def NewAndRefinanace(self):
        temp = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == False) & (self.dma_df["AGREEMENTNO"].str.startswith(
            "UV") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "LAN not as per Process note"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == True) | (self.dma_df["AGREEMENTNO"].str.startswith(
            "UV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == True)]

        self.dma_df["NEW/REFINANCE_OP"] = ""
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("LV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == True), "NEW/REFINANCE_OP"] = "NEW"
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UV") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == True), "NEW/REFINANCE_OP"] = "REFINANCE"
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RemoveOtherThanA(self):
        temp = self.dma_df[self.dma_df["STATUS"] != 'A'].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Status Other Than A"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["STATUS"] == 'A']
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RemoveValuesWithBranch_Direct(self):
        temp = self.dma_df[(self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "DMA Name Contains BRANCH, DIRECT, MAGMA"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True))]
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RemoveFromPromotionDescription(self):
        temp = self.dma_df[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Promotion desc with values death of app / nabard subsidy"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy"))]
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RemoveBasedOnTenure(self):
        temp = self.dma_df[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18))].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "New Car Tenure <= 24/Refinance CV CE <= 18"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18)))]
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RemoveOutsidePeriod(self):
        self.dma_df["DISBURSALDATE"] = pd.to_datetime(self.dma_df["DISBURSALDATE"])
        temp = self.dma_df[(((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Outside the Period of Calculation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False))]
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])
    def RBKCases(self):
        temp = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "File No. Contain RBK"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk") == False]
        print(self.dma_df.shape[0])
        print(self.rejection_df.shape[0])    
    
    def Bodycases(self):
        self.dma_df.loc[self.dma_df["MODELNAME"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"
        self.dma_df.loc[self.dma_df["MAKE"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"

        self.dma_df.loc[self.dma_df["ASSET_CATG"].str.lower().str.contains("body")==True,"Chassis / Body / CE"]="Body"
        self.dma_df.loc[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("topup plus")==True,"top up cases"]="Top up plus"
        self.dma_df.loc[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("topup")==True,"Chassis / Body / CE"]="Top up"
        self.dma_df.loc[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("top up")==True,"Chassis / Body / CE"]="Top up"
        
        # Rejected_=self.dma_df[(self.dma_df["Chassis / Body / CE"].str.lower().str.contains("body") == True)]
       
        # Rejected_=pd.DataFrame(Rejected_)
       
        # Rejected_["Remark"]="BODY/TOP UP CASES"
        # self.rejection_df=pd.concat([Rejected_,self.rejection_df],ignore_index=False)
        
        # self.dma_df=self.dma_df[~(self.dma_df["Chassis / Body / CE"].str.lower().str.contains("body",na=False))]
       
        
        
    def RemovingTop_cases(self):
        Rejected_=self.dma_df[(self.dma_df["Chassis / Body / CE"].str.lower().str.contains("top up") == True)]
       
        Rejected_=pd.DataFrame(Rejected_)
        
        Rejected_["Remark"]="BODY/TOP UP CASES"
        self.rejection_df=pd.concat([Rejected_,self.rejection_df],ignore_index=False)
        
        self.dma_df=self.dma_df[~(self.dma_df["Chassis / Body / CE"].str.lower().str.contains("top up",na=False))]
    
    
    def execute(self):
        self.merging_tagging()
        self.NewAndRefinanace()
        self.RemoveOtherThanA()
        self.RemoveValuesWithBranch_Direct()
        self.RemoveFromPromotionDescription()
        self.RemoveBasedOnTenure()
        self.RemoveOutsidePeriod()
        self.RBKCases()
        self.Bodycases()
        # self.RemovingTop_cases()
        