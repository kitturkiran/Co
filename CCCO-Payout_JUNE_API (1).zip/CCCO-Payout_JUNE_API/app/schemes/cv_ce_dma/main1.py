import os
import pandas as pd
from data_calculation import DataCalculation
from po_summary import generateSummary,generateSummary1 
from data_massaging import DataMassaging



dma_df = pd.read_excel(r"D:\CV Dump\input\Dump.xlsx")
tagging_df=pd.read_excel(r"D:\CV Dump\input\Input Sheet.xlsx")
cancellation=pd.read_excel(r"D:\CV Dump\input\Case Cancellation CV CE DM.xlsx")

rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

obj1 = DataMassaging(dma_df, rejected_df,tagging_df,"1-05-2023","31-05-2023")
obj1.execute()

data_calculation1 = DataCalculation(obj1.dma_df,tagging_df,obj1.rejection_df,cancellation)
data_calculation1.execute()

data_calculation1.rejected_df.to_excel("CV_CE DMA_REJECTED_MAY2023.xlsx",index=False)
data_calculation1.with_connector.to_excel("CV_CE DMA_CONNECTOR_OUTPUT_MAY2023.xlsx",index=False)
data_calculation1.without_connector.to_excel("CV_CE DMA_WITHOUT_CONNECTOR_OUTPUT_MAY2023.xlsx",index=False)
summary_df = generateSummary(data_calculation1.df)
summary_df.to_excel("CV_CE DMA_WITHOUT_CONNECTOR_SUMMARY_MAY2023.xlsx",index=False)
summary_df1 = generateSummary1(data_calculation1.with_connector)
summary_df1.to_excel("CV_CE DMA_CONNECTOR_SUMMARY_MAY2023.xlsx",index=False)
data_calculation1.without_connector.rename({"DMA_BROKER_ID":"Broker"},axis=1,inplace=True)
data_calculation1.without_connector.rename({"From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state":"from location"},axis=1,inplace=True)
data_calculation1.without_connector.rename({"To State ( Business Branch Location Captured)":"To State"},axis=1,inplace=True)
data_calculation1.without_connector.rename({"PRODUCT":"Product"},axis=1,inplace=True)
data_calculation1.without_connector["from location"]=data_calculation1.without_connector["from location"].str.lower()
data_calculation1.without_connector["To State"]=data_calculation1.without_connector["To State"].str.lower()
# summary_df=summary_df[["Ref No 80%","Ref No 20%","Broker","from location","To State","Product"]]
summary_ref=pd.merge(data_calculation1.without_connector,summary_df[["Ref No 80%","Ref No 20%","Broker","from location","To State","Product"]],on=["Broker","from location","To State","Product"],how="left")
summary_ref.to_excel("CV_CE DMA_without_CONNECTOR_REF_SUMMARY_MAY2023.xlsx",index=False)
# 

