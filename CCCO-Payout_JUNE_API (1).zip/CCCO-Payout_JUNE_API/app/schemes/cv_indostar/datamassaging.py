from datetime import datetime
import pandas as pd
class Massaging:
    def __init__(self,df:pd.DataFrame,rejection,start_date,end_date):
        self.df=df
        self.rejection=rejection
        self.self.start_date = start_date
        self.self.end_date = end_date
        
    def Dateofreport(self):
        self.df["DATE_OF_REPORT"]=pd.to_datetime(self.df["DATE_OF_REPORT"])
        # self.start_date=datetime.strptime("1-05-2023","%d-%m-%Y")
        # self.end_date=datetime.strptime("31-05-2023","%d-%m-%Y")
        rejected=self.df.loc[(self.df["DATE_OF_REPORT"]<self.start_date) & (self.df["DATE_OF_REPORT"]>self.end_date)]["ICICI_LAN"]
        rejected=pd.DataFrame(rejected)
        rejected["REMARK"]="Out Of Date"
        self.rejection=pd.concat([rejected,self.rejection],ignore_index=True)
        self.df.loc[(self.df["DATE_OF_REPORT"]>=self.start_date) & (self.df["DATE_OF_REPORT"]<=self.end_date)]
        
        
        
    def Landuplication(self):
        rejected=self.df.loc[self.df["ICICI_LAN"].duplicated()]["ICICI_LAN"]
        rejected=pd.DataFrame(rejected)
        rejected["REMARK"]="Duplicate LAN"
        self.rejection=pd.concat([rejected,self.rejection],ignore_index=True)
        self.df=self.df[self.df["ICICI_LAN"].duplicated()==False] 
        
    def StatusotherA(self):
        rejected=self.df[self.df["LOAN_STATUS"]!="A"]["ICICI_LAN"]
        rejected=pd.DataFrame(rejected)
        rejected["REMARK"]="Status other than A"
        self.rejection=pd.concat([rejected,self.rejection],ignore_index=True)
        self.df=self.df[self.df["LOAN_STATUS"]=="A"]     
        
    def SchemeName(self):
        rejected=self.df[~(self.df["SCHEMEDESC"].str.lower().str.contains("indo"))]["ICICI_LAN"]
        rejected=pd.DataFrame(rejected)
        rejected["REMARK"]="INDO star case"
        self.rejection=pd.concat([rejected,self.rejection],ignore_index=True)
        self.df=self.df[self.df["SCHEMEDESC"].str.lower().str.contains("indo")] 
        
    def execute(self):
        self.StatusotherA()
        self.Landuplication()
        self.Dateofreport()   
        self.SchemeName()
        