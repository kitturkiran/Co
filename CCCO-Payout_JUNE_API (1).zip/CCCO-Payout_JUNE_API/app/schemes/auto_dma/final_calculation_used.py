from pandas import DataFrame
import math

def finalRateCalculation(row : DataFrame):

    if(row["Override Rate"] > 0):
        row["Final Rate"] = row["Override Rate"]
    else:
        row["Final Rate"] = row["Base Rate"]
    
    row["rate_sum of Base_rate and reduction_rate"]=row["Base Rate"] - row["Reduction In Rate"]
    row["rate_sum of Override_rate and reduction_rate"]=row["Override Rate"] - row["Reduction In Rate"]
    # if((row["rate_sum of Base_rate and reduction_rate"]==0)):
    #     row["Addition In Rate"]=0
    if((row["rate_sum of Base_rate and reduction_rate"]==0) & (row["Override Rate"]==0)):    
        row["Special_Rate"]=0
    if((row["Base Rate"]==0)&(row["Override Rate"]==0)):
        row["Special_Rate"]=0
        

    # row["rate_sum of Base_rate and reduction_rate"]=row["Base Rate"] - row["Reduction In Rate"]
    # row["rate_sum of Override_rate and reduction_rate"]=row["Override Rate"] - row["Reduction In Rate"]
    row["Final Rate"] = row["Final Rate"] - row["Reduction In Rate"] + row["Addition In Rate"] +row["Special_Rate"] - row["special Reduction"]- row["special Reduction1"]
    if(row["Remark "]=="PO Rate"):
        row["Final Rate"] = row["Po rate"]
    # if(row["Remark "]=="PO rate / PAN India business to be considered payout"):
    #     row["Final Rate"] = row["Po rate"]    
    # Po rate
    if(row["Po rate"]=="Kerala Used car Branch cases - 0.75% of loan amount or Rs 10000/- whichever is lesser"):
        row["Final Rate"] = 0.0075
    if(row["Po rate"]=="Kerala RXLG cases Seema branch, Pls check Note"):
            row["Final Rate"] = 0.0075
    if(row["Remark "]=="RXLG cases"):
        row["Final Rate"] = row["Po rate"]
    if(row["Remark "]=="RXLG cases / PAN India business to be considered payout"):
        row["Final Rate"]=0.01
    # if((row["rate_sum of Base_rate and reduction_rate"]==0)):
    #     row["Addition In Rate"]=0
    #     row["Special_Rate"]=0
    if(row["Remark "]=="PO rate / PAN India business to be considered payout"):
        if(row["Po rate"]>0):
            
            row["Final Rate"]=0.0025
    if(row["Final Rate"]<0):
        row["Final Rate"] = 0
    # if(row["Remark "]=="PO Rate"):
    #     row["Final Rate"] = row["Po rate"]
    if((row["AGREEMENTNO"]=="LUJAI00047150459")|(row["AGREEMENTNO"]=="SPJAI00047150486")):
        row["Final Rate"]=0.03

    return row

def payoutCalculation(row:DataFrame):
    if(row["Remark "]=="PO rate"):
        row["Final Rate"] = row["Po rate"]
    
    def round_up(n,decimals=0):
        multiplier=10**decimals
        return math.floor(n*multiplier + 0.5)/multiplier
    # row["Payout"] = round_up((row["Final Rate"]*row["Final Net Loan"]),1)
    row["Payout"] = (row["Final Rate"]*row["Final Net Loan"])
    row["Payout"]=round(row["Payout"],3)
    row["Payout"]=round_up(row["Payout"])
    
    # rate=row["Payout"]
    # decimals=0
    # multiplier=10**decimals
    # rate=math.floor(((rate*multiplier) + 0.5)/multiplier)
    # row["Payout"]=rate
    
    if ((row["Po rate"]=="Kerala Used car Branch cases - 0.75% of loan amount or Rs 10000/- whichever is lesser") & (row["Payout"]>10000)):
        row["Payout"]=10000
    # row["Payout"]=round(row["Payout"])
    if ((row["Remark "]=="RXLG cases") & (row["Payout"]>25000)):
        row["Payout"]=25000
    if ((row["Remark "]=="RXLG cases / PAN India business to be considered payout") & (row["Payout"]>25000)):
        row["Payout"]=25000
    
    # def round_up(n,decimals=0):
    #     multiplier=10**decimals
    #     return math.floor(n*multiplier + 0.5)/multiplier
    
    # row["Payout"]=round_up(row["Payout"])
    return row

def executeCalculation(df:DataFrame):
    df = df.apply(lambda x : finalRateCalculation(x), axis=1)
    df = df.apply(lambda x : payoutCalculation(x), axis=1)
    return df
