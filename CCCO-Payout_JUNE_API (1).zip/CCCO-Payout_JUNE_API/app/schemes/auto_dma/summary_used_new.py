import pandas as pd
import numpy as np
import math
def summary_used_new(df:pd.DataFrame):
    
    # df=pd.merge(df,cf[["Ref No","Canacellation"]],on="Ref No",how="left")
    # df["CNCL"]=df["Canacellation"]
    df["CNCL"].fillna(0,inplace=True)
    df["GROSS PAYOUT"]=df["TOTAL PAYOUT"]-df["ADVN"]-df["CNCL"]
    df["CGST@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["CGST_1@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["SGST@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["SGST_1@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["checking"]=np.where(df["FROM LOCATION"].str.lower()==df["TO LOCATION"].str.lower(),"True","False")
    df.loc[df["checking"]=="True","IGST@9"]=0
    df.loc[df["checking"]=="True","IGST_1@9"]=0
    df.loc[df["checking"]=="False","IGST@9"]=(((df["GROSS PAYOUT"]*9.0)/118))
    df.loc[df["checking"]=="False","IGST_1@9"]=(((df["GROSS PAYOUT"]*9.0)/118))
    df.loc[df["checking"]=="False","CGST@4.5"]=0
    df.loc[df["checking"]=="False","CGST_1@4.5"]=0
    df.loc[df["checking"]=="False","SGST@4.5"]=0
    df.loc[df["checking"]=="False","SGST_1@4.5"]=0
    def rounding(row: pd.DataFrame):
        def round_up(n,decimals=0):
    
            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
                
        row["CGST@4.5"]=round(row["CGST@4.5"],3)
        row["CGST@4.5"]=round_up(row["CGST@4.5"])
        row["CGST_1@4.5"]=round(row["CGST_1@4.5"],3)
        row["CGST_1@4.5"]=round_up(row["CGST_1@4.5"])
        row["SGST@4.5"]=round(row["SGST@4.5"],3)
        row["SGST@4.5"]=round_up(row["SGST@4.5"])
        row["SGST_1@4.5"]=round(row["SGST_1@4.5"],3)
        row["SGST_1@4.5"]=round_up(row["SGST_1@4.5"])
        row["IGST@9"]=round(row["IGST@9"],3)
        row["IGST@9"]=round_up(row["IGST@9"])
        row["IGST_1@9"]=round(row["IGST_1@9"],3)
        row["IGST_1@9"]=round_up(row["IGST_1@9"])
        return row
        
    
    df=df.apply(lambda x :rounding(x),axis=1)
    df["REVISEDGROSSPO"]=((df["GROSS PAYOUT"])-(df["CGST@4.5"]+df["CGST_1@4.5"]+df["SGST@4.5"]+df["SGST_1@4.5"]+df["IGST@9"]+df["IGST_1@9"]))
    df["TDSAmount"]=((df["REVISEDGROSSPO"]*0.05))
    def rounding1(row):
        def round_up(n,decimals=0):
        
            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
                
        row["TDSAmount"]=round(row["TDSAmount"],3)
        row["TDSAmount"]=round_up(row["TDSAmount"])
        return row
    df=df.apply(lambda x:rounding1(x),axis=1)
    df["NetPayout"]=(df["REVISEDGROSSPO"]-df["TDSAmount"])
    df["FINALPAYOUTS"]=((df["NetPayout"])-(df["ADVN2"]+df["CNCL2"]+df["PDD"]+df["OTHERDEBITS"]))    
    df.drop(columns="Amount",inplace=True)

    return df

def summary_used_new1(newCar:pd.DataFrame,usedCar:pd.DataFrame,cf: pd.DataFrame):
    # dict={}
    # lst=cf["Code"].tolist()
    # lst1=cf["Debit Amount"].tolist()
    # for i in lst:
    #     for j in lst1:
    #         dict[i]=j
    
    # dict.popitem()
    # def CNCL(row:pd.DataFrame):
    #     for i in lst:
    #         if (row["DMABROKERCODE"]==i):
    #             if (row["TOTAL PAYOUT"]>dict[i]):
    #                 row["GROSS PAYOUT"]=row["TOTAL PAYOUT"]-dict[i]
    #             else:
    #                 # row["GROSS PAYOUT"]=row["TOTAL PAYOUT"]-dict[i]
    #                 dict[i]=dict[i]-row["TOTAL PAYOUT"]
    #                 row["GROSS PAYOUT"]=0
                
    #     return row  
            
    # df=df.apply(lambda x : CNCL(x),axis=1)
    # return df
    
                
# summary_used_new1(dma_df,CNCL)
    new_used=pd.concat([newCar,usedCar],ignore_index=True)
    cf.rename(columns={"Broker ID":"DMABROKERCODE_y"},inplace=True)
    new_used=pd.merge(new_used,cf[["DMABROKERCODE_y","Debit Amt"]],on="DMABROKERCODE_y",how="left")
    new_used["Debit Amt"].fillna(0, inplace=True)

    df=pd.DataFrame(columns=["DMABROKERCODE","MONTH","NARRATION","Ref No","CAR TYPE","DMA_NAME","AMTFIN","NETLOAN","TOTAL PAYOUT","ADVN","CNCL","GROSS PAYOUT","Recovery","CGST@4.5","CGST_1@4.5","SGST@4.5","SGST_1@4.5","IGST@9","IGST_1@9","REVISEDGROSSPO","TDSRATE","TDSAmount","NetPayout","ADVN2","CNCL2","PDD","OTHERDEBITS","FINALPAYOUTS","REMARKS","TDSCODE","DMA VENDOR CODE","DMA PO BRANCH","DMA PAN","DMA ACCNO","DMA IFSC Code","DMA MODE OF PAYMENT","IBOX_IBOXID","IBOX_IBOXSTATUS","FROM LOCATION","TO LOCATION","RCM/Non RCM","Channel GST"])
    grf=new_used.groupby(["DMABROKERCODE_y"])
    for code, gdf in grf:
        temp = {}
        temp["DMABROKERCODE"]=[code]
        temp["MONTH"]="FEB -23"
        temp["NARRATION"]="AUTO DMA NEW CAR POFEB23"
        temp["Ref No"]=""
        temp["CAR TYPE"]="NEW"
        temp["DMA_NAME"]=[gdf["NAME"].iloc[0]]
        temp["AMTFIN"]=[gdf["AMTFIN"].sum()]
        temp["NETLOAN"]=[gdf["Final Net Loan"].sum()]
        temp["TOTAL PAYOUT"]=[gdf["Payout"].sum()]
        temp["ADVN"]=0.0
        temp["CNCL"]=[gdf["Debit Amt"].iloc[0]]
        temp["GROSS PAYOUT"]=0.0
        temp["Recovery"]=0.0
        temp["CGST@4.5"]=0.0
        temp["CGST_1@4.5"]=0.0
        temp["SGST@4.5"]=0.0
        temp["SGST_1@4.5"]=0.0
        temp["IGST@9"]=0.0
        temp["IGST_1@9"]=0.0
        temp["REVISEDGROSSPO"]=0.0
        temp["TDSRATE"]=5
        temp["TDSAmount"]=0.0
        temp["NetPayout"]=0.0
        temp["ADVN2"]=0.0
        temp["CNCL2"]=0.0
        temp["PDD"]=0.0
        temp["OTHERDEBITS"]=0.0
        temp["FINALPAYOUTS"]=0.0
        temp["REMARKS"]=""
        temp["TDSCODE"]=""
        temp["DMA VENDOR CODE"]=""
        temp["DMA PO BRANCH"]=[gdf["BRANCHNM"].iloc[0]]
        temp["DMA PAN"]=""
        temp["DMA ACCNO"]=""
        temp["DMA IFSC Code"]=""
        temp["DMA MODE OF PAYMENT"]=""
        temp["IBOX_IBOXID"]=""
        temp["IBOX_IBOXSTATUS"]=""
        temp["FROM LOCATION"]=[gdf["GST State From"].iloc[0]]
        temp["TO LOCATION"]=[gdf["GST State To"].iloc[0]]
        temp["RCM/Non RCM"]=""
        temp["Channel GST"]=""
        
        temp = pd.DataFrame(temp)
        df = pd.concat([df, temp], ignore_index=True) 
        # def round_up(n,decimals=0):

        #     multiplier=10**decimals
        #     return math.floor(n*multiplier + 0.5)/multiplier
    # df.loc[(df["DMABROKERCODE"].duplicated()==True),"CNCL"]=0
    df["GROSS PAYOUT"]=df["TOTAL PAYOUT"]-df["ADVN"]-df["CNCL"]
    df["CGST@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["CGST_1@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["SGST@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["SGST_1@4.5"]=(((df["GROSS PAYOUT"]*4.5)/118))
    df["checking"]=np.where(df["FROM LOCATION"].str.lower()==df["TO LOCATION"].str.lower(),"True","False")
    df.loc[df["checking"]=="True","IGST@9"]=0
    df.loc[df["checking"]=="True","IGST_1@9"]=0
    df.loc[df["checking"]=="False","IGST@9"]=(((df["GROSS PAYOUT"]*9.0)/118))
    df.loc[df["checking"]=="False","IGST_1@9"]=(((df["GROSS PAYOUT"]*9.0)/118))
    df.loc[df["checking"]=="False","CGST@4.5"]=0
    df.loc[df["checking"]=="False","CGST_1@4.5"]=0
    df.loc[df["checking"]=="False","SGST@4.5"]=0
    df.loc[df["checking"]=="False","SGST_1@4.5"]=0
    df["REVISEDGROSSPO"]=((df["GROSS PAYOUT"])-(df["CGST@4.5"]+df["CGST_1@4.5"]+df["SGST@4.5"]+df["SGST_1@4.5"]+df["IGST@9"]+df["IGST_1@9"]))
    df["TDSAmount"]=((df["REVISEDGROSSPO"]*0.05))
    df["NetPayout"]=(df["REVISEDGROSSPO"]-df["TDSAmount"])
    df["FINALPAYOUTS"]=((df["NetPayout"])-(df["ADVN2"]+df["CNCL2"]+df["PDD"]+df["OTHERDEBITS"]))
    def rounding(row:pd.DataFrame):
        def round_up(n,decimals=0):

            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
        row["CGST@4.5"]=round(row["CGST@4.5"],3)
        row["CGST@4.5"]=round_up(row["CGST@4.5"])
        row["CGST_1@4.5"]=round(row["CGST_1@4.5"],3)
        row["CGST_1@4.5"]=round_up(row["CGST_1@4.5"])
        row["SGST@4.5"]=round(row["SGST@4.5"],3)
        row["SGST@4.5"]=round_up(row["SGST@4.5"])
        row["SGST_1@4.5"]=round(row["SGST_1@4.5"],3)
        row["SGST_1@4.5"]=round_up(row["SGST_1@4.5"])
        row["IGST@9"]=round(row["IGST@9"],3)
        row["IGST@9"]=round_up(row["IGST@9"])
        row["IGST_1@9"]=round(row["IGST_1@9"],3)
        row["IGST_1@9"]=round_up(row["IGST_1@9"])
        row["REVISEDGROSSPO"]=round(row["REVISEDGROSSPO"],3)
        row["REVISEDGROSSPO"]=round_up(row["REVISEDGROSSPO"])
        row["TDSAmount"]=round(row["TDSAmount"],3)
        row["TDSAmount"]=round_up(row["TDSAmount"])
        row["NetPayout"]=round(row["NetPayout"],3)
        row["NetPayout"]=round_up(row["NetPayout"])
        row["FINALPAYOUTS"]=round(row["FINALPAYOUTS"],3)
        row["FINALPAYOUTS"]=round_up(row["FINALPAYOUTS"])
        return row
    df = df.apply(lambda x : rounding(x), axis=1)
    df.loc[df["GROSS PAYOUT"]<0,"Recovery"]=df["TOTAL PAYOUT"]
    df.loc[df["GROSS PAYOUT"]<0,"GROSS PAYOUT"]=0
    df.loc[df["GROSS PAYOUT"]<0,"TOTAL PAYOUT"]=0
    
    # df.loc=df[(df["DMABROKERCODE"].duplicated()==True),"CNCL"]=0
    return df
    
    
    
                
                
    
    
    