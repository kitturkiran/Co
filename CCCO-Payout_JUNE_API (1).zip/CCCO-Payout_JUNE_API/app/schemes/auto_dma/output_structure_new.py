from pandas import DataFrame
from datetime import datetime


class OutputStructure1:
    def __init__(self, df: DataFrame):
        self.df = df

    def addStructure(self, car_type: str):
        self.df["Net Loan"] = 0
        self.df["Auto Type"] = car_type
        self.df["MANF_BAND"] = ""
        self.df["Final Net Loan"] = 0
        self.df["Total Applicable Disbursement"] = 0
        self.df["WIRR"] = 0
        self.df["AMTFIN*PRETAXIRR"] = 0
        self.df["Asset Insurance charge ID- 500080"].fillna(0, inplace=True)
        self.df["Asset Insurance PO "].fillna("Yes", inplace=True)
        self.df["Po rate"].fillna(-1, inplace=True)
        self.df["CHANNELCODE"].fillna("-", inplace=True)
        self.df["PROMOTIONSCHEME"].fillna("-", inplace=True)
        self.df["Nill_Payout_Remark"] = False
        self.df["alto_cases"] = 0
        self.df["PROCHANNEL"] = "-"
        self.df["TotalPF"] = 0
        self.df["Base Rate"] = 0
        self.df["Override Rate"] = 0
        self.df["Reduction In Rate"] = 0
        self.df["Addition In Rate"] = 0
        self.df["Addition In PO"] = 0 # for gst, etc
        self.df["Final Rate"] = 0
        self.df["Payout"] = 0
        self.df["Salaried"].fillna("-", inplace=True)
        self.df["SELF EMPLOYED"].fillna("-", inplace=True)
        self.df["Override Remark"] = '-'
        self.df["AUTO DEBIT "].fillna("-", inplace=True)
        self.df["MANUFACTURERDESC"].fillna("-", inplace=True)
        self.df.loc[(self.df["Po rate"] == "INFINIUM MOTORS PVT LTD PO already processed"), "Po rate"] = -1
        self.df.loc[(self.df["Po rate"]=="PAN India business to be considered payout"),"Po rate"]=-1
        # self.df.loc[(self.df["Po rate"]=="Str upto 1st Apr  to 14th Apr 23 to be applied"),"Po rate"]=-1
        self.df["DISB_DATE1"]=self.df["DISB_DATE"]
        phase_date1 = datetime.strptime("10-04-2023", "%d-%m-%Y")
        self.df.loc[(self.df["Po rate"]=="Str upto 1st Apr  to 14th Apr 23 to be applied"),"DISB_DATE"]=phase_date1
        self.df.loc[(self.df["Po rate"]=="Str upto 1st Apr  to 14th Apr 23 to be applied"),"Po rate"]=-1
        self.df.loc[(self.df["Po rate"] == "Not a deemed demo case ( mail Praveen  R -08-02-23  4.15Pm)"), "Po rate"] = -1
        self.df.loc[(self.df["MAKE"].str.lower().str.contains("alto",na=False)),"alto_cases"]=1
        self.df.loc[(self.df["MAKE"].str.lower().str.contains("celerio",na=False)),"alto_cases"]=1
        self.df.loc[(self.df["MAKE"].str.lower().str.contains("s-presso",na=False)),"alto_cases"]=1
        self.df.loc[(self.df["MAKE"].str.lower().str.contains("wagon r",na=False)),"alto_cases"]=1
        phase_date = datetime.strptime("10-03-2023", "%d-%m-%Y")
        self.df["CHANNELCODE1"]=self.df["CHANNELCODE"]
        self.df.loc[(self.df["CHANNELCODE"].str.lower().str.contains("pragati")==False) & (self.df["CHANNELCODE"].str.lower().str.contains("ftu")==False) & (self.df["CHANNELCODE"].str.lower().str.contains("stp")==False) & (self.df["CHANNELCODE"].str.lower().str.contains("alpa")==False) & (self.df["CHANNELCODE"].str.lower().str.contains("pa_")==False),"CHANNELCODE1"]="NO"
        # self.df.loc[(self.df["DISB_DATE"]>phase_date)&(self.df["CHANNELCODE"].str.lower().str.contains("aip")),"CHANNELCODE1"]="AIP"
        self.df.loc[(self.df["CHANNELCODE"]=="AUTO-AGRI PRODUCT"),"CHANNELCODE1"]="pragati"
        # self.df.loc[(self.df["CHANNELCODE"]=="AIP_PRAGATI"),"CHANNELCODE1"]="pragati"
        self.df.loc[(self.df["DISB_DATE"]>=phase_date)&(self.df["CHANNELCODE"]=="AUTO - ASSESSED INCOME PRODUCT"),"CHANNELCODE1"]="pragati"
        self.df.loc[(self.df["CHANNELCODE"].str.lower().str.contains("auto special scheme-kerala")),"CHANNELCODE1"]="pragati"
        return self.df
