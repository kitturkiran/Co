from pandas import DataFrame


class OutputStructure:
    def __init__(self, df: DataFrame):
        self.df = df

    def addStructure(self, car_type: str):
        self.df["Temp_State"]=""
        self.df["Net Loan"] = 0
        self.df["Auto Type"] = car_type
        self.df["Base Rate"] = 0
        self.df["Override Rate"] = 0
        self.df["Reduction In Rate"] = 0
        self.df["Addition In Rate"] = 0
        self.df["Addition In PO"] = 0 # for gst, etc
        self.df["rate_sum of Base_rate and reduction_rate"]=0
        self.df["rate_sum of Override_rate and reduction_rate"]=0
        self.df["Special_Rate"]=0
        self.df["special Reduction"]=0
        self.df["special Reduction1"]=0
        self.df["MANF_BAND"] = ""
        self.df["Final Net Loan"] = 0
        self.df["Total Applicable Disbursement"] = 0
        self.df["WIRR"] = 0
        self.df["AMTFIN*PRETAXIRR"] = 0
        self.df["Asset Insurance charge ID- 500080"].fillna(0, inplace=True)
        self.df["Asset Insurance PO "].fillna("Yes", inplace=True)
        self.df["Po rate"].fillna(0, inplace=True)
        self.df["CHANNELCODE"].fillna("-", inplace=True)
        self.df["PROMOTIONSCHEME"].fillna("-", inplace=True)
        self.df["Final Rate"] = 0
        self.df["Payout"] = 0
        self.df["Salaried"].fillna("-", inplace=True)
        self.df["SELF EMPLOYED"].fillna("-", inplace=True)
        self.df["Override Remark"] = '-'

        self.df["PROCHANNEL"] = "-"
        self.df["TotalPF"] = 0
        
        self.df.loc[(self.df["Po rate"] == "As per grid"), "Po rate"] = 0
        return self.df
