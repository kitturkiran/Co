import os
import pandas as pd
from .data_manipulation import DataManipulation
from .final_calculation_used import executeCalculation
from .final_calculation_new import executeCalculationNew,executeCalculationNew_INFINIUM
from .output_init_used import OutputInit
from .output_init_new import OutputInit1
from .output_structure_used import OutputStructure
from .output_structure_new import OutputStructure1
from .new_car.grid.override import executeNew
from .used_car.grid.override import execute
from .data_split_used import DataSplit
from .data_split_new import DataSplit1
from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
from datetime import datetime
from fastapi.background import BackgroundTasks
import shutil
from .summary_used_new import summary_used_new
from .summary_new import generateSummary
from .summary_old import generateSummary1
from .summary_used_new_cncl import summary_cncl

Auto_Dma=APIRouter()
@Auto_Dma.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(dma: UploadFile,
                                   tagging: UploadFile,
                                   cncl:UploadFile,
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
    
    
    dma_df = pd.read_excel(dma.file.read())
    tagging_file=tagging.file.read()
    cncl=pd.read_excel(cncl.file.read())
    tagging_new_df = pd.read_excel(tagging_file,sheet_name="New")
    tagging_used_df=pd.read_excel(tagging_file,sheet_name="Used")
    
    try:
        print("hello")
        dataManipulationObj = DataManipulation(dma_df,start_date,end_date)
        cleanedDF = dataManipulationObj.executeCleaning()
        
        dataSplitObj1 = DataSplit1(cleanedDF, tagging_new_df, tagging_used_df)
        dataSplitObj1.executePreparation()
        dataSplitObj = DataSplit(cleanedDF, tagging_new_df, tagging_used_df)
        dataSplitObj.executePreparation()



        # # For New Car
        opObj = OutputStructure1(dataSplitObj1.newCar)
        newCar = opObj.addStructure("New Car")
        print("kiran")
        finalObj = OutputInit1(newCar)
        newCar = finalObj.executeFinalOutput()
        
        newCar = executeNew(newCar)
        print("caculated started")
        newCar = executeCalculationNew(newCar)
        print("completed Calculation")
        summary_new=generateSummary(newCar)
        
        

        

        # Used Car
        print(1)
        opObj = OutputStructure(dataSplitObj.usedCar)
        usedCar = opObj.addStructure("Old Car")
        print(2)
        finalObj = OutputInit(usedCar)
        usedCar = finalObj.executeFinalOutput()

        usedCar = execute(usedCar)
        usedCar = executeCalculation(usedCar)
        summary_used=generateSummary1(usedCar)
        print(3)
        used_new=pd.concat([summary_new,summary_used],ignore_index=True)
        used_new.insert(0,"Ref No",range(30001,30001+used_new.shape[0]))
        used_new["Ref No"]=used_new["Ref No"].apply(lambda x:"AUDM052"+str(x))
        print(used_new)
        summary_cncl1=summary_cncl(used_new,cncl)
        print("kiran")
        summary_used_new1=summary_used_new(summary_cncl1)
        print(5)

    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"Auto_Dma_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        newCar.to_excel(writer, sheet_name="NEW", index=False)
        
        usedCar.to_excel(writer, sheet_name="Used", index=False)
        
        summary_used_new1.to_excel(writer,sheet_name="summary_new_used",index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)
    
@Auto_Dma.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/Auto_dma scheme 1"
    destination_dir = f"./backup/Auto_dma scheme 1/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"   