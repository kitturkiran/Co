import pandas as pd

def summary_cncl(df:pd.DataFrame,cf:pd.DataFrame):
    cf.rename(columns={"Code":"DMABROKERCODE"},inplace=True)
    cf.rename(columns={"Sum of Dr Amt. ":"Amount"},inplace=True)
    # cf.rename(columns={"Sum of Dr Amt.":"Amount"},inplace=True)
    df=pd.merge(df,cf[["DMABROKERCODE","Amount"]],on="DMABROKERCODE",how="left")
    temp=cf["DMABROKERCODE"].to_list()
    temp1=cf["Amount"].to_list()
    dit={"Code":"Amount"}
    for i in range(0,len(temp1)):
        dit[temp[i]]=temp1[i]
    df=df.apply(lambda row: cancel(row,dit,temp),axis=1)
    df["CNCL"]=df["Amount"]
    # df.drop(columns="Amount",inplace=True)
    return df
    



def cancel(row,dit,temp):
        for code in temp:
            if(row["DMABROKERCODE"]==code):
                if(row["GROSS PAYOUT"]>dit[code]):


                    row["GROSS PAYOUT"]=row["GROSS PAYOUT"]-dit[code]
                    # row["Final Payout"]=dit[code]-row["Final Payout"]
                    # dit[code]=0
                    row["Amount"]=dit[code]
                    dit[code]=0
            
                else:
                    # row["Final Payout"]=0
                    dit[code]=dit[code]-row["GROSS PAYOUT"]
                    row["Amount"]=row["GROSS PAYOUT"]
                    row["GROSS PAYOUT"]=0

        return row
    