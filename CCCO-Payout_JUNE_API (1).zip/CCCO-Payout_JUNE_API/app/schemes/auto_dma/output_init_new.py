import pandas as pd


class OutputInit1:
    def __init__(self, df: pd.DataFrame):
        self.df = df

    def updateTopTier(self):
        self.df.loc[((self.df["Consolidated State for Po processing"].str.lower() == "delhi") | (self.df["Consolidated State for Po processing"].str.lower() == "delhi ncr") | (self.df["Consolidated State for Po processing"].str.lower() == "mumbai") | (self.df["Consolidated State for Po processing"].str.lower() == "gujarat") | (self.df["Consolidated State for Po processing"].str.lower(
        ) == "pune") | (self.df["Consolidated State for Po processing"].str.lower() == "bangalore") | (self.df["Consolidated State for Po processing"].str.lower() == "hyderabad") | (self.df["Consolidated State for Po processing"].str.lower() == "chennai")), ["Top/TierII"]] = "Top"

    def updateManfBrand(self):
        condition = (self.df['MANUFACTURERDESC'].str.lower().str.contains("maruti") | self.df['MANUFACTURERDESC'].str.lower().str.contains("hyundai") | self.df['MANUFACTURERDESC'].str.lower().str.contains("tata") | self.df['MANUFACTURERDESC'].str.lower().str.contains("honda") | self.df['MANUFACTURERDESC'].str.lower(
        ).str.contains("toyota") | self.df['MANUFACTURERDESC'].str.lower().str.contains("ford") | self.df['MANUFACTURERDESC'].str.lower().str.contains("fca") | self.df['MANUFACTURERDESC'].str.lower().str.contains("fiat") | self.df['MANUFACTURERDESC'].str.lower().str.contains("jeep"))

        self.df.loc[condition, "MANF_BAND"] = "A"
        self.df.loc[~condition, "MANF_BAND"] = "B"

    def addNetLoan(self):
        self.df["Net Loan"] = (self.df["AMTFIN"] -
                               self.df["ADVANCE_EMI"]) * self.df["flag"]

    def updateFinalNetLoan(self):
        condition = self.df["Asset Insurance PO "] == "No"
        self.df.loc[(condition), "Final Net Loan"] = (
            self.df["Net Loan"] - self.df["Asset Insurance charge ID- 500080"])
        self.df.loc[(~condition), "Final Net Loan"] = self.df["Net Loan"]

    def updateAMTFINPRETAXIRR(self):
        self.df["AMTFIN*PRETAXIRR"] = self.df["AMTFIN"] * self.df["PRETAXIRR"]

    def applicableState(self):
        self.df["Temp_State"] = self.df["Consolidated State for Po processing"]
        self.df.loc[(self.df["Consolidated State for Po processing"].isin(["Delhi", "Noida", "Gurgaon"])), "Temp_State"] = "Delhi"
        self.df.loc[(self.df["Consolidated State for Po processing"].isin(["Haryana", "Punjab","HP","J&K"])), "Temp_State"] = "Haryana"
        self.df.loc[(self.df["Sourcing"].str.lower() == "aggregator"), "Temp_State"] = "Aggregator"

    def updateTotalDisbursementAmount(self):
        self.applicableState()
        gp = self.df.groupby(['DMABROKERCODE_y', 'Temp_State'])["AMTFIN"].sum().reset_index()
        print(gp)
        for row in range(gp.shape[0]):
            temp = gp.iloc[row, :]
            code = temp["DMABROKERCODE_y"]
            state = temp["Temp_State"]
            total_disb = temp["AMTFIN"]
            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (
                self.df["Temp_State"] == state), "Total Applicable Disbursement"] = total_disb
            
        gp3 = self.df.groupby(['DMABROKERCODE_y'])["AMTFIN"].sum().reset_index()

        # for row in range(gp3.shape[0]):
        #     temp = gp3.iloc[row, :]
        #     code = temp["DMABROKERCODE_y"]
        #     # state = temp["Temp_State"]
        #     total_disb = temp["AMTFIN"]
        #     self.df.loc[(self.df["DMABROKERCODE_y"] == 271169), "Total Applicable Disbursement"] = total_disb
            # if (self.df["DMABROKERCODE_y"]==271169):
            #     self.df.loc["Total Applicable Disbursement"]=self.df["AMTFIN"].sum()
            
            # self.df.loc[(self.df["DMABROKERCODE_y"] == 271169), "Total Applicable Disbursement"] = total_disb
            
        self.groupingBroker(gp)
        # self.groupingBroker1(gp)
        # self.SpecialBrokerCase()

    # def SpecialBrokerCase(self):
    #     gp = self.df.groupby("DMABROKERCODE_y")
    #     for code , grp_df in gp:
    #         if(code == 275078):
    #             self.df.loc[(self.df["DMABROKERCODE_y"] == 275078), "Total Applicable Disbursement"] = grp_df["AMTFIN"].sum()
    
    def groupingBroker1(self, gp: pd.DataFrame):
        broker = [
            [164897, 101402, 245024],
            # [172023, 101696],
            [173974, 177945],
            # [104566, 173503, 179283, 215034, 191433],
            [272355, 181343],
            # [106746, 266367],
            [177591, 270686, 311146],
            [239294, 173193],
        ]

        for i in range(len(broker)):
            sum = 0
            for j in range(len(broker[i])):
                temp = gp.loc[(gp["DMABROKERCODE_y"] == broker[i][j]) & (
                    gp["Temp_State"].str.lower() == "mumbai")]["AMTFIN"]
                if(len(temp.values) > 0):
                    sum += temp.values[0]

            for j in range(len(broker[i])):
                self.df.loc[((self.df["DMABROKERCODE_y"] == broker[i][j]) & (
                    (self.df["Temp_State"].str.lower() == "mumbai"))), "Total Applicable Disbursement"] = sum    
    
    
    
    
    def groupingBroker(self, gp: pd.DataFrame):
        broker = [
            [230164, 227613, 163891],
            [272355, 181343],
            [104566, 173503, 179283, 261656, 218674],
            [235320, 191433, 273843, 234376],
            [104755, 112362, 244216],
            [106746, 266367, 101696],
            [256601, 209562],
            # [188805, 287945],
        ]

        for i in range(len(broker)):
            sum = 0
            for j in range(len(broker[i])):
                temp = gp.loc[(gp["DMABROKERCODE_y"] == broker[i][j]) & (
                    gp["Temp_State"].str.lower() == "mumbai")]["AMTFIN"]
                if(len(temp.values) > 0):
                    sum += temp.values[0]

            for j in range(len(broker[i])):
                self.df.loc[((self.df["DMABROKERCODE_y"] == broker[i][j]) & (
                    (self.df["Temp_State"].str.lower() == "mumbai"))), "Total Applicable Disbursement"] = sum
        # if(self.df["DMABROKERCODE_y"] in [188805,287945]):
        # tad=self.df.loc[(self.df["Temp_State"].str.lower() == "delhi") & (self.df["DMABROKERCODE_y"].isin([188805,287945]))]["AMTFIN"].sum()
        # self.df.loc[self.df["DMABROKERCODE_y"].isin([188805,287945])&((self.df["Temp_State"].str.lower() == "delhi")),"Total Applicable Disbursement"]=tad
        # for i in range(len(broker)):
        #     sum = 0
        #     for j in range(len(broker[i])):
        #         temp = gp.loc[(gp["DMABROKERCODE_y"] == broker[i][j]) & (
        #             gp["Consolidated State for Po processing"].str.lower() == "gurgaon")]["AMTFIN"]
        #         if(len(temp.values) > 0):
        #             sum += temp.values[0]

        #     for j in range(len(broker[i])):
        #         self.df.loc[((self.df["DMABROKERCODE_y"] == broker[i][j]) & (
        #             (self.df["Consolidated State for Po processing"].str.lower() == "gurgaon"))), "Total Applicable Disbursement"] = sum

    def updateWIRR(self):
        gp = self.df.groupby(['DMABROKERCODE_y', 'Consolidated State for Po processing'])[
            "AMTFIN*PRETAXIRR"].sum().reset_index()

        for row in range(gp.shape[0]):
            temp = gp.iloc[row, :]
            code = temp["DMABROKERCODE_y"]
            state = temp["Consolidated State for Po processing"]
            result = temp["AMTFIN*PRETAXIRR"]

            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (
                self.df["Consolidated State for Po processing"] == state), "WIRR"] = (result / self.df["Total Applicable Disbursement"])

    def processProchannel(self):
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("inbt")), "PROCHANNEL"] = "inbt"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("external")), "PROCHANNEL"] = "external"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("internal")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("top")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("max")), "PROCHANNEL"] = "maxx"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("max")), "PROCHANNEL"] = "maxx"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("refinance")), "PROCHANNEL"] = "refinance"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("eclgs")), "PROCHANNEL"] = "eclgs"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("insta")), "PROCHANNEL"] = "insta"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("external")), "PROCHANNEL"] = "external"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("internal")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("refinance")), "PROCHANNEL"] = "refinance"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("eclgs")), "PROCHANNEL"] = "eclgs"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("INTopup")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["CHANNELCODE"].str.lower().str.contains("intopup")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-'), "PROCHANNEL"] = "sale purchase"
        self.df.loc[(self.df["PROCHANNEL"].str.lower().str.contains("insta")), "PROCHANNEL"] = "topup"
        # tad=self.df.loc[(self.df["Consolidated State for Po processing"].str.lower() == "delhi") & (self.df["DMABROKERCODE_y"].isin([287945]))]["AMTFIN"].sum()
        # self.df.loc[self.df["DMABROKERCODE_y"].isin([287945])&((self.df["Consolidated State for Po processing"].str.lower() == "delhi")),"Total Applicable Disbursement"]=tad
        tad=self.df.loc[(self.df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (self.df["DMABROKERCODE_y"].isin([188805,287945]))]["AMTFIN"].sum()
        self.df.loc[self.df["DMABROKERCODE_y"].isin([188805,287945])&((self.df["Consolidated State for Po processing"].str.lower() == "gurgaon")),"Total Applicable Disbursement"]=tad
        # tad=self.df.loc[(self.df["Consolidated State for Po processing"].str.lower() == "delhi") & (self.df["DMABROKERCODE_y"].isin([188805]))]["AMTFIN"].sum()
        # self.df.loc[self.df["DMABROKERCODE_y"].isin([188805])&((self.df["Consolidated State for Po processing"].str.lower() == "delhi")),"Total Applicable Disbursement"]=tad
        
        
    def processTotalPF(self):
        gp = self.df.groupby(['DMABROKERCODE_y',"Temp_State"])[
            ["AMTFIN", "PROCESSINGFEE"]].sum().reset_index()

        for row in range(gp.shape[0]):
            temp1 = gp.iloc[row, :]
            pf = temp1["PROCESSINGFEE"]
            amt = temp1["AMTFIN"]
            code = temp1["DMABROKERCODE_y"]
            state=temp1["Temp_State"]
            if(pf== 0):
                self.df.loc[(self.df["DMABROKERCODE_y"] == code)&(self.df["Temp_State"] ==state), "TotalPF"] = 0
            else:
                self.df.loc[(self.df["DMABROKERCODE_y"] == code)&(self.df["Temp_State"] ==state),"TotalPF"]= round(((pf/amt) * 100), 2)
                
    def changesFromTagging(self):
        # self.df.loc[(self.df["Po rate"].str.lower() == "po as of dec 6th to be applied"), "DISB_DATE"] = pd.to_datetime("2022/12/06", format="%Y/%m/%d")
        self.df.loc[(self.df["Po rate"].str.lower() == "po as of dec 6th to be applied"), "Po rate"] = -1
        self.df.loc[(self.df["Po rate"].str.lower() == "infinium motors pvt ltd  payout already processed"), "Po rate"] = 0
        self.df.loc[(self.df["Po rate"].str.lower() == "as per kerala grid"), "Po rate"] = -1
        self.df.loc[(self.df["Po rate"].str.lower() == "pan india business to be considered payout"), "Po rate"] = -1
        

    def executeFinalOutput(self):
        # self.updateTopTier()
        self.updateManfBrand()
        self.addNetLoan()
        self.updateFinalNetLoan()
        self.updateAMTFINPRETAXIRR()
        self.updateTotalDisbursementAmount()
        self.updateWIRR()
        self.processProchannel()
        self.processTotalPF()
        # self.changesFromTagging()
        return self.df
