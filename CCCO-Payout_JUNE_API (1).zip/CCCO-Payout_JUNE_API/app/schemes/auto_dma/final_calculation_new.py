from pandas import DataFrame
import math

def finalRateCalculation(row : DataFrame):
    if(row["Po rate"] != -1):
        
        row["Final Rate"] = row["Po rate"]
    else:
        if(row["Override Rate"] > 0):
            row["Final Rate"] = (row["Override Rate"] - row["Reduction In Rate"] + row["Addition In Rate"])
        else:
            row["Final Rate"] = (row["Base Rate"] - row["Reduction In Rate"] + row["Addition In Rate"])
        
    if(row["Final Rate"] < 0):
        row["Final Rate"] = 0
    # if(row["DMABROKERCODE_y"]==104980):
    #     row["Final Rate"] = 0
        

    return row

def payoutCalculation(row:DataFrame):
    row["Payout"] = row["Final Rate"] * row["Final Net Loan"]
    
    def round_up(n,decimals=0):
        multiplier=10**decimals
        return math.floor(n*multiplier + 0.5)/multiplier
    row["Payout"]=round(row["Payout"],3)
    row["Payout"]=round_up(row["Payout"])
    return row

def executeCalculationNew(df:DataFrame):
    
    df = df.apply(lambda x : finalRateCalculation(x), axis=1)
    df = df.apply(lambda x : payoutCalculation(x), axis=1)
    return df

def executeCalculationNew_INFINIUM(df:DataFrame):
    df=df[(df["DMABROKERCODE_y"]==104980)]
    

    return df