import pandas as pd


class DataSplit1:

    def __init__(self, cleanedDF: pd.DataFrame, tagging_df_new: pd.DataFrame, tagging_df_used: pd.DataFrame):
        self.cleanedDF = cleanedDF
        self.tagging_df_new = tagging_df_new
        self.tagging_df_used = tagging_df_used
        
        self.newCar = None
        self.usedCar = None


    def split(self):
        condition = self.cleanedDF["AGREEMENTNO"].str.startswith("LA") == True
        self.newCar = self.cleanedDF[condition]
        self.usedCar = self.cleanedDF[~condition]

    def mergeTagging(self):
        self.tagging_df_new = self.tagging_df_new[["AGREEMENTNO","GST State From", "GST State To", "DMABROKERCODE", "TENURE", "Irr roundup", "Asset Insurance charge ID- 500080", "Asset Insurance PO ", "Po rate", "Segment","Salaried", "SELF EMPLOYED", "Sourcing", "Consolidated State for Po processing", "EV Band","Top/TierII", "Remark ", "AUTO DEBIT ","Latest Zone"]]
        self.tagging_df_used = self.tagging_df_used[["AGREEMENTNO","GST State From", "GST State To", "DMABROKERCODE", "TENURE", "Irr roundup", "Asset Insurance charge ID- 500080", "Asset Insurance PO ", "Po rate", "Segment","Salaried", "SELF EMPLOYED", "Sourcing", "Consolidated State for Po processing","EV Band", "Top/TierII", "Remark ", "AUTO DEBIT ","Latest Zone"]]
        self.newCar = pd.merge(self.newCar, self.tagging_df_new, on="AGREEMENTNO")
        self.usedCar = pd.merge(self.usedCar, self.tagging_df_used, on="AGREEMENTNO")

    def executePreparation(self):
        self.split()
        self.mergeTagging()
        
