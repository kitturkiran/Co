import pandas as pd
from datetime import datetime
def override31A(row:pd.DataFrame):
    phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] <= phase_date):
        return row
    # state_list = ["mumbai", "pune", "romg"] #ROMG is present in grid but don't know the meaning
    irr = row["Irr roundup"]

    # if(row["Consolidated State for Po processing"].lower() not in state_list):
    #     return row

    if((row["DMABROKERCODE_y"] == 101402) & (row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd")):
        if(irr < 9.10):
            return row
        rate = row["Override Rate"]
        # if row['Total Applicable Disbursement'] <= 10000000:
        if(irr < 9.20):
                rate = 0.0125
        elif(irr < 9.30):
                rate = 0.0150
        elif(irr < 9.45):
                rate = 0.0175
        else:
                rate = 0.0200
                
        if(row["TotalPF"] < 0.40):
                row["Reduction In Rate"] =+ 0.001

        row["Override Rate"] = rate
        row["Override Remark"] += "31A, "


    return row