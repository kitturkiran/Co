import pandas as pd
from datetime import datetime

def override29(row: pd.DataFrame):
    broker_codes = [112416, 170419, 162025, 175957, 195738, 244693, 286699, 222554, 289566, 272274, 273069, 265328, 
                    267036, 108210]
    phase_date = datetime.strptime("11-10-2022", "%d-%m-%Y")
    
    if(row["DISB_DATE"] >= phase_date):
        if((row["Consolidated State for Po processing"].lower() == "ap/rotg") & (row["DMABROKERCODE_y"] in broker_codes) & 
        (row["TENURE_y"] >= 39)):
            irr = row["Irr roundup"]
            segment = row["Segment"]
            
            if((irr >= 8.10) & (segment == "A+")):
                row["Override Rate"] = 0.0075
                row["Override Remark"] += "29, "
                   
            if((irr >= 8.25) & (segment in ["A+", "A", "C"])):
                row["Override Rate"] = 0.0115
                row["Override Remark"] += "29, "
                
            if((irr >= 8.35) & (segment in  ["A+", "A", "C", "B+", "B"])):
                row["Override Rate"] = 0.0125
                row["Override Remark"] += "29, "
        
    return row