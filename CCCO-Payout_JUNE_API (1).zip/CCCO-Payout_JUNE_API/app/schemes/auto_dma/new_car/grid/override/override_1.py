from pandas import DataFrame
from datetime import datetime

def override1(row: DataFrame):
    phase_date = datetime.strptime("16-10-2022", "%d-%m-%Y")
    if(row["DISB_DATE"] > phase_date):
        return row

    if(row["Irr roundup"] >= 8.10):
        if(row["TENURE_y"] >= 37):
            if((row["SELF EMPLOYED"].lower() == "yes") | (row["Salaried"].lower() == "yes")):
                if(row["Base Rate"] < 0.0050) & (row["Override Rate"] < 0.0050):
                    row["Reduction In Rate"]  = 0
                    row["Override Rate"] = 0.0050
                    row["Override Remark"] += "one, "
   
    return row