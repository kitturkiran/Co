import pandas as pd

def override17(row: pd.DataFrame):
    broker_code = 266366
    consol_states = ["delhi", "gurgaon", "noida"]
    if((row["DMABROKERCODE_y"] == broker_code) & (row["Consolidated State for Po processing"].lower() in consol_states)):
        if(row["Irr roundup"] >= 8.25):
            row["Override Rate"] = 0.0135
            row["Override Remark"] += "17, "
        
    return row