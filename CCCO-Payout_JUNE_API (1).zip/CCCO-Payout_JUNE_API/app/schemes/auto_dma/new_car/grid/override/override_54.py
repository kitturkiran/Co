import pandas as pd

def override54(row: pd.DataFrame):
    broker_codes = [198344,
                    189067,
                    145293,
                    244287,
                    180355,
                    180410,
                    182170,
                    184461,
                    210113,
                    271384,
                    184924,
                    185496,
                    273007,
                    272651,
                    183849,
                    307873,
                    112261,
                    247479,
                    307251,
                    175384,
                    175119,
                    245566,
                    244282,
                    359166,
                    161623,
                    166253,
                    166257,
                    ]
    segments=["A","B+","B","C"]
    if((row["DMABROKERCODE_y"] in broker_codes) & (row["Consolidated State for Po processing"].lower() == "gujarat")):
        segment=row["Segment"]
        if (segment in segments):
            row["Reduction In Rate"] += 0.0040
            row["Override Remark"] += "54, "
        
    return row