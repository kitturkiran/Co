import pandas as pd

def override46(row: pd.DataFrame):
    broker_codes = {
        182592: "agra",
        184853: "aligarh",
        249529: "aligarh",
        196891: "aligarh",
        299145: "aligarh",
        195740: "mathura",
        289291: "mathura",
        308840: "aligarh",
        196656: "agra",
        304426: "agra",
        248767: "agra",
        267124: "agra",
        267042: "agra",
        290490: "agra",
        299206: "mathura",
        248044: "agra",
        260997: "agra",
        182245: "agra",
        253232: "aligarh",
        294014: "aligarh",
    }
    
    
    if(row["DMABROKERCODE_y"] in broker_codes.keys()):
        if(row["BRANCHNM"].lower() == broker_codes[row["DMABROKERCODE_y"]]):
            row["Reduction In Rate"] += 0.0050
            row["Override Remark"] += "46, "
        
    return row