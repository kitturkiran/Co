import pandas as pd
from datetime import datetime
def override59(row:pd.DataFrame):
    # phase_date = datetime.strptime("21-04-2023", "%d-%m-%Y")

    # if(row["DISB_DATE"] <= phase_date):
    #     return row

    if((row["Temp_State"].lower() == "delhi") & (row["TENURE_y"]>=36) & (row["TENURE_y"]<=60) ):
        product = ["safari", "grand vitara", "verna", "hycross", "hyryder","xuv 700"]

        car_make = row["MAKE"].lower()
        irr = row["Irr roundup"]
        # for item in product:
        if(("safari" in car_make)|("grand vitara" in car_make)|("verna" in car_make)|("hycross" in car_make)|("hyryder" in car_make)|("xuv 700" in car_make)):
                if(irr >= 9.00):
                    row["Base Rate"] = max(0.01,row["Base Rate"])

                    row["Override Remark"] += "59, "
                    
        # if(("urban cruiser" in car_make)|("glanza" in car_make)):
        #     if(irr >= 9.10):
        #         row["Override Rate"] = 0.0100
        #         if (row["Override Rate"]>0):
        #             row["Addition In Rate"] = (row["Override Rate"] * 0.09)
        #         # row["Addition In Rate"] = (row["Override Rate"] * 0.09)
        #         row["Override Remark"] += "34, "

    return row