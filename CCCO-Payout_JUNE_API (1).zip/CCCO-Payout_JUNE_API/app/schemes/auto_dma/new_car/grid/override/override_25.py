import pandas as pd
from datetime import datetime
def override25(row: pd.DataFrame):
    broker_codes = [104755, 112362, 244216]
    # phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] <= phase_date):
        
    # if((row["Consolidated State for Po processing"].lower() == "mumbai") & (row["DMABROKERCODE_y"] in broker_codes) & 
    #     (row["Total Applicable Disbursement"] >= 30000000)):
    #         segment = row["Segment"]
    #         irr = row["Irr roundup"]
            
    #         if(segment == "A+"):
    #             if(irr >= 8.95):
    #                 row["Override Rate"] = 0.0165
    #                 row["Override Remark"] += "25, "
    #             elif(irr >= 8.85):
    #                 row["Override Rate"] = 0.0140
    #                 row["Override Remark"] += "25, "
    #             elif(irr >= 8.75):
    #                 row["Override Rate"] = 0.0100
    #                 row["Override Remark"] += "25, "
            
    #         elif(segment in ["A", "B+", "B", "C"]):
    #             if(irr >= 9.10):
    #                 row["Override Rate"] = 0.0200
    #                 row["Override Remark"] += "25, "
    #             elif(irr >= 8.95):
    #                 row["Override Rate"] = 0.0165
    #                 row["Override Remark"] += "25, "
    #             elif(irr >= 8.85):
    #                 row["Override Rate"] = 0.0140
    #                 row["Override Remark"] += "25, "
    #         if(row["TotalPF"] < 0.40):
    #             row["Reduction In Rate"] =+ 0.001
    #             # row["Override Remark"] += "25, "
                
    #         if(row["TotalPF"] < 0.40):
    #             row["Reduction In Rate"] =+ 0.001
    # else:
    if((row["Consolidated State for Po processing"].lower() == "mumbai") & (row["DMABROKERCODE_y"] in broker_codes) & 
        (row["Total Applicable Disbursement"] >= 30000000)):
            segment = row["Segment"]
            irr = row["Irr roundup"]
            
            if(segment == "A+"):
                if(irr>=9.00):
                    row["Override Rate"] = 0.0150
                    row["Override Remark"] += "25, "
                    
                elif(irr >= 8.95):
                    row["Override Rate"] = 0.0140
                    row["Override Remark"] += "25, "
                elif(irr >= 8.90):
                    row["Override Rate"] = 0.0125
                    row["Override Remark"] += "25, "
                elif(irr >= 8.85):
                    row["Override Rate"] = 0.0100
                    row["Override Remark"] += "25, "
            
            elif(segment in ["A", "B+", "B", "C"]):
                if(irr >= 9.20):
                    row["Override Rate"] = 0.0200
                    row["Override Remark"] += "25, "
                elif(irr >= 9.10):
                    row["Override Rate"] = 0.0165
                    row["Override Remark"] += "25, "
                elif(irr >= 9.00):
                    row["Override Rate"] = 0.0140
                    row["Override Remark"] += "25, "
            
            if(row["TotalPF"] < 0.40):
                row["Reduction In Rate"] =+ 0.001
                    
            
        
                
    return row