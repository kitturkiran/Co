import pandas as pd

def override42(row: pd.DataFrame):
    broker_codes = [
                    359057,
                    190099,
                    184793,
                    261406,
                    268182,
                    145857,
                    258293,
                    364626,
                    367557,
                    380623,
                    191667,
                    227511,
                    285522,
                    257546,
                    384177,
                    202105,
                    202106,
                    298776,
                    289350,
                    104381,
                    101900,
                    164968,
                    101650,
                    261561,
                    376823,
                    316159,
                    310068,

                    ]
    
    if((row["DMABROKERCODE_y"] in broker_codes) & (row["Consolidated State for Po processing"].lower() == "roka")):
        row["Reduction In Rate"] += 0.0035
        row["Override Remark"] += "42, "
        
    return row