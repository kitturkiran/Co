import pandas as pd

def override5(row: pd.DataFrame):
    broker_list = [262816, 268259]

    type1_make = ["seltos", "carnival", "sonnet", "innova", "hector", "safari", "harrier", "city", "creta"]
    
    type2_make = ["i20", "venue", "thar", "nexon", "xuv 300", "magnite"]

    type1_rate = 7.65
    type2_rate = 7.80

    type2_rate_grid = {
        "loan_min": [0, 800000, 1600000],
        "loan_max": [800000, 1600000, 4000000],
        "rate": [8.40, 8.25, 8.00]
    }
    type2_rate_grid = pd.DataFrame(type2_rate_grid)

    condition1 = (row["DMABROKERCODE_y"] == broker_list[0])
    condition2 = (row["DMABROKERCODE_y"] == broker_list[1])

    if condition1 or condition2:
        row["Reduction In Base Rate"] = 0
        flag1, flag2 = False, False
        for i in range(len(type1_make)):
            if type1_make[i].lower() in row.loc["MAKE"].lower() and row.loc["Irr roundup"] >= type1_rate:
                flag1 = True

        for i in range(len(type2_make)):
            if type2_make[i].lower() in row.loc["MAKE"].lower() and row.loc["Irr roundup"] >= type2_rate:
                flag2 = True

        if flag1:
                special = 0.0025
                row["Override Remark"]+="overide5,"

        elif flag2:
            for i in range(type2_rate_grid.shape[0]):
                if (type2_rate_grid.loc[i, "loan_min"] <= row.loc["Final Net Loan"] < type2_rate_grid.loc[i, "loan_max"]) and (row.loc["Irr roundup"] >= type2_rate_grid.loc[i, "rate"]):
                    special = 0.0025
                    row["Override Remark"]+="overide5,"
                    break

            if row.loc["Final Net Loan"] >= 4000000 and (7.80 <= row.loc["Irr roundup"] < 8.00):
                special = 0.0025
                row["Override Remark"]+="overide5,"

        if ("stp" in row.loc["CHANNELCODE"].lower() or "alpa" in row.loc["CHANNELCODE"].lower() or " pa_" in row["CHANNELCODE"].lower()) and row.loc["Irr roundup"] >= 7.60:
            special = max(0.0025, special)
            row["Override Remark"]+="overide5,"
        
        row.loc["Special Rate"] = special
        
    return row