import pandas as pd

def override16(row: pd.DataFrame):
    broker_codes = [266407, 267866, 112416, 289524, 108210, 283989, 267867, 230252, 269283, 311945, 292700, 
                    209399, 220857, 273451, 244693, 240130, 107309, 158383, 168661, 195738, 284051, 310767, 
                    292510, 303325, 291326, 304928, 183665, 101761]
    
    if((row["Consolidated State for Po processing"].lower() == "hyderabad") & (row["DMABROKERCODE_y"] in broker_codes) & 
       (row["TENURE_y"] >= 36)):
        grid = {
            "rate_min": [8.00, 8.10, 8.25, 8.50, 8.60, 8.80, 9.00, 8.10, 8.25, 8.50, 8.60, 8.80, 9.00, 8.25, 8.50, 8.60, 8.80, 9.00],
            "rate_max": [8.10, 8.25, 8.50, 8.60, 8.80, 9.00, 101, 8.25, 8.50, 8.60, 8.80, 9.00, 101, 8.50, 8.60, 8.80, 9.00, 101],
            "payout": [0.75, 1.15, 1.25, 1.35, 1.45, 1.55, 1.65, 1.15, 1.25, 1.35, 1.45, 1.55, 1.65, 1.25, 1.35, 1.45, 1.55, 1.65],
            "segment": [1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
        }
        
        grid = pd.DataFrame(grid)
        
        irr = row["Irr roundup"]
        
        segment = {
            "A+": 1,
            "A": 2,
            "C": 2,
            "B+": 3,
            "B": 3
        }
        
        po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["payout"]
        
        if(po.shape[0] != 0):
            row["Override Rate"] = (float(po) / 100)
            row["Override Remark"] += "16, "
        else:
            row["Override Rate"] = 0
            row["Override Remark"] += "16, "
            
        if(("alpa" in row['CHANNELCODE'].lower()) | ("stp" in row['CHANNELCODE'].lower()) | ("pa" in row['CHANNELCODE'].lower())):
            if(irr >= 8.00):
                if(0.0075 > row["Override Rate"]):
                    row["Override Rate"] = 0.0075
                    row["Override Remark"] += "16, "
        
    return row