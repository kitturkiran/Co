from datetime import datetime
import pandas as pd

def override57(row: pd.DataFrame):

    
    # if(row["Consolidated State for Po processing"].lower() != "bangalore"):
    #     return row

    broker_list = 237744
    if((row["DMABROKERCODE_y"]==broker_list) & (row["Consolidated State for Po processing"] == "Kolkata")):
        if ((row["Irr roundup"]>=9.00) & (row["Total Applicable Disbursement"]>=10000000)):
            
            row["Override Rate"] = 0.00170
            row["Override Remark"] += "57, "

    return row   