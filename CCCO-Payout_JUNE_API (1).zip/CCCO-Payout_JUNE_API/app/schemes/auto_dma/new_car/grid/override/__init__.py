import pandas as pd

from .override_1 import override1
from .override_2 import override2
from .override_3 import override3
from .override_4 import override4
from .override_5 import override5
from .override_6 import override6
from .override_7 import override7
from .override_8 import override8
from .override_9 import override9
from .override_10 import override10
from .override_11 import override11
from .override_12 import override12
from .override_13 import override13
from .override_14 import override14
from .override_15 import override15
from .override_16 import override16
from .override_17 import override17
from .override_18 import override18
from .override_19 import override19
from .override_20 import override20
from .override_21 import override21
from .override_22 import override22
from .override_23 import override23
from .override_24 import override24
from .override_25 import override25
from .override_26 import override26
from .override_27 import override27
from .override_28 import override28
from .override_29 import override29
from .override_30 import override30
from .override_31 import override31
from .override_32 import override32
from .override_33 import override33
from .override_34 import override34
from .override_35 import override35
from .override_36 import override36
from .override_37 import override37
from .override_38 import override38
from .override_39 import override39
from .override_40 import override40
from .override_41 import override41
from .override_42 import override42
from .override_43 import override43
from .override_44 import override44
from .override_45 import override45
from .override_46 import override46
from .override_47 import override47
from .override_48 import override48
from .override_49 import override49
from .override_50 import override50
from .override_51 import override51
from .override_52 import override52
from .override_53 import override53
from .override_54 import override54
from .override_57 import override57
from .override_59 import override59
from .override_22A import override22A
from .override_24A import override24A
from .override_31A import override31A
from .override_60 import override60
from .override_61 import override61

from ..base_grid.base_grid_phase1 import BaseGridPhase1
from ..base_grid.base_grid_phase2 import BaseGridPhase2


def executeNew(df: pd.DataFrame):
    # Applying base grid
    # df = df.apply(lambda x: BaseGridPhase1(x), axis=1)
    df = df.apply(lambda x: BaseGridPhase2(x), axis=1)
    
    #Applying override grid
    df = df.apply(lambda x: override10(x), axis=1)#
    df = df.apply(lambda x: override13(x), axis=1)#
    df = df.apply(lambda x: override15(x), axis=1)#
    # df = df.apply(lambda x: override16(x), axis=1)
    # df = df.apply(lambda x: override17(x), axis=1)
    # df = df.apply(lambda x: override18(x), axis=1)
    # df = df.apply(lambda x: override19(x), axis=1)
    # df = df.apply(lambda x: override20(x), axis=1)
    df = df.apply(lambda x: override21(x), axis=1)#
    df = df.apply(lambda x: override22(x, df), axis=1)#
    # df = df.apply(lambda x: override22A(x, df), axis=1)#
    df = df.apply(lambda x: override61(x, df), axis=1)#
    # df = df.apply(lambda x: override23(x), axis=1)#
    # df = df.apply(lambda x: override24(x, df), axis=1)#
    df = df.apply(lambda x: override24A(x, df), axis=1)#
    df = df.apply(lambda x: override25(x), axis=1)#
    # df = df.apply(lambda x: override26(x), axis=1)
    df = df.apply(lambda x: override27(x, df), axis=1)
    # df = df.apply(lambda x: override28(x), axis=1)
    # df = df.apply(lambda x: override29(x), axis=1)
    # df = df.apply(lambda x: override30(x), axis=1)
    # df = df.apply(lambda x: override31(x), axis=1)#
    # df = df.apply(lambda x: override31A(x), axis=1)#
    df = df.apply(lambda x: override32(x), axis=1)
    # df = df.apply(lambda x: override33(x), axis=1)#
    # df = df.apply(lambda x: override34(x), axis=1)#
    # df = df.apply(lambda x: override35(x), axis=1)
    df = df.apply(lambda x: override36(x), axis=1)#
    df = df.apply(lambda x: override37(x,df), axis=1)#
    df = df.apply(lambda x: override38(x), axis=1)#
    # df = df.apply(lambda x: override39(x), axis=1)
    # df = df.apply(lambda x: override40(x), axis=1)
    df = df.apply(lambda x: override41(x), axis=1)#
    df = df.apply(lambda x: override42(x), axis=1)#
    # df = df.apply(lambda x: override43(x), axis=1)
    # df = df.apply(lambda x: override45(x), axis=1)
    df = df.apply(lambda x: override46(x), axis=1)#
    # df = df.apply(lambda x: override47(x), axis=1)
    # df = df.apply(lambda x: override48(x), axis=1)
    df = df.apply(lambda x: override49(x), axis=1)#
    # df = df.apply(lambda x: override50(x), axis=1)
    # df = df.apply(lambda x: override51(x), axis=1)#
    # df = df.apply(lambda x: override52(x), axis=1)#
    # df = df.apply(lambda x: override53(x), axis=1)
    # df = df.apply(lambda x: override3(x), axis=1)#
    # df = df.apply(lambda x: override5(x), axis=1) Not Applicable
    df = df.apply(lambda x: override6(x), axis=1)# 
    df = df.apply(lambda x: override7(x), axis=1)
    df = df.apply(lambda x: override8(x), axis=1)#
    # df = df.apply(lambda x: override9(x), axis=1)#Not applicable for april.
    # df = df.apply(lambda x: override1(x), axis=1) Not Applicable For December
    # df = df.apply(lambda x: override2(x), axis=1) Not Applicable For December
    df = df.apply(lambda x: override12(x), axis=1)#
    # df = df.apply(lambda x: override11(x), axis=1) Not Applicable For December
    df = df.apply(lambda x: override14(x), axis=1)#
    # df = df.apply(lambda x: override44(x), axis=1)
    df = df.apply(lambda x: override54(x), axis=1)#
    # df = df.apply(lambda x: override57(x), axis=1)#
    df = df.apply(lambda x: override4(x), axis=1)
    # df = df.apply(lambda x: override60(x),axis=1)
    df = df.apply(lambda x: override59(x),axis=1)
    df = df.apply(lambda x: override51(x), axis=1)#
    df["DISB_DATE"]=df["DISB_DATE1"]
    df.drop(columns="DISB_DATE1",inplace=True)
    
    return df
