import pandas as pd

def override39(row : pd.DataFrame):
    if(row["Consolidated State for Po processing"] == "J&K"):
        # if("ddsa" in row["Sourcing"].lower()):
            irr = row["Irr roundup"]
            rate = row["Override Rate"]
            if((irr < 9.35) & (irr >= 9.20) ):
                rate = 0.0035
            elif(((irr < 9.50) & (irr >= 9.35))):
                rate = 0.0035
            elif((irr < 9.70)& (irr >= 9.50)):
                rate = 0.0035
            elif(irr>=9.70):
                rate = 0.0035
            # elif((irr < 9.40)& (irr >= 9.25)):
            #     rate = 0.0040
            # elif((irr < 9.60)& (irr >= 9.40)):
            #     rate = 0.0045
            # elif((irr >= 9.60)):
            #     rate = 0.0050

            row["Override Rate"] = rate
            row["Override Remark"] += "39, "

    return row