from pandas import DataFrame
from datetime import datetime


def override6(row: DataFrame):

    state = ["jharkhand","chattisgarh"]
    state1=["bihar"]
    rowState = row["Consolidated State for Po processing"].lower()

    if(rowState in state):
        if("ddsa" in row["Sourcing"].lower()):
            row["Reduction In Rate"] += 0.0040
            row["Override Remark"] += "6, "
    if(rowState in state1):
        if("ddsa" in row["Sourcing"].lower()):
            row["Reduction In Rate"] += 0.0050
            row["Override Remark"] += "6, "
        # if((row["DMABROKERCODE_y"] == 285705) & (rowState=="orissa")):
        #     row["Reduction In Rate"] = 0
            
    return row