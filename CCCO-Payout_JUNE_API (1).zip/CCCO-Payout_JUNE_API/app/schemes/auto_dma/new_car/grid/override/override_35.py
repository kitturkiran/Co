import pandas as pd

def override35(row:pd.DataFrame):
    broker_list = [291778, 295348]
    if(row["DMABROKERCODE_y"] in broker_list):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        
        if(irr >= 8.25):
            row["Override Rate"] = 0.010
            row["Override Remark"] += "35, "
        
        if(segment in ["A", "B+"]):
            if(irr >= 8.45):
                row["Override Rate"] = 0.0150
                row["Override Remark"] +="35, "
 
    return row