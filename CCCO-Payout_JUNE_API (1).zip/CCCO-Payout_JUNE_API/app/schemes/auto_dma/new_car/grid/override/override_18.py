import pandas as pd

def override18(row: pd.DataFrame):
    if(row["TENURE_y"] >= 36):
        
        branch_states = ["cochin", "trivandrum", "thrissur", "trichur", "kottayam", "calicut"]
        if(row["BRANCHNM"].lower() in branch_states):
            row["Override Rate"] = override18A(row)
            row["Override Remark"] += "18A, "
            
        if(row["Consolidated State for Po processing"].lower() == "kerala"):
            row["Override Rate"] = override18B(row)
            row["Override Remark"] += "18B, "
            
    return row
        
               
def override18A(row: pd.DataFrame):
    grid = {
        'rate_min': [8.25, 8.50, 8.75, 9.00, 8.25, 8.50, 8.75, 9.00, 9.25],
        'rate_max': [8.50, 8.75, 9.00, 101, 8.50, 8.75, 9.00, 9.25, 101],
        'po': [1.25, 1.50, 1.75, 2.00, 0.50, 0.75, 1.00, 1.25, 1.50],
        'segment': [1, 1, 1, 1, 2, 2, 2, 2, 2]
    }
    grid = pd.DataFrame(grid)
    
    segment = {
        "A": 1,
        "B+": 1,
        "B": 1,
        "C": 1,
        "aip": 2,
        "pragati": 2
    }
    
    irr = row["Irr roundup"]
    
    channelCode = ""
    if(("aip" in row["CHANNELCODE"].lower()) | ("assessed income product" in row["CHANNELCODE"].lower())):
        channelCode = "aip"
    elif("pragati" in row["CHANNELCODE"].lower()):
        channelCode = "pragati"
    else:
        channelCode = "temp"
    
    if(row["Segment"] != "A+"):
        po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["po"]
        if(po.shape[0] == 0):
            po = 0
    else:
        po = row["Override Rate"]
     
    if(channelCode != "temp"):   
        po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[channelCode])]["po"]
        if(po.shape[0] == 0):
            po = 0
        
    return float(po) / 100
    
        
def override18B(row: pd.DataFrame):
    irr = row["Irr roundup"]
    
    grid = {
        'rate_min': [9.75, 10.00, 10.50, 11.00, 11.50],
        'rate_max': [10.00, 10.50, 11.00, 11.50, 101],
        'po': [2.00, 2.50, 3.00, 3.50, 4.00],
        'segment': [1, 1, 1, 1, 1]
    }
    grid = pd.DataFrame(grid)
    
    segment = {
        "A": 1,
        "B+": 1,
        "B": 1,
        "C": 1,
    }
    
    if(row["Segment"] != "A+"):
        po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["po"]
        if(po.shape[0] == 0):
            po = row["Override Rate"]
            return po
    else:
        po = row["Override Rate"]
        return po
        
    return float(po) / 100