import pandas as pd

def override37(row:pd.DataFrame,df):

    if(row["Consolidated State for Po processing"].lower() == "chennai"):
        if(row["DMABROKERCODE_y"] == 183781):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override37A(row)
        # elif(row["DMABROKERCODE_y"] == 242595):
        #     row["Override Rate"], row["Override Remark"] = override37B(row)
        # elif(row["DMABROKERCODE_y"] in [144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354]):
        #     row["Override Rate"], row["Override Remark"] = override37C(row)
        elif(row["DMABROKERCODE_y"] in [275151]):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override37D(row,df)
        elif(row["DMABROKERCODE_y"] in [266135,206822,318136]):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override37E(row,df)
        elif(row["DMABROKERCODE_y"] in [273006]):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override37F(row,df)

            
    if(row["Consolidated State for Po processing"].lower() == "kerala"):
        if(row["DMABROKERCODE_y"] == 131389):
            row["Override Rate"], row["Override Remark"] = override37B(row)
    
    return row

def override37A(row: pd.DataFrame):
    wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    if(row["Total Applicable Disbursement"] >= 30000000):
        if(wirr >= 9.40):
            rate = 0.0175
        # if(row["TotalPF"] < 0.40):
            # reduction = 0.001
            remark += "37A, "
        elif(wirr >= 9.20):
            rate = 0.0150
            remark += "37A, "
        elif(wirr >= 9.10):
            rate = 0.0135
            remark += "37A, "
        
    return rate, remark,reduction

def override37B(row: pd.DataFrame):
    wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    if(row["Total Applicable Disbursement"] >= 30000000):
        if(wirr >= 9.50):
            rate = 0.020
            remark += "37B, "
        elif(wirr >= 9.40):
            rate = 0.0180
            remark += "37B, "
        # elif(wirr >= 8.85):
        #     rate = 0.0100
        #     remark += "37B, "
    return rate, remark
def override37C(row: pd.DataFrame):
    wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    
    if(wirr >= 9.25):
        rate = 0.0225
        remark += "37C, "
    elif(wirr >= 8.95):
        rate = 0.0175
        remark += "37C, "
    elif(wirr >= 8.75):
        rate = 0.0125
        remark += "37C, "        
        
    return rate, remark

def override37D(row: pd.DataFrame,df):
    # wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    if(row["Total Applicable Disbursement"] >= 30000000):
        df=df.loc[(df["DMABROKERCODE_y"].isin([275151])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]["AMTFIN"].sum()
        df["AMTFIN*PRETAXIRR"]=df["AMTFIN"]*df["PRETAXIRR"]
        result=df["AMTFIN*PRETAXIRR"].sum()
            # result2=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]["PRETAXIRR"].sum()
            # result3=result1*result2
            
        result4=df.loc[(df["DMABROKERCODE_y"].isin([275151])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]["AMTFIN"].sum()
            # gp = df.groupby(["DMABROKERCODE_y"])[["AMTFIN*PRETAXIRR", "AMTFIN"]].sum().reset_index()
            

            # result = gp["AMTFIN*PRETAXIRR"]
        wirr = float(round((result / result4), 2))

        if(wirr >= 9.40):
            rate = 0.0185
            remark += "37D, "
        elif(wirr >= 9.20):
            rate = 0.0160
            remark += "37D, "
        elif(wirr >= 9.10):
            rate = 0.0150
            remark += "37D, " 
        # if(row["TotalPF"] < 0.40):
        #     reduction =+ 0.001       
        
    return rate, remark,reduction


def override37E(row: pd.DataFrame,df):
    # wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    # if(row["Total Applicable Disbursement"] >= 30000000):
    df=df.loc[(df["DMABROKERCODE_y"].isin([266135,206822,318136])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]
    df["AMTFIN*PRETAXIRR"]=df["AMTFIN"]*df["PRETAXIRR"]
    result=df["AMTFIN*PRETAXIRR"].sum()
            # result2=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]["PRETAXIRR"].sum()
            # result3=result1*result2
            
    result4=df.loc[(df["DMABROKERCODE_y"].isin([266135,206822,318136])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]["AMTFIN"].sum()
            # gp = df.groupby(["DMABROKERCODE_y"])[["AMTFIN*PRETAXIRR", "AMTFIN"]].sum().reset_index()
            

            # result = gp["AMTFIN*PRETAXIRR"]
    wirr = float(round((result / result4), 2))
    tad = df[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"].isin([266135,206822,318136]))]["AMTFIN"].sum()
    pf=df[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"].isin([266135,206822,318136]))]["PROCESSINGFEE"].sum()
    po=round((pf/tad)*100,2)
    if(tad>30000000):
        if(wirr >= 9.40):
                rate = 0.0185
                remark += "37E, "
        elif(wirr >= 9.20):
                rate = 0.0160
                remark += "37E, "
        elif(wirr >= 9.10):
                rate = 0.0150
                remark += "37D, " 
    # if(po < 0.40):
    #     reduction =+ 0.001       
        
    return rate, remark,reduction


def override37F(row: pd.DataFrame,df):
    # wirr = row["WIRR"]
    rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    if(row["Total Applicable Disbursement"] >= 30000000):
        df=df.loc[(df["DMABROKERCODE_y"].isin([273006])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]
        df["AMTFIN*PRETAXIRR"]=df["AMTFIN"]*df["PRETAXIRR"]
        result=df["AMTFIN*PRETAXIRR"].sum()
            # result2=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]["PRETAXIRR"].sum()
            # result3=result1*result2
            
        result4=df.loc[(df["DMABROKERCODE_y"].isin([273006])) & (df["Consolidated State for Po processing"].str.lower()=="chennai")]["AMTFIN"].sum()
            # gp = df.groupby(["DMABROKERCODE_y"])[["AMTFIN*PRETAXIRR", "AMTFIN"]].sum().reset_index()
            

            # result = gp["AMTFIN*PRETAXIRR"]
        wirr = float(round((result / result4), 2))
        print(wirr)
        if(wirr >= 9.40):
            rate = 0.0185
            remark += "37F, "
        elif(wirr >= 9.20):
            rate = 0.0160
            remark += "37F, "
        elif(wirr >= 9.10):
            rate = 0.0150
            remark += "37D, " 
        # if(row["TotalPF"] < 0.40):
        #     reduction =+ 0.001       
        
    return rate, remark,reduction
