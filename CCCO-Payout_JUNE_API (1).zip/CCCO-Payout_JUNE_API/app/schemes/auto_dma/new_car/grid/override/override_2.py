from pandas import DataFrame
from datetime import datetime


def override2(row: DataFrame):
    phase_date = datetime.strptime("17-10-2022", "%d-%m-%Y")
    if(row["DISB_DATE"] < phase_date):
        return row

    if(row["AMTFIN"] >= 2000000) & (row["AUTO DEBIT "].lower() == "yes"):
        if(row["Irr roundup"] >= 8.10):
            if(row["TENURE_y"] >= 36):
                if(row["Base Rate"] < 0.0030) & (row["Override Rate"] < 0.0030):
                    row["Override Rate"] = 0.003
                    row["Override Remark"] += "2, "
    
    return row