import pandas as pd

def override30(row: pd.DataFrame):
    if((row["DMABROKERCODE_y"] == 308499) & (row["Consolidated State for Po processing"].lower() == "mumbai")):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        
        if(irr >= 8.25):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "30, "
            
        if((irr >= 8.65) & (segment in ["A", "B+"])):
            row["Override Rate"] = 0.0200
            row["Override Remark"] += "30, "
            
    return row