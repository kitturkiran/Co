import pandas as pd

def override34(row:pd.DataFrame):

    if((row["DMABROKERCODE_y"] == 104980) & (row["Consolidated State for Po processing"].lower() == "gujarat")):
        product = ["fortuner", "camry", "vellfire", "innova", "hyryder"]

        car_make = row["MAKE"].lower()
        irr = row["Irr roundup"]
        for item in product:
            if(item in car_make):
                if(irr >= 8.95):
                    row["Override Rate"] = 0.0100
                    if (row["Override Rate"]>0):
                        row["Addition In Rate"] = (row["Override Rate"] * 0.09)
                    row["Override Remark"] += "34, "
                    
        if(("urban cruiser" in car_make)|("glanza" in car_make)):
            if(irr >= 9.10):
                row["Override Rate"] = 0.0100
                if (row["Override Rate"]>0):
                    row["Addition In Rate"] = (row["Override Rate"] * 0.09)
                # row["Addition In Rate"] = (row["Override Rate"] * 0.09)
                row["Override Remark"] += "34, "

    return row