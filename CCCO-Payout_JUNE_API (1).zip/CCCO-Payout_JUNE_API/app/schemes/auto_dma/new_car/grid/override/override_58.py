import pandas as pd

def override58(row: pd.DataFrame):
        
        
        segment = row["Segment"]
        irr = row["Irr roundup"]
        rate = row["Override Rate"]
    
    # grid_top = {'rate_min': [8.75, 8.85, 9.00, 9.10, 9.30, 9.10, 9.25, 9.40, 9.60],
    #             'rate_max': [8.85, 9.00, 9.10, 9.30, 101.0, 9.25, 9.40, 9.60, 101.0],
    #             'cat3': [0.75, 1.25, 1.50, 1.60, 1.70, 1.70, 1.85, 2.00, 2.10],
    #             'cat2': [0.65, 1.10, 1.35, 1.45, 1.55, 1.55, 1.70, 1.85, 1.95],
    #             'cat1': [0.50, 1.00, 1.25, 1.35, 1.45, 1.45, 1.60, 1.75, 1.85],
    #             'segment': [1, 1, 1, 1, 1, 2, 2, 2, 2]}

    # grid_top = pd.DataFrame(grid_top)

    # segment = {
    #     "A+": 1,
    #     'A': 2, 
    #     'B+': 2, 
    #     'B': 2, 
    #     'C': 2,
    # }
        broker=[245813,
            267747,
            134660,
            105059,
            253940,
            285333,
            284407,
            155962,
            103112,
            259667,
            237613,
            293014,
            264832,
            265985,
            183457,
            286346,
            ]
        if((row["DMABROKERCODE_y"] in broker)&((row["Consolidated State for Po processing"].lower() == "rajasthan"))):
    
        
                if ((row['Total Applicable Disbursement'] >= 30000000)&(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())| (("cust" in row["CHANNELCODE"].lower()))) == False):

  #     rate=0
        #     segment = row["Segment"]
        #     irr = row["Irr roundup"]
        #     rate = row["Override Rate"]
                        if(irr > 9.20):
                                rate = 0.0150
                                row["Override Remark"] += "58, "
                        if((irr < 9.10) & (irr >= 9.05)& (segment in ["A"])):
                                rate = 0.0125
                                row["Override Remark"] += "58, "
                        if((irr < 9.20)& (irr >= 9.10) & (segment in ["A","C"])):
                                rate = 0.0140
                                row["Override Remark"] += "58, "

            
            
            
                elif ((row['Total Applicable Disbursement'] >= 10000000)&(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())| (("cust" in row["CHANNELCODE"].lower()))) == False):

                        if(irr > 9.20):
                                rate = 0.0125
                                row["Override Remark"] += "58, "
                        if((irr < 9.10) & (irr >= 9.05)& (segment in ["A"])):
                                rate = 0.0115
                                row["Override Remark"] += "58, "
                        if((irr < 9.20)& (irr >= 9.10) & (segment in ["A","C"])):
                                rate = 0.0125
                                row["Override Remark"] += "58, "

                elif ((row['Total Applicable Disbursement'] < 10000000)&(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())| (("cust" in row["CHANNELCODE"].lower()))) == False):
        #     segment = row["Segment"]
        #     irr = row["Irr roundup"]
        #     rate = row["Override Rate"]
                        if(irr > 9.20):
                                rate = 0.0100
                                row["Override Remark"] += "58, "
                        if((irr < 9.10) & (irr >= 9.05)& (segment in ["A"])):
                                rate = 0.0100
                                row["Override Remark"] += "58, "
                        if((irr < 9.20)& (irr >= 9.10) & (segment in ["A","C"])):
                                rate = 0.0115
                                row["Override Remark"] += "58, "

                    
        if(row["TotalPF"] < 0.40):
                row["Reduction In Rate"] =+ 0.001
        


        # Handling the band A from the grid
        row["Override Rate"] = rate

        return row