import pandas as pd

def override21(row: pd.DataFrame):
    consol_state = "mumbai"
    broker_code = 236835
    
    if((row["Consolidated State for Po processing"].lower() == consol_state) & (row["DMABROKERCODE_y"] == broker_code)):
        irr = row["Irr roundup"]
        if(irr >= 9.25):
            row["Override Rate"] = 0.0225
            row["Override Remark"] += "21, "
        elif(irr >= 9.00):
            row["Override Rate"] = 0.0200
            row["Override Remark"] += "21, "
            
    return row