import pandas as pd

def override9(row:pd.DataFrame):
    if("orissa" in row["Consolidated State for Po processing"].lower()):
        if(row["DMABROKERCODE_y"] == 285705):
            row["Reduction In Rate"] = 0.0075
            row["Override Remark"] += "9, "

    return row