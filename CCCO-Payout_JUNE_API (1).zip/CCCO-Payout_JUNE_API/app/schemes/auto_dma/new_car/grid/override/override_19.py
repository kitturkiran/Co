import pandas as pd

def override19(row: pd.DataFrame):
    broker_code = 246529
    consol_state = "rajasthan"
    target1 = 20000000
    target2 = 35000000
    
    if((row["Consolidated State for Po processing"].lower() == consol_state) & (row["DMABROKERCODE_y"] == broker_code)):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        
        if(row["Total Applicable Disbursement"] >= target2):
            po = 0.0200
        elif(row["Total Applicable Disbursement"] >= target1):
            po = 0.0175
        else:
            po = 0.0
        
        if((segment == "A+") & (irr >= 9.00)):
            row["Override Rate"] = po
            row["Override Remark"] += "19, "
        elif((segment in ["A", "C"]) & (irr >= 9.10)):
            row["Override Rate"] = po
            row["Override Remark"] += "19, "
        elif((segment in ["B+", "B"]) & (irr >= 9.25)):
            row["Override Rate"] = po
            row["Override Remark"] += "19, "
                
    return row