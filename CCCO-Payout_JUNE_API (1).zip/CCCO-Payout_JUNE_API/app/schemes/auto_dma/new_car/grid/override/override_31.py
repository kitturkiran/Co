import pandas as pd
from datetime import datetime

def override31(row:pd.DataFrame):
    phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] > phase_date):
        return row
    # state_list = ["mumbai", "pune", "romg"] #ROMG is present in grid but don't know the meaning
    irr = row["Irr roundup"]
    broker_codes_c = [164968, 25320, 208196, 144435, 101397]
    broker_codes_d = [104532, 301720]
    broker_codes_e = [218674, 261656,299254]
    broker_codes_f = [299254]
    broker_codes_h = [164897]

    # if(row["Consolidated State for Po processing"].lower() not in state_list):
    #     return row

    if((row["DMABROKERCODE_y"] == 101402) & (row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd")):
        if(irr < 8.90):
            return row
        rate = row["Override Rate"]
        # if row['Total Applicable Disbursement'] <= 10000000:
        if(irr < 9.00):
                rate = 0.0125
        elif(irr < 9.10):
                rate = 0.0150
        elif(irr < 9.25):
                rate = 0.0175
        else:
                rate = 0.0200

        if(row["TotalPF"] < 0.40):
                row["Reduction In Rate"] =+ 0.001
        row["Override Rate"] = rate
        row["Override Remark"] += "31, "
        



    return row