import pandas as pd
from datetime import datetime

def override36(row:pd.DataFrame):

    if(row["Consolidated State for Po processing"].lower() != "chennai"):
        return row
    broker_list1=[266134,255535,164514,242595]
    broker_list = [262041,269736,122452,164572,109512,269889,243198]
    if((row["TENURE_y"] < 36)):
        return row

    # phase_date = datetime.strptime("08-1-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] <= phase_date):
    #     if((row["DMABROKERCODE_y"] in broker_list)):
    #         row["Override Rate"] = override36A(row)
    #         row["Override Remark"] += "36A, "
    # else:
    if((row["DMABROKERCODE_y"] in broker_list)):
        row["Base Rate"] = override36B(row)
        row["Override Remark"] += "36B, "
    
    
    
    if((row["DMABROKERCODE_y"] in broker_list1)):
        row["Base Rate"] = override36A(row)
        row["Override Remark"] += "36A, "
    return row


def override36A(row: pd.DataFrame):
    segment = row["Segment"]
    irr = row["Irr roundup"]
    rate = row["Base Rate"]
    
    if(irr < 9.25):
        
        if(irr >= 9.15):
            if(segment in ["A+", "A", "C"]):
                rate = 0.0150
        elif(irr >= 9.00):
            if(segment in ["A+"]):
                rate = 0.0125                        
        elif(irr >= 8.85):
            if(segment == "A+"):
                rate = 0.0075
        else:
            rate=0
        
        # elif(irr >= 8.80):
        #     if(segment in ["A+","A"]):
        #         rate = 0.0135                
    else:
        if(irr < 9.30):
            rate = 0.0160
        elif(irr < 9.40):
            rate = 0.0170
        elif(irr < 9.60):
            rate = 0.0185
        else:
            rate = 0.0200
    channelCode = ""
    if("stp" in row['CHANNELCODE'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE"].lower()):
        channelCode = "pa"
        
    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.85):
            rate = max(0.0075, rate)
    
    # if(row["TotalPF"] < 0.40):
    #     row["Reduction In Rate"] =+ 0.001

    return rate

def override36B(row: pd.DataFrame):
    segment = row["Segment"]
    irr = row["Irr roundup"]
    rate = row["Base Rate"]
    
    if(irr < 9.25):
        
        if(irr >= 9.15):
            if(segment in ["A+", "A", "C"]):
                rate = 0.0135
        elif(irr >= 9.00):
            if(segment in ["A+"]):
                rate = 0.0110                        
        elif(irr >= 8.85):
            if(segment == "A+"):
                rate = 0.0065
        else:
            rate=0
        
        # elif(irr >= 8.80):
        #     if(segment in ["A+","A"]):
        #         rate = 0.0135                
    else:
        if(irr < 9.30):
            rate = 0.0145
        elif(irr < 9.40):
            rate = 0.0155
        elif(irr < 9.60):
            rate = 0.0170
        else:
            rate = 0.0185
    channelCode = ""
    if("stp" in row['CHANNELCODE'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE"].lower()):
        channelCode = "pa"
        
    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.85):
            rate = max(0.0075, rate)
            
    # if(row["TotalPF"] < 0.40):
        # row["Reduction In Rate"] =+ 0.001

    return rate