import pandas as pd
from datetime import datetime
def override22A(row: pd.DataFrame, df: pd.DataFrame):
    phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] <= phase_date):
        return row

    broker_codes_a = [164897, 245024, 172023, 177945, 173974, 258295, 215034, 191433, 272355, 
                      181343, 177591, 270686, 239294, 387379, 311146]
    broker_codes_b = [123964, 104549]
    broker_codes_c = [164968, 25320, 208196, 144435, 101397]
    broker_codes_d = [104532, 301720]
    broker_codes_e = [106746,266367,101696]
    broker_codes_f = [299254]
    broker_codes_g = [173193]
    
    if(row["Consolidated State for Po processing"].lower() == "mumbai"):
        code = row["DMABROKERCODE_y"]
        if(code in broker_codes_a):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"]= override22A1(row, df)
        
        if(code in broker_codes_b):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"]= override22B(row, df)
            
        # if(code in broker_codes_c):
            # row["Override Rate"], row["Override Remark"] = override22C(row, df)
            
        if(code in broker_codes_d):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override22D(row,df)

        if(code in broker_codes_e):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"]= override22E(row,df)
        
        if(code in broker_codes_f):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override22F(row,df)
          
        if(code in broker_codes_g):
            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"]= override22G(row,df)  
    return row


def override22A1(row: pd.DataFrame, df: pd.DataFrame):
    irr = row["Irr roundup"]
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segment = row["Segment"]
    reduction=row["Reduction In Rate"]
    
    
    if(row["DMABROKERCODE_y"] in [164897, 245024]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([164897, 245024]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([164897, 245024]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] in [172023]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([172023]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([172023]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] in [173974, 177945]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([173974, 177945]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([173974, 177945]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] in [258295,215034,191433]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([258295,215034,191433]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([258295,215034,191433]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] in [272355]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([272355]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([272355]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] in [181343]):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([181343]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([181343]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] == 177591):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([177591]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([177591]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] == 270686):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([270686]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([270686]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] == 311146):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([311146]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([311146]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] == 239294):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([239294]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([239294]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    elif(row["DMABROKERCODE_y"] == 387379):
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([387379]))]["AMTFIN"].sum()
        pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([387379]))]["PROCESSINGFEE"].sum()
        po=round((pf/tad)*100,2)
    # elif(row["DMABROKERCODE_y"] in [239294, 173193, 387379,308499]):
        # tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([239294, 173193,387379,308499]))]["AMTFIN"].sum()
    # 
    # if(tad >= 10000000):
    # if((irr >= 9.05) & (segment in ["A+"])):
    #         po_rate = 0.0100
    #         remark += "22A, "
    if((irr >= 9.05) & (segment in ["A",  "C"])):
            po_rate = 0.0130
            remark += "22AA, "
    if((irr >= 9.15) & (segment in ["A", "B+","C","B"])):
            po_rate = 0.0140
            remark += "22AA, "
            
    if((irr >= 9.25) & (segment in ["A", "B+","C","B"])):
            po_rate = 0.0160
            remark += "22AA, "
    if(row["TotalPF"] < 0.40):
        reduction =+ 0.001
            
    return po_rate, remark,reduction


def override22B(row: pd.DataFrame,df: pd.DataFrame):
    irr = row["Irr roundup"]
    segment = row["Segment"]
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    
    tad1 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([123964, 104549]))]["AMTFIN"].sum()
    # if(tad1 >= 30000000):
        
    if((segment in ["A+"]) & (irr >= 8.85)):
            po_rate = 0.0075
            remark += "22BB, "
    if((segment in ["C", "B+", "A","A+"]) & (irr >= 9.10)):
            po_rate = 0.0125
            remark += "22BB, "
    if(row["TotalPF"] < 0.40):
        reduction =+ 0.001
    
    return po_rate, remark,reduction


def override22C(row: pd.DataFrame,df: pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    tad3 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([164968, 235320, 208196, 144435, 101397, 101696]))]["AMTFIN"].sum()
    # if(tad3 >= 30000000):
    
    if((row["Segment"] == "A+") & (row["Irr roundup"] >= 8.85)):
            po_rate = 0.0100
            remark += "22CC, "
        
    return po_rate, remark


def override22D(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    reduction=row["Reduction In Rate"]
    
    tad4 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532, 216182]))]["AMTFIN"].sum()
    # if(tad4 >= 30000000):    
    
    if((segmet in ["A+"])):
            if(irr>=8.85):
                po_rate=0.0085
                remark += "22DD, "

            if(irr>=8.90):
                po_rate=0.0115
                remark += "22DD, "

            
    if(segmet in ["A","C","A+"]):
            if(irr >= 9.05):
                po_rate = 0.0140
                remark += "22DD, "
            # if(irr >= 8.95):
            #     po_rate = 0.0140
            #     remark += "22D, "
    if(segmet in ["B+", "B","C","A","A+"]):
            if(irr >= 9.15):
                po_rate = 0.0160
                remark += "22DD, "
            if(irr >= 9.30):
                po_rate = 0.0175
                remark += "22DD, "
    tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532,301720]))]["AMTFIN"].sum()
    pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532,301720]))]["PROCESSINGFEE"].sum()
    po=round((pf/tad)*100,2)
    if(po < 0.40):
        reduction =+ 0.001
    
    return po_rate, remark,reduction

def override22E(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    reduction=row["Reduction In Rate"]
    tad5 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([218674, 261656]))]["AMTFIN"].sum()
    # if(tad5 >= 30000000):    
    
    if((segmet in ["A+"])):
            if(irr>=8.85):
                po_rate=0.0085
                remark += "22EE, "

            if(irr>=8.90):
                po_rate=0.0115
                remark += "22EE, "

            
    if(segmet in ["A","C","A+"]):
            if(irr >= 9.05):
                po_rate = 0.0140
                remark += "22EE, "
            # if(irr >= 8.95):
            #     po_rate = 0.0140
            #     remark += "22D, "
    if(segmet in ["B+", "B","C","A","A+"]):
            if(irr >= 9.15):
                po_rate = 0.0160
                remark += "22EE, "
            if(irr >= 9.30):
                po_rate = 0.0175
                remark += "22EE, "
    tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([106746,266367,101696]))]["AMTFIN"].sum()
    pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([106746,266367,101696]))]["PROCESSINGFEE"].sum()
    po=round((pf/tad)*100,2)
    if(po < 0.40):
        reduction =+ 0.001
    return po_rate, remark,reduction

def override22F(row: pd.DataFrame,df: pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    reduction=row["Reduction In Rate"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    tad3 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([299254]))]["AMTFIN"].sum()
    if(tad3 >= 30000000):
    
        if((row["MANUFACTURERDESC"].lower() in ["mg motor india pvt ltd", "audi"]) |(row["MAKE"].lower() in ["mg motor india pvt ltd", "audi"])| ("audi" in row["MAKE"].lower())):
            if(irr>=8.85):
                po_rate=0.0085
                remark += "22FF, "

            if(irr>=8.90):
                po_rate=0.0115
                remark += "22FF, "

            if(irr>=9.00):
                po_rate=0.0140
                remark += "22FF, "

            if(irr>=9.10):
                po_rate=0.0150
                remark += "22FF, "
            
            # po_rate = 0.0100
            # remark += "22F, "
        if(row["MANUFACTURERDESC"]=="HYUNDAI MOTORS INDIA LTD"):
            if(segmet in ["A","C","B+"]):
                if(irr >= 9.05):
                    po_rate = 0.0140
                    remark += "22FF, "
                # elif(irr >= 8.95):
                #     po_rate = 0.0140
                #     remark += "22D, "
            if(segmet in ["A","C","B+","B"]):
                if(irr >= 9.15):
                    po_rate = 0.0160
                    remark += "22FF, "
                # elif(irr >= 9.15):
                #     po_rate = 0.0185
                #     remark += "22D, "
                
    tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([299254]))]["AMTFIN"].sum()
    pf=df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([299254]))]["PROCESSINGFEE"].sum()
    po=round((pf/tad)*100,2)
    if(po < 0.40):
        reduction =+ 0.001

      
    return po_rate, remark,reduction



def override22G(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    # tad4 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532, 216182]))]["AMTFIN"].sum()
    # if(tad4 >= 30000000):    
    
    if((segmet in ["A"])):
            if(irr>=9.05):
                po_rate=0.0125
                remark += "22GG, "

            # if(irr>=8.90):
            #     po_rate=0.0115
            #     remark += "22G, "

            
    if(segmet in ["A","C","B+"]):
            if(irr >= 9.20):
                po_rate = 0.0150
                remark += "22GG, "
            # if(irr >= 8.95):
            #     po_rate = 0.0140
            #     remark += "22D, "
    if(segmet in ["B+", "B","C","A"]):
            if(irr >= 9.25):
                po_rate = 0.0160
                remark += "22GG, "
            # if(irr >= 9.30):
            #     po_rate = 0.0175
            #     remark += "22G, "
    if(row["TotalPF"] < 0.40):
        reduction =+ 0.001
    return po_rate, remark,reduction