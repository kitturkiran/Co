from datetime import datetime
import pandas as pd

def override33(row : pd.DataFrame):
    # phase_date = datetime.strptime("9-1-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] < phase_date):
    #     return row
    
    if(row["Consolidated State for Po processing"].lower() != "bangalore"):
        return row

    # broker_list_1 = [164968, 266737, 294336, 141524, 171062, 101650, 256398, 179463, 155473]
    broker_list_2 = [164968, 266737, 294336, 141524, 101650, 256398, 179463, 155473, 167708, 173194, 112416, 295008, 267233, 174384, 104505, 304002, 164432, 108210, 173813, 273607, 227239, 295009, 261561, 172149]


    if(row["DMABROKERCODE_y"] in broker_list_2):
        if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
                if(row["Total Applicable Disbursement"] < 10000000):
                    return row     
        if(row["TENURE_y"] < 36):
            row["Reduction In Rate"] += 0.0025
            row["Override Remark"] += "33, " 
        else:
            if(((row["Irr roundup"]>=8.90) & (row["Irr roundup"]<9.15))):
                row["Override Rate"] = 0.0125
                row["Override Remark"] += "33, "
                if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
                    if((row["Irr roundup"]<=8.85)):
                        row["Reduction In Rate"] += 0.0025
                        row["Override Remark"] += "32r, " 
                else:
                    if((row["Total Applicable Disbursement"] < 20000000) & (row["Irr roundup"]<=9.15)):
                        row["Reduction In Rate"] += 0.0025
                        row["Override Remark"] += "33, "                
            if(row["Irr roundup"]>=9.15):
                row["Override Rate"] = 0.0200
                row["Override Remark"] += "33, "
            
            # if(row["Irr roundup"] <= 8.60):
                if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
                    if((row["Irr roundup"]<8.90)):
                        row["Reduction In Rate"] += 0.0025
                        row["Override Remark"] += "32r, " 
                else:
                    if((row["Total Applicable Disbursement"] < 20000000) & (row["Irr roundup"]<=9.15)):
                        row["Reduction In Rate"] += 0.0025
                        row["Override Remark"] += "33, "

# < 8.95) & (row["Irr roundup"] >= 8.85)(grid_top['rate_min'] <= irr) & (grid_top['rate_max'] > irr)
    # if(row["DMABROKERCODE_y"] in broker_list_2):
    #     if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
    #             if(row["Total Applicable Disbursement"] < 10000000):
    #                 return row     
    #     if(row["TENURE_y"] < 36):
    #         row["Reduction In Rate"] += 0.0025
    #         row["Override Remark"] += "33, " 
    #     else:
    #         if(((row["Irr roundup"]>=8.75) & (row["Irr roundup"]<8.85)) & ((row["DISB_DATE"] >= datetime.strptime("7-12-2022", "%d-%m-%Y")) & ((row["DISB_DATE"] <= datetime.strptime("16-12-2022", "%d-%m-%Y"))))):
                
    #             row["Override Rate"] = 0.0125
    #             row["Override Remark"] += "33, "
    #             if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
    #                 pass
    #             else:
    #                 if((row["Total Applicable Disbursement"] < 20000000)& (row["Irr roundup"]<8.85)):
    #                     row["Reduction In Rate"] += 0.0025
    #                     row["Override Remark"] += "33, "
    #         if((row["Irr roundup"]>=8.85) & ((row["DISB_DATE"] >= datetime.strptime("7-12-2022", "%d-%m-%Y")) & ((row["DISB_DATE"] <= datetime.strptime("16-12-2022", "%d-%m-%Y"))) & (row["DISB_DATE"] <= datetime.strptime("16-12-2022", "%d-%m-%Y")))):
    #             row["Override Rate"] = 0.0200
    #             row["Override Remark"] += "33, "
    #             if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
    #                 pass
    #             else:
    #                 if((row["Total Applicable Disbursement"] < 20000000)& (row["Irr roundup"]<8.85)):
    #                     row["Reduction In Rate"] += 0.0025
    #                     row["Override Remark"] += "33, "
                
    #         if((row["Irr roundup"]>=8.95) & (row["DISB_DATE"] >= datetime.strptime("17-12-2022", "%d-%m-%Y"))):
    #             row["Override Rate"] = 0.0200
    #             row["Override Remark"] += "33, "

    #             if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
    #                 pass
    #             else:
    #                 if((row["Total Applicable Disbursement"] < 20000000)& (row["Irr roundup"]<8.85)):
    #                     row["Reduction In Rate"] += 0.0025
    #                     row["Override Remark"] += "33, "            
            # if(row["Irr roundup"] >= 8.85) & ((row["DISB_DATE"] >= datetime.strptime("7-12-2022", "%d-%m-%Y"))):
            #     if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
            #         pass
            #     else:
            #         if(row["Total Applicable Disbursement"] < 20000000):
            #             row["Reduction In Rate"] += 0.0025
            #             row["Override Remark"] += "33, "

    
        
    return row