import pandas as pd
from datetime import datetime

def override53(row: pd.DataFrame):
    phase_date = datetime.strptime("9-1-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] < phase_date):
        return row
    
    if(row["Consolidated State for Po processing"].lower() != "bangalore"):
        return row

    broker_list = 164968
    if(row["DMABROKERCODE_y"]==broker_list):
        if ((row["Irr roundup"]>=8.65) & (row["Irr roundup"] < 8.90) & (row["TENURE_y"]>=36)):
            row["Override Rate"] = 0.0025
            row["Override Remark"] += "52, "

    return row 