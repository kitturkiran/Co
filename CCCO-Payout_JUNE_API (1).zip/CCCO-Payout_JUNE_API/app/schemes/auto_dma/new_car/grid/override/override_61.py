import pandas as pd

def override61(row: pd.DataFrame,df):
    
    
    broker_codes_c = [164968, 25320, 208196, 144435, 101397]

    broker_codes_h = [164897]
    if(row["Consolidated State for Po processing"].lower() == "mumbai"):
        code = row["DMABROKERCODE_y"]
        # if(code in broker_codes_c):
        #     row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override22C(row, df)
            

        if(code in broker_codes_h):
                row["Override Rate"], row["Override Remark"]=override22H(row,df)
    return row
                
def override22C(row: pd.DataFrame,df: pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    tad3 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([164968, 235320, 208196, 144435, 101397, 101696]))]["AMTFIN"].sum()
    # if(tad3 >= 30000000):
    
    if((row["Segment"] == "A+") & (row["Irr roundup"] >= 8.85)):
            po_rate = 0.0100
            remark += "22C, "
    
    if(row["TotalPF"] < 0.40):
        reduction =+ 0.001
        
    return po_rate, remark,reduction


def override22D(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    tad4 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532, 216182]))]["AMTFIN"].sum()
    # if(tad4 >= 30000000):    
    
    if((segmet in ["A+"])):
            if(irr>=8.75):
                po_rate=0.0100
                remark += "22D, "

            if(irr>=8.85):
                po_rate=0.0130
                remark += "22D, "

            
    if(segmet in ["A","C","A+"]):
            if(irr >= 8.85):
                po_rate = 0.0130
                remark += "22D, "
            if(irr >= 8.95):
                po_rate = 0.0140
                remark += "22D, "
    if(segmet in ["B+", "B","C","A","A+"]):
            if(irr >= 8.95):
                po_rate = 0.0140
                remark += "22D, "
            if(irr >= 9.00):
                po_rate = 0.0175
                remark += "22D, "
            if(irr >= 9.15):
                po_rate = 0.0185
                remark += "22D, "
    return po_rate, remark

def override22E(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    tad5 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([218674, 261656,299254]))]["AMTFIN"].sum()
    if(tad5 >= 30000000):    
    
        if((row["MANUFACTURERDESC"].lower() in ["mg motor india pvt ltd", "audi"])|(("audi" in row["MAKE"].lower()))):
            if(irr>=8.75):
                po_rate=0.0100
                remark += "22E, "

            if(irr>=8.85):
                po_rate=0.0130
                remark += "22E, "

            if(irr>=8.95):
                po_rate=0.0140
                remark += "22E, "

            if(irr>=9.00):
                po_rate=0.0175
                remark += "22E, "

        
    # if(segmet in ["A","C"]):
    #     if(irr >= 8.85):
    #         po_rate = 0.0130
    #         remark += "22D, "
    #     elif(irr >= 8.95):
    #         po_rate = 0.0140
    #         remark += "22D, "
    # if(segmet in ["B+", "B"]):
    #     if(irr >= 9.00):
    #         po_rate = 0.0175
    #         remark += "22D, "
    #     elif(irr >= 9.15):
    #         po_rate = 0.0185
    #         remark += "22D, "
            
    return po_rate, remark

def override22F(row: pd.DataFrame,df: pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    reduction=row["Reduction In Rate"]
    
    
    tad3 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([299254]))]["AMTFIN"].sum()
    if(tad3 >= 30000000):
    
        if((row["MANUFACTURERDESC"].lower() in ["mg motor india pvt ltd", "audi"]) |(row["MAKE"].lower() in ["mg motor india pvt ltd", "audi"])| ("audi" in row["MAKE"].lower())):
            if(irr>=8.75):
                po_rate=0.0100
                remark += "22F, "

            if(irr>=8.85):
                po_rate=0.0130
                remark += "22F, "

            if(irr>=8.95):
                po_rate=0.0140
                remark += "22F, "

            if(irr>=9.00):
                po_rate=0.0175
                remark += "22F, "
            
            # po_rate = 0.0100
            # remark += "22F, "
        if(row["MANUFACTURERDESC"]=="HYUNDAI MOTORS INDIA LTD"):
            if(segmet in ["A","C","B+"]):
                if(irr >= 8.95):
                    po_rate = 0.0130
                    remark += "22F, "
                # elif(irr >= 8.95):
                #     po_rate = 0.0140
                #     remark += "22D, "
            if(segmet in ["A","C","B+","B"]):
                if(irr >= 9.00):
                    po_rate = 0.0160
                    remark += "22F, "
                # elif(irr >= 9.15):
                #     po_rate = 0.0185
                #     remark += "22D, "
        if(row["TotalPF"] < 0.40):
            reduction =+ 0.001
            
      
    return po_rate, remark,reduction

def override22H(row: pd.DataFrame,df:pd.DataFrame):
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    segmet = row["Segment"]
    irr = row["Irr roundup"]
    # tad4 = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([104532, 216182]))]["AMTFIN"].sum()
    # if(tad4 >= 30000000):    
    
    # if((segmet in ["A+"])):
    if(irr>=9.25):
                po_rate=0.0175
                remark += "61, "
    if(irr>=9.50):
                po_rate=0.020
                remark += "61, "


    return po_rate, remark