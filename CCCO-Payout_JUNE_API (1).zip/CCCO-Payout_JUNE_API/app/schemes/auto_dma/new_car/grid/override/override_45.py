import pandas as pd

def override45(row: pd.DataFrame):
    broker_codes = [ 285704, 180355, 180410, 182170, 184461, 210113, 271384, 182909, 184924, 244282, 161623, 166253, 198344, 
                    189067, 173752, 145293, 244287, 185496, 266733, 307873, 112261, 247479, 307251, 307873, 175384, 175119,
                    191164, 205682, 185853, 236565, 303692, 288800, 228382, 359166, 205161, 240127, 272354, 311388, 245566
                    ]
    
    segments = ["A", "B+", "B", "C"]
    
    if((row["DMABROKERCODE_y"] in broker_codes) & (row["Consolidated State for Po processing"].lower() == "gujarat") & 
       (row["Segment"] in segments)):
        row["Reduction In Rate"] += 0.0035
        row["Override Remark"] += "45, "
        
    return row