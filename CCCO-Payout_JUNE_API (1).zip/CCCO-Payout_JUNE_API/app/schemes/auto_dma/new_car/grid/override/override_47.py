import pandas as pd

def override47(row:pd.DataFrame):
    state = row["Consolidated State for Po processing"].lower()
    broker = row["DMABROKERCODE_y"]
    if(state != "mumbai")  | (broker != 387379):
        return row

    segment = row["Segment"]
    rate = row["Override Rate"]
    irr = row["Irr roundup"]

    if(segment in ["A", "A+"]):
        if(irr >= 8.65):
            rate = 0.75
    elif(segment in ["A", "B+", "C"]):
        if(irr >= 8.85):
            rate = 1.10
    elif(segment in ["B"]):
        if(irr >= 8.95):
            rate = 1.25

    row["Override Rate"] = rate
    row["Override Remark"] += "47, "

    return row