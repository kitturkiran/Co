from datetime import datetime
import pandas as pd

def override48(row:pd.DataFrame):
    phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] > phase_date):
        return row
    if(row["DMABROKERCODE_y"] != 316343):
        return row

    tenure = row["TENURE_y"]
    if(tenure < 24):
        return row
    if(tenure < 36):
        if(row["Irr roundup"] >= 9.85):
            row["Override Rate"] = 0.0050
            
        return row

    amt = row["AMTFIN"]
    irr = row["Irr roundup"]
    rate = row["Override Rate"]
    segment = row["Segment"]
    if(row['Total Applicable Disbursement'] < 30000000):
        row["Reduction In Rate"] += 0.0015
    if(segment == "A+"):
        if(irr < 8.75):
            rate = 0    
        elif(irr < 8.85):
            rate = 0.0075
        elif(irr < 9.00):
            rate = 0.0125
        elif(irr < 9.10):
            rate = 0.0150
        elif(irr < 9.30):
            rate = 0.0160
        else:
            rate = 0.0170
    elif(irr >= 9.00):
        if(irr < 9.25):
            rate = 0.0170
        elif(irr < 9.40):
            rate = 0.0185
        elif(irr < 9.60):
            rate = 0.0200

            # elif(irr < 9.50):
            #     rate = 0.0160
        else:
            rate = 0.0210

    if(segment == "A"):
        if((irr >=8.95) & (irr < 9.00)):
            rate = 0.0150
    if((irr >= 9.00) & (irr < 9.10) & (segment in ["A","C"])):
        rate=0.0160

    channelCode = ""
    if("stp" in row['CHANNELCODE1'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE1'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE1"].lower()):
        channelCode = "pa"
    # elif(("aip" in row['CHANNELCODE'].lower()) | ("assessed income product" in row["CHANNELCODE"].lower())):
    #     channelCode = "aip"
    elif("ftu" in row['CHANNELCODE1'].lower()):
        channelCode = "ftu"
    elif("pragati" in row['CHANNELCODE1'].lower()):
        channelCode = "pragati"
        
    if(channelCode in ["aip", "ftu", "pragati"]):
        if(irr >= 9.90):
            rate = 0.0200

    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.75):
            rate = max(rate, 0.0090)

    row["Override Rate"] = rate
    row["Override Remark"] += "48, "


    return row