import pandas as pd

def override15(row: pd.DataFrame):
    grid1 = [
            192869,
            202056,
            253609,
            185495,
            294603,
            181211,
            293545,
            290386,
            101626,
            217815,
            240889,
            153152,
            293454,
            290820,
            171583,
            303694,

            ]

    grid2 = [229137, 105059]

    grid3 = [
            240630,
            247476,
            149898,
            192445,
            155962,
            253940,
            237613,
            103112,
            267747,
            289887,
            172823,
            168612,
            264830,
            240027,
            297970,
            168612,
            102356,
            258602,
            300399,
            188120,
            114229,
            191017,
            192451,
            226183,
            299838,
            304050,
            271884,
            293747,
            183848,
            181479,
            305143,
            214897,
            163134,
            177590,
            175573,
            229137,
            105059,
            289922,
            192868,
            290811,
            319343,
            282211,
            320581,
            192451,
            275730,
            114229,
            271884,
            181479,
            183848,
            182866,
            158288,
            306959,

                ]
            
    reduction = 0
    if (row["Consolidated State for Po processing"].lower() == "rajasthan"):
        if row["DMABROKERCODE_y"] in grid1:
            reduction = max(reduction, 0.0040)

        # if row['DMABROKERCODE_y'] in grid2:
        #     reduction = max(reduction, 0.0015)

        if row['DMABROKERCODE_y'] in grid3:
            reduction = max(reduction, 0.0025)

        row["Reduction In Rate"] += reduction
        if(reduction > 0):
            row["Override Remark"] += "15, "

    return row