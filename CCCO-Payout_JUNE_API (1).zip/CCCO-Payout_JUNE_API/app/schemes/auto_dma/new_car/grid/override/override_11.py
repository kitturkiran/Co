from datetime import datetime
import pandas as pd

def override11(row : pd.DataFrame):

    phase_date = datetime.strptime("14-10-2022", "%d-%m-%Y")
    segment = row["Segment"]
    irr = row["Irr roundup"]
    channelCode = ""
    channelCode = ""
    if("stp" in row['CHANNELCODE'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE"].lower()):
        channelCode = "pa"
    elif(("aip" in row['CHANNELCODE'].lower()) | ("assessed income product" in row["CHANNELCODE"].lower())):
        channelCode = "aip"
    elif("ftu" in row['CHANNELCODE'].lower()):
        channelCode = "ftu"
    elif("pragati" in row['CHANNELCODE'].lower()):
        channelCode = "pragati"
    elif("fleet" in row["CHANNELCODE"].lower()):
        channelCode = "fleet"

    if(row["DISB_DATE"] <= phase_date):

        if(channelCode in ["stp", "alpa", "pa"]):
            if(irr < 8.10):
                row["flag"] = 0
                row["Override Remark"] += "11, "
            else:
                return row
        
        if(row["Salaried"].lower() == "yes"):
            if(irr < 8.25):
                row["flag"] = 0
                row["Override Remark"] += "11, "
            else:
                return row

        if(segment == "A+") & (irr < 8.10):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "A") & (irr < 8.10):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "B") & (irr < 8.10):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "B+") & (irr < 8.10):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "C") & (irr < 8.10):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        
        if(("aip" in channelCode) | ("assessed income product" in channelCode) | ("pragati" in channelCode) | ("ftu" in channelCode) | ("fleet" in channelCode)) & (irr < 9.65):
            row["flag"] = 0
            row["Override Remark"] += "11, "
    else:
        if(channelCode in ["stp", "alpa", "pa"]):
            if(irr < 8.25):
                row["flag"] = 0
                row["Override Remark"] += "11, "
            else:
                return row

        if(row["Salaried"].lower() == "yes"):
            if(irr < 8.35):
                row["flag"] = 0
                row["Override Remark"] += "11, "
            else:
                return row

        if(segment == "A+") & (irr < 8.35):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "A") & (irr < 8.45):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "B") & (irr < 8.90):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "B+") & (irr < 8.70):
            row["flag"] = 0
            row["Override Remark"] += "11, "
        elif(segment == "C") & (irr < 8.40):
            row["flag"] = 0
            row["Override Remark"] += "11, "

        if(("aip" in channelCode) | ("asessed income product" in channelCode) | ("pragati" in channelCode) | ("ftu" in channelCode) | ("fleet" in channelCode)) & (irr < 9.75):
            row["flag"] = 0
            row["Override Remark"] += "11, "

    return row