import pandas as pd
from datetime import datetime

def override23(row: pd.DataFrame):
    # phase_date = datetime.strptime("07-12-2022", "%d-%m-%Y")
    # if(row["DISB_DATE"] < phase_date):Chennai
    #     return row
    
    broker_codes = {348307: ["rotn", "chennai"], 
                    145035: ["rotn"], 
                    256705: ["rotn"], 
                    232691: ["rotn"], 
                    348090: ["rotn", "chennai"], 
                    171978: ["rotn", "chennai"], 
                    267873: ["rotn"], 
                    254013: ["rotn"], 
                    243881: ["rotn"], 
                    195343: ["rotn"], 
                    115182: ["rotn"], 
                    # 275356: ["rotn"],
                    243198: ["rotn"], 
                    258180: ["rotn"],
                    286988: ["rotn"],
                    243031: ["rotn"]
                    }
    
    if((row["TENURE_y"] >= 36) & (row["DMABROKERCODE_y"] in broker_codes.keys()) & (row["Total Applicable Disbursement"] <= 10000000)):
        
       if((row["Consolidated State for Po processing"].lower() in broker_codes[row["DMABROKERCODE_y"]])):
        
            grid = {'rate_min': [8.95, 9.10, 9.20, 9.40, 9.30, 9.40, 9.60, 9.80],
                    'rate_max': [9.10, 9.20, 9.40, 101.00, 9.40, 9.60, 9.80, 101.0],
                    'po': [0.50, 0.75, 0.85, 0.95, 0.90, 1.10, 1.25, 1.35],
                    'segment': [1, 1, 1, 1, 2, 2, 2, 2],}

            grid = pd.DataFrame(grid)

            segment = {
                "A+": 1,
                'A': 2, 
                'B+': 2, 
                'B': 2, 
                'C': 2,
            }

            irr = row['Irr roundup']
                
            flag = False
            po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["po"]
            if(po.shape[0] != 0):
                row["Override Rate"] = float(po) / 100
                flag = True
            
            # Handling the band A from the grid
            if((irr >= 9.15) & (irr < 9.20) & (row["Segment"] == "A")):
                row["Override Rate"] = 0.0075
                flag = True
                
            # Handling the band C from the grid
            if((irr >= 9.20) & (irr < 9.30) & (row["Segment"] in ["A","C"])):
                row["Override Rate"] = 0.0085
                flag = True
                
            channelCode = ""
            if("stp" in row['CHANNELCODE1'].lower()):
                channelCode = "stp"
            elif("alpa" in row['CHANNELCODE1'].lower()):
                channelCode = "alpa"
            elif("pa" in row['CHANNELCODE1'].lower()):
                channelCode = "pa"
            # elif(("aip" in row['CHANNELCODE'].lower()) | ("assessed income product" in row["CHANNELCODE"].lower())):
            #     channelCode = "aip"
            elif("ftu" in row['CHANNELCODE1'].lower()):
                channelCode = "ftu"
            elif("pragati" in row['CHANNELCODE1'].lower()):
                channelCode = "pragati"
                
            if(channelCode in ["aip", "pragati", "ftu"]):
                flag = True
                if(irr >= 10.00):
                    row["Override Rate"] = 0.0130
                else:
                    row["Override Rate"] = 0
                    
            if(channelCode in ["stp", "alpa", "pa"]):
                if(irr >= 8.85):
                    row["Override Rate"] = max(0.0025, row["Override Rate"])
                    flag = True
                    
            # salary = row["Salaried"].lower()   

            # if(salary == "yes"):
            #     if(irr >= 8.25):
            #         row["Override Rate"] = max(0.0025, row["Override Rate"])
            #         flag = True
                
            if(flag == True):
                row["Override Remark"] += "23, "
        
    return row