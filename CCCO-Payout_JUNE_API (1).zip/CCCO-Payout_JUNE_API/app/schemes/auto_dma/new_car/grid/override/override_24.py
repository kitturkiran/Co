import pandas as pd
from datetime import datetime

def override24(row: pd.DataFrame, df: pd.DataFrame):
    # phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] > phase_date):
    #     return row
    broker_codes = [196575, 172769, 310184]

    # total_value = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin(broker_codes))]["AMTFIN"].sum()
    
    # if((row["Consolidated State for Po processing"].lower() == "mumbai") & (row["DMABROKERCODE_y"] in broker_codes) & 
    #    (10000000 <= total_value <= 30000000)):
    if((row["Consolidated State for Po processing"].lower() == "mumbai") & (row["DMABROKERCODE_y"] in broker_codes)):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        
        tad = df[(df["Consolidated State for Po processing"].str.lower() == "mumbai") & (df["DMABROKERCODE_y"].isin([196575, 172769, 310184]))]["AMTFIN"].sum()
        # if(tad >= 10000000):
        if((segment in ["A+"]) & (irr >= 8.65)):
                if(irr >= 8.95):
                    row["Override Rate"] = 0.0125
                    row["Override Remark"] += "24, "
                elif(irr >= 8.85):
                    row["Override Rate"] = 0.0100
                    row["Override Remark"] += "24, "
            
        if(segment in ["C", "A"]):
                if(irr >= 8.95):
                    row["Override Rate"] = 0.0140
                    row["Override Remark"] += "24, "
                elif(irr >= 8.85):
                    row["Override Rate"] = 0.0130
                    row["Override Remark"] += "24, "
                    
        if(segment in ["B+", "B","C","A"]):
                if(irr >= 9.15):
                    row["Override Rate"] = 0.0185
                    row["Override Remark"] += "24, "
                elif(irr >= 9.00):
                    row["Override Rate"] = 0.0170
                    row["Override Remark"] += "24, "
                elif(irr >= 8.95):
                    row["Override Rate"] = 0.0140
                    row["Override Remark"] += "24, "
        if(row["TotalPF"] < 0.40):
            row["Reduction In Rate"] =+ 0.001
                
    return row