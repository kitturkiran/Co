import pandas as pd
from  datetime  import datetime
def override51(row: pd.DataFrame):
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
    broker_code=[
                263243,
                287762,
                287761,
                287763,
                287764,
                287765,
                287767,
                287769,
                287777,
                287778,
                287779,
                287780,
                287781,
                287782,
                287783,
                287784,
                287936,
                287938,
                287939,
                287940,
                287987,
                292929,
                292931,

                ]
    # if((row["DMABROKERCODE_y"]in broker_code)):
    #     return row
    
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
    if((row["EV Band"]=="EV Band")):
        if(("fleet" not in row["CHANNELCODE"].lower()) & ("ftu" not in row["CHANNELCODE"].lower()) & ("taxi" not in row["CHANNELCODE"].lower())):
            if((row["Irr roundup"] >= 8.85) & (row["TENURE_y"] >= 36)):
                if((row["Base Rate"]>=0) & (row["Base Rate"]<0.0050)):
                    if((row["Override Rate"]>=0) & (row["Override Rate"]<0.0050)):
                        if(row["CHANNELCODE"]=="AUTO SPECIAL SCHEME-KERALA"):
                            row["Override Rate"]=0
                        if((row["CHANNELCODE"]=="AUTO SPECIAL SCHEME-KERALA") & (row["Irr roundup"]<9.10)):
                            row["Override Rate"]=0.0050
                        else:
                            row["Override Rate"]=0.0050
                            row["Override Remark"] += "51, "
                            
                            
    # if((row["EV Band"]=="EV Band") & (row["DISB_DATE"] > phase_date) ):
    #     if(("fleet" not in row["CHANNELCODE"].lower()) & ("ftu" not in row["CHANNELCODE"].lower()) & ("taxi" not in row["CHANNELCODE"].lower())):
    #         if((row["Irr roundup"] >= 8.85) & (row["TENURE_y"] >= 36)):
    #             if((row["Base Rate"] >= 0) & (row["Base Rate"]<0.0050)):
    #                 if((row["Override Rate"]>=0) & (row["Override Rate"]<0.0050)):
    #                     if(row["CHANNELCODE"]=="AUTO SPECIAL SCHEME-KERALA"):
    #                         row["Override Rate"]=0
    #                     if((row["CHANNELCODE"]=="AUTO SPECIAL SCHEME-KERALA") & (row["Irr roundup"]<9.10)):
    #                         row["Override Rate"]=0.0050
                        
    #                     else:
    #                         row["Override Rate"]=0.0050
    #                         row["Override Remark"] += "51, "    
                        
                        
                
                
                
                # row["Override Remark"] += "51, "
        
    return row