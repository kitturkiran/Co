from pandas import DataFrame
from datetime import datetime


def override7(row: DataFrame):

    state = ["madhya pradesh"]
    rowState = row["Consolidated State for Po processing"].lower()

    if(rowState in state):
        if("ddsa" in row["Sourcing"].lower()):
            row["Reduction In Rate"] += 0.0040
            row["Override Remark"] += "7, "
    
    return row