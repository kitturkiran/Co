import pandas as pd

def override20(row: pd.DataFrame):
    consol_state = "rajasthan"
    broker_code = 227871
    if((row["Consolidated State for Po processing"].lower() == consol_state) & (row["DMABROKERCODE_y"] == broker_code)):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        if((segment == "A+") & (irr >= 8.25)):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "20, "
        elif(irr >= 8.35):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "20, "
            
    return row