import pandas as pd
from datetime import datetime

def override27(row: pd.DataFrame, df: pd.DataFrame):
    # phase_date = datetime.strptime("14-10-2022", "%d-%m-%Y")
    # if(row["DISB_DATE"] <= phase_date):
    if(row["Consolidated State for Po processing"].lower() in ["chennai"]):
        broker_codes_a = [144063,
                        220001,
                        271170,
                        269496,
                        382965,
                        110214,
                        267936,
                        268354,
                        ]
        # broker_code_b = 110214
        
        if(row["DMABROKERCODE_y"] in broker_codes_a):
            # df = df[(df["DISB_DATE"] <= phase_date) & (df["DMABROKERCODE_y"] == row["DMABROKERCODE_y"]) & (df["Consolidated State for Po processing"] == row["Consolidated State for Po processing"])]
            # state=["chennai", "rotn"]
            # df = df[(df["DMABROKERCODE_y"] == row["DMABROKERCODE_y"]) & ((df["Consolidated State for Po processing"]str.lower() == "chennai") | (df["Consolidated State for Po processing"]str.lower() == "rotn"))]
            # df = df[(df["DMABROKERCODE_y"] == row["DMABROKERCODE_y"]) & ((df["Consolidated State for Po processing"]str.lower() == "chennai") | (df["Consolidated State for Po processing"]str.lower() == "rotn"))]
            
            df=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]
            df["AMTFIN*PRETAXIRR"]=df["AMTFIN"]*df["PRETAXIRR"]
            result=df["AMTFIN*PRETAXIRR"].sum()
            # result2=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]["PRETAXIRR"].sum()
            # result3=result1*result2
            
            result4=df.loc[(df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354])) & ((df["Consolidated State for Po processing"].str.lower()=="chennai"))]["AMTFIN"].sum()
            # gp = df.groupby(["DMABROKERCODE_y"])[["AMTFIN*PRETAXIRR", "AMTFIN"]].sum().reset_index()
            

            # result = gp["AMTFIN*PRETAXIRR"]
            wirr = float(round((result / result4), 2))
            # print(len(wirr))
            tad = df[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354]))]["AMTFIN"].sum()
            pf=df[(df["Consolidated State for Po processing"].str.lower() == "chennai") & (df["DMABROKERCODE_y"].isin([144063, 220001, 271170, 269496, 382965, 110214, 267936, 268354]))]["PROCESSINGFEE"].sum()
            po=round((pf/tad)*100,2)

            row["Override Rate"], row["Override Remark"],row["Reduction In Rate"] = override27A(row, wirr,po)
        

    
    return row
        
            
def override27A(row: pd.DataFrame, wirr,po):
    wirr = wirr
    po_rate = row["Override Rate"]
    remark = row["Override Remark"]
    tenure = row["TENURE_y"]
    reduction=row["Reduction In Rate"]
    
    if(wirr >= 9.10):
        po_rate = 0.0150
        remark += "27, "
    if(wirr >= 9.25):
        po_rate = 0.0175
        remark += "27, "
    if(wirr >= 9.40):
        po_rate = 0.0225
        remark += "27, "

    if tenure <= 23:
        po_rate = 0
        row["Exclude Remark"] = "Tenure<=23months"
    # elif 24 <= tenure <= 35:
    #     po_rate = 0.005        
    # if(po < 0.40):
    #     reduction =+ 0.001
    
    return po_rate, remark,reduction



# def override27B(row: pd.DataFrame, wirr: float):
#     wirr = wirr
#     po_rate = row["Override Rate"]
#     remark = row["Override Remark"]
    
#     if(wirr >= 8.60):
#         po_rate = 0.0200
#         remark += "27, "
#     elif(wirr >= 8.50):
#         po_rate = 0.0175
#         remark += "27, "
#     elif(wirr >= 8.40):
#         po_rate = 0.0120
#         remark += "27, "
        
#     return po_rate, remark