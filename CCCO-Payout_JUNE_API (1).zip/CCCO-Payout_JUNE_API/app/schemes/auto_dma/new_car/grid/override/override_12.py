import pandas as pd

def override12(row: pd.DataFrame):
    code=[179033, 270834, 268262, 269465, 269467, 269469]
    code1=[104980]
    # if(row["TENURE_y"]<36):
    #     return row
     
    if((row["DMABROKERCODE_y"] in code) & (row["Consolidated State for Po processing"].lower() == 'gujarat')):
        if("one" in row["Override Remark"]):
            row["Addition In Rate"] = (row["Override Rate"] * 0.09)
            row["Override Remark"] += "12"  
        else:
            row["Addition In Rate"] = (row["Base Rate"] * 0.09)
            row["Override Remark"] += "12, "
            
    if((row["DMABROKERCODE_y"] in code1) & (row["Consolidated State for Po processing"].lower() == 'gujarat')):
        if (row["Override Rate"]==0):

            row["Addition In Rate"] = (row["Base Rate"] * 0.09)
            row["Override Remark"] += "12, "
        
    return row