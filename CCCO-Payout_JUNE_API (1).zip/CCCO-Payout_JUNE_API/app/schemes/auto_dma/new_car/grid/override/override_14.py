import pandas as pd
from datetime import datetime

def override14(row: pd.DataFrame):
    broker_code = 266338
    if(row["DMABROKERCODE_y"] != broker_code):
        return row
    row["Override Rate"] = 0
    
    row["Override Remark"] += "14, "
    
    # if(row["TotalPF"] < 0.45):
    #     row["Reduction In Rate"] += 0.0010
    if(row["TENURE_y"] <= 23):
        row["Override Rate"] = 0
        row["Exclude Remark"] = "Tenure<=23months"
    elif(row["TENURE_y"] <= 35):
        row["Override Rate"] = 0.0050
    else:
        # if(row['Total Applicable Disbursement'] >= 30000000):
        # phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
        # if(row["DISB_DATE"] <= phase_date):
        # row["Base Rate"] = override14A(row)
        # if(row['Total Applicable Disbursement'] < 50000000):
        #         row["Reduction In Rate"] += 0.0015
        # else:
        row["Base Rate"] = override14B(row)
        if(row['Total Applicable Disbursement'] < 100000000):
                row["Reduction In Rate"] += 0.0015
    
    return row
    
    
def override14A(row: pd.DataFrame):    
    grid = {'rate_min': [8.75, 8.85, 9.00, 9.10, 9.30, 9.10, 9.25, 9.40, 9.60],
            'rate_max': [8.85, 9.00, 9.10, 9.30, 101.00, 9.25, 9.40, 9.60, 101.0],
            'po': [0.75, 1.25, 1.50, 1.60, 1.70, 1.70, 1.85, 2.00, 2.10],
            'segment': [1, 1, 1, 1, 1, 2, 2, 2, 2]
            }

    grid = pd.DataFrame(grid)

    segment = {
        "A+": 1,
        'A': 2, 
        'B+': 2, 
        'B': 2, 
        'C': 2
    }

    irr = row['Irr roundup']
    
    po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["po"]
    if(po.shape[0] != 0):
        po = float(po)
    else:
        po = 0

    # Handling the band A from the grid

    if((irr >= 8.95) & (irr < 9.00) & (row["Segment"] == "A")):
            po = 1.50

    if((irr >= 9.00) & (irr < 9.10) & (row["Segment"] in ["A", "C"])):
            po = 1.60
            
    channelCode = ""
    if("stp" in row['CHANNELCODE1'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE1'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE1"].lower()):
        channelCode = "pa"
    # elif(("aip" in row['CHANNELCODE'].lower())):
    #     channelCode = "aip"
    elif("ftu" in row['CHANNELCODE1'].lower()):
        channelCode = "ftu"
    elif("pragati" in row['CHANNELCODE1'].lower()):
        channelCode = "pragati"
    
    if(channelCode in ["pragati", "ftu"]):
        if(irr >= 9.90):
                po = 2.00
        else:
            po = 0
            
    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.75):
            po = max(0.90, po)
            
    if((row["EV Band"]=="EV Band")):
        if(("fleet" not in row["CHANNELCODE1"].lower()) & ("ftu" not in row["CHANNELCODE1"].lower()) & ("taxi" not in row["CHANNELCODE1"].lower())):
            if((row["Irr roundup"] >= 8.75) & (row["TENURE_y"] >= 36)):
                if (po==0):
                    if(row["Override Rate"]==0):
                        if(row["CHANNELCODE1"]=="AUTO SPECIAL SCHEME-KERALA"):
                            po=0
                        elif(channelCode in ["stp", "alpa", "pa"]):
                            po = max(0.90, po)
                        else:
                            po=0.5
                            row["Override Remark"] += "14A, "
    
    return (po / 100)


def override14B(row: pd.DataFrame):
    grid = {'rate_min': [8.85, 8.95, 9.10, 9.20, 9.40, 9.30, 9.40, 9.60, 9.80],
            'rate_max': [8.95, 9.10, 9.20, 9.40, 101.00, 9.40, 9.60, 9.80, 101.0],
            'po': [0.75, 1.25, 1.50, 1.60, 1.70, 1.70, 1.85, 2.00, 2.10],
            'segment': [1, 1, 1, 1, 1, 2, 2, 2, 2]
            }

    grid = pd.DataFrame(grid)

    segment = {
        "A+": 1,
        'A': 2, 
        'B+': 2, 
        'B': 2, 
        'C': 2
    }

    irr = row['Irr roundup']
    
    po = grid.loc[(grid['rate_min'] <= irr) & (grid['rate_max'] > irr) & (grid['segment'] == segment[row['Segment']])]["po"]
    if(po.shape[0] != 0):
        po = float(po)
    else:
        po = 0

    # Handling the band A from the grid

    if((irr >= 9.15) & (irr < 9.20) & (row["Segment"] == "A")):
            po = 1.50
    
    if((irr >= 9.20) & (irr < 9.30) & (row["Segment"] in ["A", "C"])):
            po = 1.60
            
    channelCode = ""
    if("stp" in row['CHANNELCODE1'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE1'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE1"].lower()):
        channelCode = "pa"
    elif(("aip_pragati" in row['CHANNELCODE1'].lower())):
        channelCode = "aip"
    elif("ftu" in row['CHANNELCODE1'].lower()):
        channelCode = "ftu"
    elif("pragati" in row['CHANNELCODE1'].lower()):
        channelCode = "pragati"
    
    if(channelCode in ["aip","pragati", "ftu"]):
        if(irr >= 10.00):
                po = 2.00
        else:
            po = 0
            
    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.85):
            po = max(0.90, po)
            
    if((row["EV Band"]=="EV Band")):
        if(("fleet" not in row["CHANNELCODE1"].lower()) & ("ftu" not in row["CHANNELCODE1"].lower()) & ("taxi" not in row["CHANNELCODE1"].lower())):
            if((row["Irr roundup"] >= 8.85) & (row["TENURE_y"] >= 36)):
                if (po==0):
                    if(row["Override Rate"]==0):
                        if(row["CHANNELCODE1"]=="AUTO SPECIAL SCHEME-KERALA"):
                            po=0
                        elif(channelCode in ["stp", "alpa", "pa"]):
                            po = max(0.90, po)
                        else:
                            po=0.5
                            row["Override Remark"] += "14B, "
    
    return (po / 100)