from datetime import datetime
import pandas as pd

def override52(row: pd.DataFrame):
    # phase_date = datetime.strptime("8-1-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] > phase_date):
    #     return row
    
    if(row["Consolidated State for Po processing"].lower() != "bangalore"):
        return row

    broker_list = 164968
    if(row["DMABROKERCODE_y"]==broker_list):
        if ((row["Irr roundup"]>=8.75) & (row["Irr roundup"] < 8.90) & (row["TENURE_y"]>=36)):
            row["Override Rate"] = 0.0025
            row["Override Remark"] += "52, "
            
    broker_list = 171062
    if(row["DMABROKERCODE_y"]==broker_list):
        if ((row["Irr roundup"]>=8.90) & (row["Irr roundup"] < 9.00) & (row["TENURE_y"]>=36)):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "52, "
        if ((row["Irr roundup"]>=9.00) & (row["TENURE_y"]>=36)):
            row["Override Rate"] = 0.0200
            row["Override Remark"] += "52, "

    return row        
            