import pandas as pd

def override13(row: pd.DataFrame):
    grid = {
        101402: "telangana", 
        239300: "karnataka", 
        245368: "hyderabad", 
        274716: "bangalore", 
        274696: "rotn", 
        274696: "kerala", 
        274911: "pune", 
        274911: "telangana", 
        274911: "telangana", 
        245369: "hyderabad", 
        245732: "hyderabad"
    }
    
    if(row["DMABROKERCODE_y"] in grid.keys()):
        if((row["Consolidated State for Po processing"].lower() == grid[row["DMABROKERCODE_y"]]) & (row["WIRR"] >= 9.15)):
            row["Override Rate"] = 0.0250
            row["Override Remark"] += "13, "
            
    return row
            