from pandas import DataFrame
from datetime import datetime


def override3(row: DataFrame):
    phase_date = datetime.strptime("14-4-2023", "%d-%m-%Y")
    if(row["DISB_DATE"] > phase_date):
        return row

    if(row["TENURE_y"] < 36):
        return row

    broker = [263243,
            287762,
            287761,
            287763,
            287764,
            287765,
            287767,
            287769,
            287777,
            287778,
            287779,
            287780,
            287781,
            287782,
            287783,
            287784,
            287936,
            287938,
            287939,
            287940,
            287987,
            292929,
            292931,
            ]

    if((row["DMABROKERCODE_y"] in broker)):
        segment = row["Segment"]
        irr = row["Irr roundup"]
        rate = row["Override Rate"]
        if row['Total Applicable Disbursement'] < 50000000:
            if(segment == "A+"):
                if(irr < 8.75):
                    rate = 0
                elif(irr < 8.85):
                    rate = 0.0050
                elif(irr < 9.00):
                    rate = 0.0100
                elif(irr < 9.10):
                    rate = 0.0125
                elif(irr < 9.30):
                    rate = 0.0135
                else:
                    rate = 0.0145
            else:
                if(irr < 9.10):
                    rate = 0
                elif(irr < 9.25):
                    rate = 0.0145
                elif(irr < 9.40):
                    rate = 0.0160
                elif(irr < 9.60):
                    rate = 0.0175
                # elif(irr < 9.50):
                #     rate = 0.0160
                else:
                    rate = 0.0185
                # elif(irr < 9.85):
                #     rate = 0.0185
                # else:
                #     rate = 0.0205

            if(segment == "A"):
                if((irr >=8.95) & (irr < 9)):
                    rate = 0.0125

            if(segment in ["A","C"]):
                if((irr >=9.00) & (irr < 9.10)):
                    rate = 0.0135

            channelcode = row["CHANNELCODE1"].lower()

            if(("aip" in channelcode) | ("ftu" in channelcode) | ("pragati" in channelcode)):
                if(irr >= 9.90):
                    rate = 0.0180
            
            if(("stp" in channelcode) | ("alpa" in channelcode) | ("pa_" in channelcode)):
                if(irr >= 8.75):
                    rate = max(0.0050, rate)
                    
                    
        if row['Total Applicable Disbursement'] >= 50000000:
            if(segment == "A+"):
                if(irr < 8.75):
                    rate = 0
                elif(irr < 8.85):
                    rate = 0.0065
                elif(irr < 9.00):
                    rate = 0.0110
                elif(irr < 9.10):
                    rate = 0.0135
                elif(irr < 9.30):
                    rate = 0.0145
                else:
                    rate = 0.0155
            else:
                if(irr < 9.10):
                    rate = 0
                elif(irr < 9.25):
                    rate = 0.0155
                elif(irr < 9.40):
                    rate = 0.0170
                elif(irr < 9.60):
                    rate = 0.0185
                # elif(irr < 9.50):
                #     rate = 0.0160
                else:
                    rate = 0.0195
                # elif(irr < 9.85):
                #     rate = 0.0185
                # else:
                #     rate = 0.0205

            if(segment == "A"):
                if((irr >=8.95) & (irr < 9)):
                    rate = 0.0135

            if(segment in ["A","C"]):
                if((irr >=9.00) & (irr < 9.10)):
                    rate = 0.0145

            channelcode = row["CHANNELCODE1"].lower()

            if(("aip" in channelcode) | ("ftu" in channelcode) | ("pragati" in channelcode)):
                if(irr >= 9.90):
                    rate = 0.0190
            
            if(("stp" in channelcode) | ("alpa" in channelcode) | ("pa_" in channelcode)):
                if(irr >= 8.75):
                    rate = max(0.0075, rate)

            # salary = row["Salaried"].lower()   

            # if(salary == "yes"):
            #     if(irr >= 8.45):
            #         rate = max(rate, 0.0075)

            row["Override Remark"] += "3, "
            row["Override Rate"] = rate
    
    return row