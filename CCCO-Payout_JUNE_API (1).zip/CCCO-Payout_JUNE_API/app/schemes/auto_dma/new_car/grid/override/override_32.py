from datetime import datetime
import pandas as pd

def override32(row:pd.DataFrame):
    # phase_date = datetime.strptime("8-1-2023", "%d-%m-%Y")
    # if(row["DISB_DATE"] > phase_date):
    #     return row
    
    if((row["Consolidated State for Po processing"].lower() != "bangalore")| (row["TENURE_y"]<=35)):
        return row

    # broker_list  = [167708, 173194, 112416, 295008, 267233, 164968, 266737, 294336, 141524, 174384, 171062, 104505, 155473, 101650, 304002, 164432, 108210, 256398, 173813, 273607, 227239, 295009, 261561, 172149, 179463]
    broker_list = [141524,
                    171062,
                    101650,
                    155473,
                    ]
    broker_list_1 = [164968,
                    266737,
                    294336,
                    256398,
                    179463,
                    ]
    broker_list_2 =[167708,
                    173194,
                    112416,
                    295008,
                    267233,
                    174384,
                    104505,
                    304002,
                    164432,
                    108210,
                    173813,
                    273607,
                    227239,
                    295009,
                    261561,
                    172149,
                    ]
    if(row["DMABROKERCODE_y"] in broker_list):
        # if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
        # if(row["Total Applicable Disbursement"] < 10000000):
            # row["Reduction In Rate"] += 0.0025
            # row["Override Remark"] += "32r, "     
        # if(row["TENURE_y"] < 36):
        #     row["Reduction In Rate"] += 0.0025
        #     row["Override Remark"] += "32, " 
        # else:
        if(((row["Irr roundup"]>=9.25))):
            row["Override Rate"] = 0.02
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 10000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "     
        elif(((row["Irr roundup"]>=9.00))):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 10000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "       
            
    if(row["DMABROKERCODE_y"] in broker_list_1):
        # if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
        # if(row["Total Applicable Disbursement"] < 30000000):
        #     row["Reduction In Rate"] += 0.0025
        #     row["Override Remark"] += "32r, "   
        # if(row["TENURE_y"] < 36):
        #     row["Reduction In Rate"] += 0.0025
        #     row["Override Remark"] += "32, " 
        # else:
        if(((row["Irr roundup"]>=9.25))):
            row["Override Rate"] = 0.02
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 30000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "     
        elif(((row["Irr roundup"]>=9.00))):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 30000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "     
            
    if(row["DMABROKERCODE_y"] in broker_list_2):
        # if(row["MANUFACTURERDESC"].lower() == "maruti suzuki india ltd") | (row["NAME"].lower() == "trident automobiles bangalore p ltd"):
        # if(row["Total Applicable Disbursement"] < 20000000):
                 
        # # if(row["TENURE_y"] < 36):
        #     row["Reduction In Rate"] += 0.0025
        #     row["Override Remark"] += "32r, " 
        # else:
        if(((row["Irr roundup"]>=9.25))):
            row["Override Rate"] = 0.02
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 20000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "                 
        elif(((row["Irr roundup"]>=9.05))):
            row["Override Rate"] = 0.0125
            row["Override Remark"] += "32, "
            if(row["Total Applicable Disbursement"] < 20000000):
                row["Reduction In Rate"] += 0.0025
                row["Override Remark"] += "32r, "     





    return row