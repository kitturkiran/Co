
import pandas as pd

def override26(row: pd.DataFrame):
    broker_codes = [104566, 173503, 179283, 261656, 218674]
    
    if((row["Consolidated State for Po processing"].lower() == "mumbai") & (row["DMABROKERCODE_y"] in broker_codes) & 
       (row["Total Applicable Disbursement"] >= 30000000)):
        irr = row["Irr roundup"]
        
        if(row["MANUFACTURERDESC"].lower() in ["mg motor india pvt ltd", "audi"]):
            if(irr >= 8.50):
                row["Override Rate"] = 0.0175
                row["Override Remark"] += "26, "
            elif(irr >= 8.35):
                row["Override Rate"] = 0.0150
                row["Override Remark"] += "26, "
            elif(irr >= 8.25):
                row["Override Rate"] = 0.0125
                row["Override Remark"] += "26, "
                
    return row