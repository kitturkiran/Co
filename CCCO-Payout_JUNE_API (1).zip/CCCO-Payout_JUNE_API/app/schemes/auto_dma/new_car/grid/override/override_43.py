import pandas as pd

def override43(row: pd.DataFrame):
    grid = {
        291270: 0.0050, 
        223840: 0.0075, 
        191338: 0.0050, 
        197097: 0.0050, 
        213631: 0.0050, 
        198693: 0.0050, 
        205013: 0.0050, 
        297395: 0.0050, 
        193239: 0.0050
    }
    
    if((row["DMABROKERCODE_y"] in grid.keys()) & (row["Consolidated State for Po processing"].lower() == "ap/rotg")):
        row["Reduction In Rate"] += grid[row["DMABROKERCODE_y"]]
        row["Override Remark"] += "43, "
        
    return row