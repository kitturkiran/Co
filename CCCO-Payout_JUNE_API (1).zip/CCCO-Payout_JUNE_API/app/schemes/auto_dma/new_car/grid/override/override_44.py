import pandas as pd
from datetime import datetime

def override44(row: pd.DataFrame):
    # pf condition not to be applied
    if(row["DMABROKERCODE_y"] == 269302):
        if(row["TotalPF"] < 0.45):
            row["Reduction In Rate"] -= 0.0010
            row["Override Remark"] += "44, "
            
    # zh condition not to be applieed
    broker_codes = [266338, 269302, 275078]
    if(row["DMABROKERCODE_y"] in broker_codes):
        row = resetZH(row)
              
    return row

def resetZH(row : pd.DataFrame):

    phase_date = datetime.strptime("14-12-2022", "%d-%m-%Y")
    segment = row["Segment"]
    irr = row["Irr roundup"]
    channelCode = ""
    if("stp" in row['CHANNELCODE'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE'].lower()):
        channelCode = "alpa"
    elif("pa" in row["CHANNELCODE"].lower()):
        channelCode = "pa"

    if(row["DISB_DATE"] <= phase_date):
        if(segment == "A+") & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "A") & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "B") & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "B+") & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "C") & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        
        if(channelCode in ["stp", "alpa", "pa"]) & (irr < 8.10):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        if(("aip" in channelCode) | ("assessed income product" in channelCode) | ("pragati" in channelCode) | ("ftu" in channelCode) | ("fleet" in channelCode)) & (irr < 9.65):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        if(row["Salaried"].lower() == "yes") & (irr < 8.25):
            row["flag"] = 1
            row["Override Remark"] += "44, "
            
    else:
        if(segment == "A+") & (irr < 8.35):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "A") & (irr < 8.45):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "B") & (irr < 8.90):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "B+") & (irr < 8.70):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        elif(segment == "C") & (irr < 8.40):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        
        if(channelCode in ["stp", "alpa", "pa"]) & (irr < 8.25):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        if(("aip" in channelCode) | ("asessed income product" in channelCode) | ("pragati" in channelCode) | ("ftu" in channelCode) | ("fleet" in channelCode)) & (irr < 9.75):
            row["flag"] = 1
            row["Override Remark"] += "44, "
        if(row["Salaried"].lower() == "yes") & (irr < 8.35):
            row["flag"] = 1
            row["Override Remark"] += "44, "

    return row