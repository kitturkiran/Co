import pandas as pd

def override10(row : pd.DataFrame):
    if(row["TENURE_y"] < 36):
        return row

    # if("18A" in row["Override Remark"]):
    #     return row

    if("kerala" in row["Consolidated State for Po processing"].lower()):
        segment_band = ["A", "B+", "B", "C"]
        irr = row["Irr roundup"]
        rate = row["Override Rate"]
        rate1=row["Base Rate"]

        channelCode = ""
        if(("aip" in row['CHANNELCODE1'].lower()) | ("assessed income product" in row["CHANNELCODE1"].lower())):
            channelCode = "aip"
        if("auto special scheme-kerala" == row['CHANNELCODE'].lower()):
            channelCode = "ASSK"
        

        if(("aip_pragati" in row['CHANNELCODE1'].lower()) | ("pragati" in row["CHANNELCODE1"].lower()) | ("auto special scheme-kerala" in row["CHANNELCODE1"].lower())):
            if(irr < 9.10):
                rate = 0
            elif(irr < 9.25):
                rate = 0.0100
            elif(irr < 9.40):
                rate = 0.0125
            elif(irr < 9.65):
                rate = 0.0150
            elif(irr < 9.90):
                rate = 0.0175
            elif(irr < 10):
                rate = 0.0185
        
        if(row["Segment"] in segment_band):
            if(irr < 10.00):
                rate1 = row["Base Rate"]
            elif(irr < 10.25):
                rate1 = 0.0185
            elif(irr < 10.75):
                rate1 = 0.0200
            elif(irr < 11.25):
                rate1 = 0.0225
            elif(irr < 11.50):
                rate1 = 0.0250
            else:
                rate1 = 0.0275
        row["Override Rate"] = rate
        row["Base Rate"]=rate1
        row["Override Remark"] += "10, "

    return row