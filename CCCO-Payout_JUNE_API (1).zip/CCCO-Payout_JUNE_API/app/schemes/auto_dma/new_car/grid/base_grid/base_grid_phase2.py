import pandas as pd
from datetime import datetime

def BaseGridPhase2(row:pd.DataFrame):
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")

    # if(row["DISB_DATE"] <= phase_date):
    #     return row

    broker = row["DMABROKERCODE_y"]
    if(broker in [266338, 275078,316343]):
        return row
    
    base_rate = 0.0
    tenure = row["TENURE_y"]
    if tenure <= 23:
        base_rate = 0
        row["Exclude Remark"] = "Tenure<=23months"
    elif 24 <= tenure <= 35:
        base_rate = 0.005
    else:
        base_rate = baseRateGrid(row)
        
        # if(row["alto_cases"]==1):
        #         if ((row["Irr roundup"]>=9.00) & (row["Irr roundup"]<9.10)):
        #             if row['Total Applicable Disbursement'] >= 30000000:
        #                 base_rate=max(0.0160,base_rate)
        #                 row["Override Remark"] += "BaseGird2+Alto, "
                        
        #             elif row['Total Applicable Disbursement'] >= 10000000:
        #                 base_rate=max(0.0145,base_rate)
        #                 row["Override Remark"] += "BaseGird2+Alto, "
        #             else:
        #                 base_rate=max(0.0135,base_rate)
        #                 row["Override Remark"] += "BaseGird2+Alto, "
                
                
        
        
    
        
    row["Base Rate"] = base_rate
    return row

def baseRateGrid(row: pd.DataFrame):

    grid_top = {'rate_min': [8.85, 8.95, 9.10, 9.20, 9.40, 9.30, 9.40, 9.60, 9.80],
                'rate_max': [8.95, 9.10, 9.20, 9.40, 101.0, 9.40, 9.60, 9.80, 101.0],
                'cat3': [0.75, 1.25, 1.50, 1.60, 1.70 ,1.70, 1.85, 2.00, 2.10],
                'cat2': [0.65, 1.10, 1.35, 1.45, 1.55, 1.55, 1.70, 1.85, 1.95],
                'cat1': [0.50, 1.00, 1.25, 1.35, 1.45, 1.45, 1.60, 1.75, 1.85],
                'segment': [1, 1, 1, 1, 1, 2, 2, 2, 2]
                }

    grid_top = pd.DataFrame(grid_top)

    segment = {
        "A+": 1,
        'A': 2, 
        'B+': 2, 
        'B': 2, 
        'C': 2,
    }
    
    if row['Total Applicable Disbursement'] >= 30000000:
        category = "cat3"
    elif row['Total Applicable Disbursement'] >= 10000000:
        category = "cat2"
    else:
        category = "cat1"
        
    irr = row['Irr roundup']
    
    po = grid_top.loc[(grid_top['rate_min'] <= irr) & (grid_top['rate_max'] > irr) & (grid_top['segment'] == segment[row['Segment']])][category]
    if(po.shape[0] != 0):
        po = float(po)
    else:
        po = 0

    # Handling the band A from the grid

    if(((irr >= 9.15) & (irr < 9.20)) & (row["Segment"] == "A")):
        
        if(category == "cat3"):
            po = 1.50
        elif(category == "cat2"):
            po = 1.35
        else:
            po = 1.25
        row["Override Remark"] += "BaseGird2, "
    
    # Handling the band A & C from the grid

    if((irr >= 9.20) & (irr < 9.30) & (row["Segment"] in ["A","C"])):
        if(category == "cat3"):
            po = 1.60
        elif(category == "cat2"):
            po = 1.45
        else:
            po = 1.35
            
    channelCode = ""
    if("stp" in row['CHANNELCODE1'].lower()):
        channelCode = "stp"
    elif("alpa" in row['CHANNELCODE1'].lower()):
        channelCode = "alpa"
    elif("pa_" in row["CHANNELCODE1"].lower()):
        channelCode = "pa"
    elif(("aip" in row['CHANNELCODE1'].lower())):
        channelCode = "aip"
    elif("ftu" in row['CHANNELCODE1'].lower()):
        channelCode = "ftu"
    elif("pragati" in row['CHANNELCODE1'].lower()):
        channelCode = "pragati"

    if(channelCode in ["aip","pragati", "ftu"]):

        if(irr >= 10.00):
            if(category == "cat1"):
                po = 1.80
            elif(category == "cat2"):
                po = 1.90
            else:
                po = 2.00
        else:
            po = 0

    if(channelCode in ["stp", "alpa", "pa"]):
        if(irr >= 8.85):
            if(category == "cat1"):
                po = max(0.50, po)
            elif(category == "cat2"):
                po = max(0.75, po)
            else:
                po= max(0.90, po)
                
    # salary = row["Salaried"].lower()   

    # if(salary == "yes"):
    #     if(irr >= 8.35):
    #         if(category == "cat1"):
    #             po = max(0.75, po)
    #         elif(category == "cat2"):
    #             po = max(0.85, po)
    #         else:
    #             po= max(1.00, po)
    
    
    
    
    return (float(po) / 100)