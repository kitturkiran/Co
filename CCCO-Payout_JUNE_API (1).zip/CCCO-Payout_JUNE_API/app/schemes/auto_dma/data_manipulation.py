from datetime import datetime
import pandas as pd


class DataManipulation:
    def __init__(self, dma_df: pd.DataFrame,start_date,end_date):
        self.dma_df = dma_df
        self.dma_df["flag"] = 1
        self.dma_df["Exclude Remark"] = "-"
        self.start_date=start_date
        self.end_date=end_date
        

        

    def classifyLAN(self):
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("LA") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("LU") == False) & (self.dma_df["AGREEMENTNO"].str.startswith(
            "LP") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("SP") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("UP") == False), ["flag", "Exclude Remark"]] = [0, "Not Used Nor New Car"]

    def outOfCycle(self):
        self.dma_df["DISB_DATE"] = pd.to_datetime(self.dma_df["DISB_DATE"], format="%m/%d/%Y")
        # self.start_date = datetime.strptime("5-1-2023", "%m-%d-%Y")
        # self.end_date = datetime.strptime("5-31-2023", "%m-%d-%Y")
        self.dma_df.loc[((self.dma_df["DISB_DATE"] > self.end_date) == True) | ((self.dma_df["DISB_DATE"] < self.start_date) == True), ["flag", "Exclude Remark"]] = [0, "Out Of Cycle"]
                
    def status(self):
        self.dma_df.loc[self.dma_df["STATUS"].str.lower() != "a", ["flag", "Exclude Remark"]] = [0, "Status Not A"]

    def rbk(self):
        self.dma_df.loc[self.dma_df['FILENO'].str.lower().str.contains("rbk")== True, ["flag", "Exclude Remark"]] = [0, "File No RBK"]

    def generalName(self):
        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("alternate channel") == True, ["flag", "Exclude Remark"]] = [0, "ALternate Channel"]

        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("dma not available") == True, ["flag", "Exclude Remark"]] = [0, "DMA Not Available"]

        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("sfa") == True, ["flag", "Exclude Remark"]] = [0, "SFA"]

        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("dukaan") == True, ["flag", "Exclude Remark"]] = [0, "Dukaan"]

        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("paisa bazar"), ["flag", "Exclude Remark"]] = [0, "Paisa Bazar"]
        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("paisabazaar"), ["flag", "Exclude Remark"]] = [0, "Paisa Bazar"]
        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("online asset"), ["flag", "Exclude Remark"]] = [0, "Online Asset"]
        
        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("online"), ["flag", "Exclude Remark"]] = [0, "Online"]
        
        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("direct cases"), ["flag", "Exclude Remark"]] = [0, "Direct Cases"]

        self.dma_df.loc[self.dma_df["NAME"].str.startswith("BRANCH") == True, ["flag", "Exclude Remark"]] = [0, "Branch"]

        self.dma_df.loc[self.dma_df["NAME"].str.lower().str.contains("bor & dst") == True, ["flag", "Exclude Remark"]] = [0, "Bor & Dst"]

    def novation(self):
        self.dma_df.loc[self.dma_df["SCHEMECODE"].str.lower().str.contains(
            "novation") == True, "flag"] = 0

    def deathNabard(self):
        for col in self.dma_df.columns:
            self.dma_df.loc[(self.dma_df[col].astype(str).str.lower() == "death") | (
                self.dma_df[col].astype(str).str.lower().str.contains("nabard")), ["flag", "Exclude Remark"]] = [0, "Death & Nabard"]

    def demoSpectra(self):
        self.dma_df.loc[(self.dma_df['PROMOTIONDESC'].str.lower() == "demo") | (
            self.dma_df['PROMOTIONDESC'].str.lower() == "spectra"), ["flag", "Exclude Remark"]] = [0, "Demo or Spectra"]

    def removeFlag(self):
        self.dma_df = self.dma_df.loc[(self.dma_df["flag"] != 0)]

    def executeCleaning(self):
        self.classifyLAN()
        self.outOfCycle()
        self.status()
        self.rbk()
        self.generalName()
        self.novation()
        self.deathNabard()
        self.demoSpectra()
        self.removeFlag()
        return self.dma_df

        
