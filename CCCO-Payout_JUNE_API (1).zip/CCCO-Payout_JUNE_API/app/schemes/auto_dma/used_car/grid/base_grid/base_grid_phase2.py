import pandas as pd
from datetime import datetime

def BaseGridPhase2(row: pd.DataFrame):    
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")

    if((row["Consolidated State for Po processing"].lower()=="gurgaon") & (row["DMABROKERCODE_y"]==271161)):
        return row
    
    if((row["Consolidated State for Po processing"].lower()=="gurgaon") & (row["DMABROKERCODE_y"]==310089)):
        return row
    

    rate = 0

    if((row["TENURE_y"] <= 15)):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 35):
            row["Reduction In Rate"] = 0.0050
        
        if(((row["PROCHANNEL"] == "sale purchase") | (row["PROCHANNEL"] == "refinance"))):
            rate = gridCalculation1(row)
        elif(((row["PROCHANNEL"] == "maxx") | (row["PROCHANNEL"] == "external"))):
            rate = gridCalculation2(row)
        elif((row["PROCHANNEL"] == "topup")):
            rate = gridCalculation3(row)
        elif((row["PROCHANNEL"] == "inbt")):
            rate = gridCalculation4(row)

    if((row["TotalPF"] < 0.90)):
        # if((row["DMABROKERCODE_y"]!=213292)):
        row["Reduction In Rate"] += 0.0010

    if((("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower()))):
        if(row["Irr roundup"] >= 11.25):
            rate = max(rate, 0.0100)

    if((row["Top/TierII"] == "Tier II")):

        if((("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())) == False):
            row["Reduction In Rate"] += 0.0025

    # if (row["PROCHANNEL"] == "insta"):
    #     rate = 0.01
    # if(row["CHANNELCODE"] == "ALPA- Insta Top Up"):
    #     rate = 0.01 
    # if(row["CHANNELCODE"] == "ALPA- Insta Money"):
    #     rate = 0.01 
    if(row["TENURE_y"]<=15):
        rate=0.0000     
    
    row["Base Rate"] = rate

    return row


def gridCalculation1(row: pd.DataFrame):
    grid = {
        'rate_min': [11.25, 11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25],
        'rate_max': [11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25, 101.0],
        'cat1': [0, 0, 0, 0, 0, 2.25, 2.50, 3.00, 3.50, 3.75, 4.00],
        'cat2': [0, 0, 0, 1.00, 2.25, 2.50, 3.00, 3.25, 3.75, 4.00, 4.25],
        'cat3': [0, 1.75, 2.00, 2.25, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50],
        'cat4': [2.00, 2.00, 2.25, 2.50, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    cat = ""
    if(row["AMTFIN"] < 500000):
        cat = "cat1"
    elif(500000 <= row["AMTFIN"] < 1000000):
        cat = "cat2"
    elif(1000000 <= row["AMTFIN"] < 2000000):
        cat = "cat3"
    elif(row["AMTFIN"] >= 2000000):
        cat = "cat4"

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)


def gridCalculation2(row: pd.DataFrame):
    grid = {
        'rate_min': [14.50, 15.00, 15.50, 16.00, 16.50],
        'rate_max': [15.00, 15.50, 16.00, 16.50, 101.0],
        'payout': [3.00, 3.50, 4.00, 4.25, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)


def gridCalculation3(row: pd.DataFrame): 
    grid = {
        'rate_min': [15.50, 16.00, 16.50],
        'rate_max': [16.00, 16.50, 101.0],
        'payout': [0.50, 1.00, 1.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0

    return (float(rate) / 100)


def gridCalculation4(row: pd.DataFrame):
    grid = {
        'rate_min': [14.50, 15.00, 15.50, 16.00, 16.50],
        'rate_max': [15.00, 15.50, 16.00, 16.50, 101.0],
        'payout': [2.00, 2.50, 3.00, 3.50, 4.00]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0

    return (float(rate) / 100)

def nillPayout(row: pd.DataFrame):
    row["Reduction In Rate"] = 0
    row["Base Rate"] = 0

