import pandas as pd

def override31(row:pd.DataFrame,df):
    broker_code=[271161]
    broker_code1=[310089]
    if((row["Consolidated State for Po processing"].lower()=="gurgaon") & (row["DMABROKERCODE_y"] in broker_code)):
        
        # if(row["AMTFIN"]<= 1000000):
            
            if(row["Irr roundup"]>=10.50):
                row["Override Rate"]=0.0150
                row["Override Remark"] += "31, "
            else:
                row["Base Rate"]=0
                row["Override Rate"]=0
            tad = df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([271161]))]["AMTFIN"].sum()
            pf=df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([[271161]]))]["PROCESSINGFEE"].sum()
            po=round((pf/tad)*100,2)
            if(po < 0.90):
                row["Reduction In Rate"] =+ 0.001
                
                
    if((row["Consolidated State for Po processing"].lower()=="gurgaon") & (row["DMABROKERCODE_y"] in broker_code1)):
        
        # if(row["AMTFIN"]<= 1000000):
            
            if(row["Irr roundup"]>=11.50):
                row["Override Rate"]=0.0275
                row["Override Remark"] += "31, "
            else:
                row["Base Rate"]=0
                row["Override Rate"]=0
            
            tad = df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([310089]))]["AMTFIN"].sum()
            pf=df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([[310089]]))]["PROCESSINGFEE"].sum()
            po=round((pf/tad)*100,2)
            print(po)
            if(po < 0.90):
                row["Reduction In Rate"] =+ 0.001
            
    return row

