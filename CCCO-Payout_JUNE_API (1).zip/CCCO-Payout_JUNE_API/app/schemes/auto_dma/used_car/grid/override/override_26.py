import pandas as pd

def override26(row:pd.DataFrame):
    broker_code=[262441,
                 225763,
                 239016,
                 194288,
                 305040,
                 304592,
                 270915,
                 306961,
                 199693,
                 238040,
                 258363,
                 183109,
                 215228,
                 207298,
                 304902,
                 244151,
                 186823,
                 207714,
                 188663,
                 207711,
                 194228,
                 231917,
                 101811,
                 101640,
                 271163,
                 308231,
                 304687,
                 314862,
                 317169,
                 215902,
                 ]
    
    state_list=["JALANDHAR",
                "JALANDHAR",
                "AMRITSAR",
                "JALANDHAR",
                "JALANDHAR",
                "JALANDHAR",
                "AMRITSAR",
                "JALANDHAR",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "LUDHIANA",
                "JALANDHAR",
                "AMRITSAR",
                "AMRITSAR",
                "LUDHIANA",
                "MANDI GOBINDGARH",
                "LUDHIANA",
                "LUDHIANA",
                ]
    broker = row["DMABROKERCODE_y"]
    state = row["BRANCHNM"]
    for i in range(len(broker_code)):
        if(broker == broker_code[i]) & (state == state_list[i]):
            row["special Reduction"]=0.0025
            row["Override Remark"] += "26, "
        
        
        
        
    return row