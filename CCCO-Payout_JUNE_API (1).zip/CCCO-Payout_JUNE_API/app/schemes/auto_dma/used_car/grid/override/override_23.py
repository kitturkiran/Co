import pandas as pd
from datetime import datetime

def override23(row: pd.DataFrame):
    broker_code = 213292

    if((row["DMABROKERCODE_y"] != broker_code)):
        return row
    
    rate = row["Base Rate"]
    irr = row["Irr roundup"]

    if(row["TENURE_y"] <= 15):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 35):
            row["Reduction In Rate"] = 0.0050
        elif(row["TENURE_y"] >= 35):
            row["Reduction In Rate"] = 0.0000
        
        if((row["PROCHANNEL"] == "sale purchase") & (row["TENURE_y"] > 36)):
            if (row["AMTFIN"] < 1000000):
                if (row[irr>13.00]):
                    rate=4.5
            if (1000000<= row["AMTFIN"] < 2000000):    
                if (row[irr>12.25]):
                    rate=4.5
            if (row["AMTFIN"] > 2000000):    
                if (row[irr>12.00]):
                    rate=4.5
    rate=(float(rate) / 100)    
    row["Base Rate"] = rate
    row["Override Remark"] += "23, "
    
    return row
    
