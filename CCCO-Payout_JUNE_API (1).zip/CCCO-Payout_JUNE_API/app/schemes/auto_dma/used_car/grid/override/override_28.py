import pandas as pd

def override28(row:pd.DataFrame):

    if((row["Consolidated State for Po processing"].lower()=="chennai") & (row["PROCHANNEL"]=="sale purchase") & (row["DMABROKERCODE_y"]==231992)):
        
        
        if(row["Irr roundup"]<12.50):
            row["Base Rate"]=0.00
            row["Override Rate"]=0.00
            row["Reduction In Rate"]=0
            row["Override Remark"] += "28, "       
    
        if(row["Irr roundup"]>=12.50):
            row["Override Rate"]=0.0275
            row["Reduction In Rate"]=0
            row["Override Remark"] += "28, "
        if(row["Irr roundup"]>=12.75):
            row["Override Rate"]=0.0350
            row["Reduction In Rate"]=0
            row["Override Remark"] += "28, "
            
            
    return row