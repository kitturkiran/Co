import pandas as pd

def override29(row:pd.DataFrame):
    broker_code=[
                171659,
                194573,
                197846,
                183737,
                175552,
                207040,
                207946,
                208632,
                208859,
                212170,
                219020,
                237300,
                233542,
                247235,
                221664,
                271164,
                271690,
                284417,
                283995,
                285899,
                286991,
                289186,
                297632,
                272353,


                ]
    if((row["Consolidated State for Po processing"].lower()=="chennai")):
        if(row["PROCHANNEL"] in ["topup","inbt"]):
            return row
        
        if("dsa" in row["Sourcing"].lower()):
            if (row["DMABROKERCODE_y"] in broker_code):
                row["Reduction In Rate"] += 0.0035
                row["Override Remark"] += "29, "
                
                
    return row
                
            
            