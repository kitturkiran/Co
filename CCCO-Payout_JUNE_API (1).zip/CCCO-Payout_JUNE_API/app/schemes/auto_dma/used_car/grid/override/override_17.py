import pandas as pd
from datetime import datetime

def override17(row: pd.DataFrame):
    broker_code = 266338
    
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
    if((row["DMABROKERCODE_y"] != broker_code)):
        return row
    
    rate = row["Base Rate"]

    if(row["TENURE_y"] <= 15):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 35):
            row["Reduction In Rate"] = 0.0050
        
        if(row["PROCHANNEL"] == "topup"):
            rate = gridCalculation1(row)
        elif(row["PROCHANNEL"] == "inbt"):
            rate = gridCalculation2(row)
        
    if(row["TotalPF"] < 0.90):
        row["Reduction In Rate"] += 0.0010
    
    if(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())):
        if((row["PROCHANNEL"]=="topup") | (row["PROCHANNEL"]=="inbt")):
            if(row["Irr roundup"] >= 11.25):
                rate = max(rate, 0.0100)

   
    if((row["Top/TierII"] == "Tier II")):
    
        if((("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())) == False):
            row["Reduction In Rate"] += 0.0025
        
    # if (row["PROCHANNEL"] == "insta"):
    #     rate = 0.01

    if(row["TENURE_y"]<=15):
        rate=0.0000 
    
    row["Base Rate"] = rate
    row["Override Remark"] += "17, "
    
    return row

def gridCalculation1(row: pd.DataFrame):
    grid = {
        'rate_min': [15.50, 16.00, 16.50],
        'rate_max': [16.00, 16.50, 101.0],
        'payout': [0.50, 1.00, 1.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0

    return (float(rate) / 100)


def gridCalculation2(row: pd.DataFrame):
    grid = {
        'rate_min': [14.50, 15.00, 15.50, 16.00, 16.50],
        'rate_max': [15.00, 15.50, 16.00, 16.50, 101.0],
        'payout': [2.00, 2.50, 3.00, 3.50, 4.00]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)