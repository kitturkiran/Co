import pandas as pd

def override11(row:pd.DataFrame):

    broker_list = [186123, 236120, 252711, 290622, 187519, 233371, 238332, 244992, 290620]

    if((row["Consolidated State for Po processing"].lower() == "rowb") | (row["Consolidated State for Po processing"] == "Kolkata")):
        if(row["DMABROKERCODE_y"] in broker_list):
            row["Reduction In Rate"] += 0.0035
            row["Override Remark"] += "11, "

    return row
