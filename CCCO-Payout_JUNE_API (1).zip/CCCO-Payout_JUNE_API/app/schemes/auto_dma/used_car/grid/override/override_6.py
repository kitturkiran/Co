import pandas as pd
from datetime import datetime

def override6(row: pd.DataFrame):   
    broker_code=[266338,269302,275078]
    phase_date = datetime.strptime("14-10-2022", "%d-%m-%Y")
    if((row["DISB_DATE"] <= phase_date)):
        return row

    rate = row["Override Rate"]
    rate = row["Base Rate"]
    # if(row["DMABROKERCODE_y"] in broker_code):
    #     return row
    # rate = row["Override Rate"]
    if (((row["PROCHANNEL"] == "inbt") | (row["CHANNELCODE"]=="EXTERNAL TOPUP_EMI MULTIPLIER")) & (row["Override Remark"]=="-")):
        #   rate = row["Override Rate"]
        #   rate = row["Base Rate"]
        if ((row["Segment"]=="A+") & (row["Irr roundup"] < 13.74)):
            rate=0
        if ((row["Segment"]=="A") & (row["Irr roundup"] < 14.49)):
            rate=0
        if ((row["Segment"]=="B+") & (row["Irr roundup"] < 14.74)):
            rate=0
        if ((row["Segment"]=="B") & (row["Irr roundup"] < 14.99)):
            rate=0
        if ((row["Segment"]=="C") & (row["Irr roundup"] < 14.24)):
            rate=0

    if ((row["PROCHANNEL"] == "maxx") & (row["Override Remark"]=="-")):
        if ((row["Segment"]=="A+") & (row["Irr roundup"] < 13.74)):
            rate=0
        if ((row["Segment"]=="A") & (row["Irr roundup"] < 14.49)):
            rate=0
        if ((row["Segment"]=="B+") & (row["Irr roundup"] < 14.74)):
            rate=0
        if ((row["Segment"]=="B") & (row["Irr roundup"] < 14.99)):
            rate=0
        if ((row["Segment"]=="C") & (row["Irr roundup"] < 14.24)):
            rate=0

    
    if ((row["PROCHANNEL"]=="topup") & (row["Override Remark"]=="-")):
        if ((row["Salaried"]=="Yes") & (row["Irr roundup"] < 14.24)):
            rate=0
        if ((row["SELF EMPLOYED"]=="Yes") & (row["Irr roundup"] < 14.74)):
            rate=0

    if(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower() )& (row["Override Remark"]=="-") ):
        if (row["Irr roundup"]< 11.24):
            rate=0
    # row["Override Rate"] = rate
    row["Base Rate"]=rate
    row["Override Rate"] = rate
    row["Override Remark"] = "6, "

    return row