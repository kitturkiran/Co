import pandas as pd

def override27(row:pd.DataFrame):
    Agreement_no=["LURUP00046891747",
                  "LUGDP00046909884",
                  "LUAMT00046971193",
                  "LUAMT00046978046",
                  "LULUD00046982015",
                  "LUAMT00046990180",
                  "LUFER00047004106",
                  "LUJAL00047001677",
                  "LUKLA00047004292",
                  "LULUD00047009725",
                  "LUJAL00047024364",
                  "LUJAL00047022571",
                  "LUTTR00047033781",
                  "LUFER00047025780",
                  "LULUD00047034102",
                  "LUAMT00047037802",
                  "LUAMT00047061060",
                  "LUJAL00047072329"]
    if(row["AGREEMENTNO"] in Agreement_no):
        row["special Reduction1"]=0.0025
        row["Override Remark"] += "27, "
        
    return row
    
    

