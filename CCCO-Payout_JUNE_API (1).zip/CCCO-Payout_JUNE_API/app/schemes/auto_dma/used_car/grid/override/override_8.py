import pandas as pd

def override8(row: pd.DataFrame):
    code=[179033, 270834, 268262, 269465, 269467, 269469, 104980]
     
    if ((row["DMABROKERCODE_y"] in code) & ( row["Consolidated State for Po processing"].lower() == 'gujarat')):
        row["Addition In Rate"] = (row["Base Rate"] * 0.09)
        row["Override Remark"] += "8, "
        
    return row