import pandas as pd
from datetime import datetime

def override14(row: pd.DataFrame):
    broker_code = 269302
    
    # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
    if((row["DMABROKERCODE_y"] != broker_code)):
        return row
    
    rate = row["Base Rate"]
    # po=row["Override Rate"]
    

    if(row["TENURE_y"] <= 15):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 34):
            row["Reduction In Rate"] = 0.0050
        elif(row["TENURE_y"] > 34):
            row["Reduction In Rate"] = 0.0000
        
        channelCode=""
        if("stp" in row["CHANNELCODE"].lower()):
            channelCode="stp"
        elif("alpa" in row["CHANNELCODE"].lower()):
            channelCode="alpa"
        elif("pa_" in row["CHANNELCODE"].lower()):
            channelCode="pa_"
        if(("alpa" in channelCode) | ("stp" in channelCode) | ("pa_" in channelCode)):
            if(row["Irr roundup"] < 11.25):
                return row
            elif(row["Irr roundup"] < 11.75):
                row["Override Rate"] = 0.0100
                row["Override Remark"] += "14," 
                return row
            elif(row["Irr roundup"] < 12.25):
                row["Override Rate"] = 0.0150
                row["Override Remark"] += "14," 
                return row
            elif(row["Irr roundup"] == 12.25):
                row["Override Rate"] = 0.0200
                row["Override Remark"] += "14," 
                return row
            
        if((row["AMTFIN"] < 1000000)):
            rate = gridCalculation1(row)
        else:
            rate = gridCalculation2(row)
             
    row["Base Rate"] = rate
    row["Override Remark"] += "14, "
    
    return row
   
            
def gridCalculation1(row: pd.DataFrame):
    grid = {
        'rate_min': [12.00, 12.50, 13.25],
        'rate_max': [12.50, 13.25, 101.0],
        'payout': [2.00, 3.00, 4.00]
    }
    grid = pd.DataFrame(grid)
    
    irr = row["Irr roundup"]
    
    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)


def gridCalculation2(row: pd.DataFrame):
    grid = {
        'rate_min': [11.00, 11.50, 12.00, 12.50],
        'rate_max': [11.50, 12.00, 12.50, 101.0],
        'cat1': [0, 2.00, 2.25, 2.75],
        'cat2': [2.00, 2.25, 2.50, 2.75]
    }
    grid = pd.DataFrame(grid)
    
    cat = ""
    if(row["AMTFIN"] <= 2000000):
        cat = "cat1"
    else:
        cat = "cat2"
    
    irr = row["Irr roundup"]
    
    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)