import pandas as pd

def override24(row:pd.DataFrame,df):
    broker_code=[143627, 101979, 127790, 163850, 170597, 134470, 220776, 235025, 160717, 170417, 104822, 174886, 237388, 303533, 264142, 168396]
    if((row["Consolidated State for Po processing"].lower()=="pune") & (row["PROCHANNEL"]=="sale purchase") & (row["DMABROKERCODE_y"] in broker_code)):
        for i in broker_code:
            Amount=df[(df["DMABROKERCODE_y"]==i) & (df["Consolidated State for Po processing"].str.lower()=="pune") & (df["PROCHANNEL"]=="sale purchase")]["AMTFIN"].sum()
            number_of_unit=df[(df["DMABROKERCODE_y"]==i)&(df["Consolidated State for Po processing"].str.lower()=="pune") & (df["PROCHANNEL"]=="sale purchase")].shape[0]
            if ((Amount >= 33000000) & (number_of_unit >= 30)):
        # if(row["AMTFIN"]<= 1000000):
            
                if(row["Irr roundup"]>=12.50):
                    row["Override Rate"]=0.025
                    row["Override Remark"] += "24, "
                    
                tad = df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([310089]))]["AMTFIN"].sum()
                pf=df[(df["Consolidated State for Po processing"].str.lower() == "gurgaon") & (df["DMABROKERCODE_y"].isin([[310089]]))]["PROCESSINGFEE"].sum()
                po=round((pf/tad)*100,2)
                print(po)
                if(po < 0.90):
                    row["Reduction In Rate"] =+ 0.001
            
            
    return row

