import pandas as pd

def override22(row: pd.DataFrame):
    if((row["Consolidated State for Po processing"].lower() == "kerala") & (row["PROCHANNEL"] == "sale purchase") & (row["TENURE_y"]>15)):
        if(("aip_pragati" in row["CHANNELCODE"].lower()) | ("pragati" in row["CHANNELCODE"].lower()) | ("aip" in row["CHANNELCODE"].lower()) | ("assessed income product" in row["CHANNELCODE"].lower())):
        
          
       
            if(100000 <= row["AMTFIN"] <= 1000000):
                
                irr = row["Irr roundup"]
                rate = row["Base Rate"]
                if (irr<13):
                    rate=0
                if (irr>=13):
                    rate=1.75
                if(irr>=13.25):
                    rate=2.00
                if((irr>=13.50) & (irr<=100)):
                    rate=2.25
                rate=(float(rate) / 100)
                row["Base Rate"] = rate
                row["Override Remark"] += "22, "   

    return row
                
                    
                    
                
                    
                
                        
            
          
                    
    