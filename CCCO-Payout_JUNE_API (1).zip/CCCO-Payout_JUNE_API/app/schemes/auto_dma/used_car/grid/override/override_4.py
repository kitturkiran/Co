import pandas as pd

def override4(row:pd.DataFrame):
    if(row["DMABROKERCODE_y"] != 268259):
        return row

    if((row["TENURE_y"] < 36) | (row["TENURE_y"] > 84)):
        return row

    segment  = row["Segment"]
    irr = row["Irr roundup"]

    if(segment in ["A+", "A"]):
        if(irr >= 12.00):
            row["Base Rate"] = 0.0050
        else:
            row["Base Rate"] = 0.0
        row["Override Remark"] += "4, "

    if(segment in ["B+", "B", "C"]):
        if(irr > 13.25):
            row["Base Rate"] = 0.0050
        else:
            row["Base Rate"] = 0.0
        row["Override Remark"] += "4, "

    if(row["PROCHANNEL"] in ["topup", "maxx"]):
        if(irr > 14.50):
            row["Base Rate"] = 0.0050
        else:
            row["Base Rate"] = 0.0
        row["Override Remark"] += "4, "
 
    return row