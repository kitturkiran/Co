import pandas as pd

def override20(row: pd.DataFrame):
    broker_codes = [256705, 232691, 243198, 226496]
    if((row["Consolidated State for Po processing"].lower() == "rotn") & (row["DMABROKERCODE_y"] in broker_codes)):
        if((row["TENURE_y"] >= 36) & (row["PROCHANNEL"] == "sale purchase")):
            rate = row["Override Rate"]
            grid = {
                'rate_min': [10.75, 11.00, 11.25, 11.50, 12.00, 12.50, 13.00, 13.50, 14.00, 14.50, 15.00],
                'rate_max': [11.00, 11.25, 11.50, 12.00, 12.50, 13.00, 13.50, 14.00, 14.50, 15.00, 101.00],
                'cat1': [0, 0, 0, 0, 0, 1.25, 1.50, 1.75, 2.25, 2.50, 2.75],
                'cat2': [0, 0, 0, 1.00, 1.25, 1.50, 1.75, 2.00, 2.50, 2.75, 3.00],
                'cat3': [0, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.75, 3.00, 3.25],
                'cat4': [1.00, 1.00, 1.25, 1.50, 1.50, 1.75, 2.00, 2.25, 2.75, 3.00, 3.25]
            }

            grid = pd.DataFrame(grid)

            irr = row["Irr roundup"]
            cat = ""
            if(row["AMTFIN"] < 500000):
                cat = "cat1"
            elif(500000 <= row["AMTFIN"] < 1000000):
                cat = "cat2"
            elif(1000000 <= row["AMTFIN"] < 2000000):
                cat = "cat3"
            elif(row["AMTFIN"] >= 2000000):
                cat = "cat4"

            rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
            if(rate.shape[0] == 0):
                rate = 0
                
            row["Override Rate"] = (float(rate) / 100)
            row["Override Remark"] += "20, "
            
    return row