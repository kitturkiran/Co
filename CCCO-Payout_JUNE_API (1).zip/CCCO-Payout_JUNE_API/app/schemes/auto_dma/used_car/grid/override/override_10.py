import pandas as pd

def override10(row:pd.DataFrame):
    broker_list = [274328, 266450, 266338, 286228, 275078,230043]

    if(row["DMABROKERCODE_y"] in broker_list):
        row["Base Rate"] = 0
        row["Override Rate"] = 0
        row["Final Rate"]=0
        row["Reduction In Rate"]=0
        row["Override Remark"] += "10, "
    if(row["DMABROKERCODE_y"]==269302):
        row["Override Rate"] = 0
        row["Reduction In Rate"]=0
    if(row["DMABROKERCODE_y"]==269302):
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 35):
            row["Reduction In Rate"] = 0.0050
        
        

    return row