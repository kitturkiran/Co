import pandas as pd

def override19(row: pd.DataFrame):
    if((row["DMABROKERCODE_y"] == 164968) & (row["Consolidated State for Po processing"].lower() == "bangalore")):
        rate = row["Base Rate"]
        
        if(row["TENURE_y"] < 24):
            rate = 0
        else:
            if(row["TENURE_y"] < 36):
                row["Reduction In Rate"] = 0.01 
            
            if(row["Irr roundup"] >= 14.00):
                rate = 0.04
            elif(row["Irr roundup"] >= 12.50):
                rate = 0.03
        if(row["Irr roundup"] < 12.50):
                rate = 0 
                row["Base Rate"] = 0
               

        row["Base Rate"] = rate
        row["Override Remark"] += "19, "
    
    return row