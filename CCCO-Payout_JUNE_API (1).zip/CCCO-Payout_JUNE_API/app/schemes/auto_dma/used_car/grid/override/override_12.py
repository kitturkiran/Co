import pandas as pd
from datetime import datetime

def override12(row: pd.DataFrame):   
    broker_code = 275078
    phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
    if((row["DISB_DATE"] > phase_date) | (row["DMABROKERCODE_y"] != broker_code)):
        return row

    rate = row["Base Rate"]

    if(row["TENURE_y"] <= 15):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] = 0.0100
        elif(row["TENURE_y"] <= 35):
            row["Reduction In Rate"] = 0.0050
        
        if((row["PROCHANNEL"] == "sale purchase") | (row["PROCHANNEL"] == "refinance")):
            rate = gridCalculation1(row)
        elif((row["PROCHANNEL"] == "maxx") | (row["PROCHANNEL"] == "external")):
            rate = gridCalculation2(row)
        elif((row["PROCHANNEL"] == "topup")):
            rate = gridCalculation3(row)
        elif(row["PROCHANNEL"] == "inbt"):
            rate = gridCalculation4(row)

    if(row["TotalPF"] < 0.80):
        row["Reduction In Rate"] += 0.0010

    if(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())):
        if(row["Irr roundup"] >= 11.00):
            rate = max(rate, 0.0100)
    
    if((row["Top/TierII"] == "Tier II") & ("alpa" not in row["CHANNELCODE"].lower()) & ("pa_" not in row["CHANNELCODE"].lower())):
        row["Reduction In Rate"] += 0.0025

    if (row["PROCHANNEL"] == "insta"):
        rate = 0.01
    if(row["TENURE_y"]<=15):
        rate=0.0000     
    row["Base Rate"] = rate
    row["Override Remark"] += "12, "

    return row


def gridCalculation1(row: pd.DataFrame):
    grid = {
        'rate_min': [11.25, 11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25],
        'rate_max': [11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25, 101.00],
        'cat1': [0, 0, 0, 0, 0, 2.25, 2.50, 3.00, 3.50, 3.75, 4.00],
        'cat2': [0, 0, 0, 1.00, 2.25, 2.50, 3.00, 3.25, 3.75, 4.00, 4.25],
        'cat3': [0, 1.75, 2.00, 2.25, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50],
        'cat4': [2.00, 2.00, 2.25, 2.50, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    cat = ""
    if(row["AMTFIN"] < 500000):
        cat = "cat1"
    elif(500000 <= row["AMTFIN"] < 1000000):
        cat = "cat2"
    elif(1000000 <= row["AMTFIN"] < 2000000):
        cat = "cat3"
    elif(row["AMTFIN"] >= 2000000):
        cat = "cat4"

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)


def gridCalculation2(row: pd.DataFrame):
    grid = {
        'rate_min': [14.00, 14.25, 14.75, 15.25, 15.75, 16.25],
        'rate_max': [14.25, 14.75, 15.25, 15.75, 16.25, 101.0],
        'cat1': [2.50, 3.00, 3.50, 4.00, 4.25, 4.50]
        # 'cat2': [0, 0, 2.50, 3.25, 3.75, 4.00, 4.25],
        # 'cat3': [0, 2.75, 3.25, 3.75, 4.00, 4.25, 4.50],
        # 'cat4': [2.75, 3.25, 3.75, 4.00, 4.25, 4.50, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    # cat = ""
    # if(row["AMTFIN"] < 500000):
    #     cat = "cat1"
    # elif(500000 <= row["AMTFIN"] < 1000000):
    #     cat = "cat2"
    # elif(1000000 <= row["AMTFIN"] < 2000000):
    #     cat = "cat3"
    # elif(row["AMTFIN"] >= 2000000):
    #     cat = "cat4"

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]['cat1']
    if(rate.shape[0] == 0):
        rate = 0
        
    return (float(rate) / 100)


def gridCalculation3(row: pd.DataFrame): 
    grid = {
        'rate_min': [15.25, 15.75, 16.25],
        'rate_max': [15.75, 16.25, 101.0],
        'payout': [0.50, 1.00, 1.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
    if(rate.shape[0] == 0):
        rate = 0

    return (float(rate) / 100)


def gridCalculation4(row: pd.DataFrame):
    grid = {
        'rate_min': [14.00, 14.25, 14.75, 15.25, 15.75, 16.25],
        'rate_max': [14.25, 14.75, 15.25, 15.75, 16.25, 101.0],
        'cat1': [1.50, 2.00, 2.50, 3.00, 3.50, 4.00],
        # 'cat2': [2.00, 2.50, 3.50, 4.00]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    # cat = ""
    # if(row["AMTFIN"] <= 1500000):
    #     cat = "cat1"
    # else:
    #     cat = "cat2"

    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]['cat1']
    if(rate.shape[0] == 0):
        rate = 0

    return (float(rate) / 100)

def nillPayout(row: pd.DataFrame):
    row["Reduction In Rate"] = 0
    row["Override Rate"] = 0