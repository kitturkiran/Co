import pandas as pd
from datetime import datetime

def override30(row: pd.DataFrame):
    broker_code = 213292
    
    if((row["DMABROKERCODE_y"] != broker_code)):
        return row
    
    rate = row["Base Rate"]
    # po=row["Override Rate"]
    

    if(row["TENURE_y"] <= 15):
        rate = 0
    else:
        if(row["TENURE_y"] <= 23):
            row["Reduction In Rate"] += 0.0100
        elif(row["TENURE_y"] <= 34):
            row["Reduction In Rate"] += 0.0050
        # elif(row["TENURE_y"] > 34):
        #     row["Reduction In Rate"] = 0.0000
        
        # channelCode=""
        # if("stp" in row["CHANNELCODE"].lower()):
        #     channelCode="stp"
        # elif("alpa" in row["CHANNELCODE"].lower()):
        #     channelCode="alpa"
        # elif("pa_" in row["CHANNELCODE"].lower()):
        #     channelCode="pa_"
        # if(("alpa" in channelCode) | ("stp" in channelCode) | ("pa_" in channelCode)):
        #     if(row["Irr roundup"] < 11.00):
        #         return row
        #     elif(row["Irr roundup"] < 11.50):
        #         row["Override Rate"] = 0.0100
        #         row["Override Remark"] += "14," 
        #         return row
        #     elif(row["Irr roundup"] < 12.00):
        #         row["Override Rate"] = 0.0150
        #         row["Override Remark"] += "14," 
        #         return row
        #     elif(row["Irr roundup"] == 12.00):
        #         row["Override Rate"] = 0.0200
        #         row["Override Remark"] += "14," 
        #         return row
        if(((row["PROCHANNEL"] == "sale purchase") | (row["PROCHANNEL"] == "refinance"))):
            if((("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())) == False):
                if((row["AMTFIN"] < 1000000)):
                    if (row["Irr roundup"]<13.5):
                        rate = 0.045-((13.5-row["Irr roundup"])/100)
                    else:
                        rate=0.045
                elif((1000000<= row["AMTFIN"] < 2000000)):
                    if (row["Irr roundup"]<12.75):
                        rate = 0.045-((12.75-row["Irr roundup"])/100)
                    else:
                        rate=0.045
                    
                elif((row["AMTFIN"] >= 2000000)):
                    if (row["Irr roundup"]<12.5):
                        rate = 0.045-((12.5-row["Irr roundup"])/100)
                    else:
                        rate=0.045
                    
            
             
    row["Base Rate"] = rate
    row["Override Remark"] += "30, "
    
    return row
   
            
# def gridCalculation1(row: pd.DataFrame):
#     grid = {
#         'rate_min': [12.00, 12.50, 13.25],
#         'rate_max': [12.50, 13.25, 101.0],
#         'payout': [2.00, 3.00, 4.00]
#     }
#     grid = pd.DataFrame(grid)
    
#     irr = row["Irr roundup"]
    
#     rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])]["payout"]
#     if(rate.shape[0] == 0):
#         rate = 0
        
#     return (float(rate) / 100)


# def gridCalculation2(row: pd.DataFrame):
#     grid = {
#         'rate_min': [10.75, 11.25, 11.75, 12.25],
#         'rate_max': [11.25, 11.75, 12.25, 101.0],
#         'cat1': [0, 2.00, 2.25, 2.75],
#         'cat2': [2.00, 2.25, 2.50, 2.75]
#     }
#     grid = pd.DataFrame(grid)
    
#     cat = ""
#     if(row["AMTFIN"] <= 2000000):
#         cat = "cat1"
#     else:
#         cat = "cat2"
    
#     irr = row["Irr roundup"]
    
#     rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
#     if(rate.shape[0] == 0):
#         rate = 0
        
#     return (float(rate) / 100)