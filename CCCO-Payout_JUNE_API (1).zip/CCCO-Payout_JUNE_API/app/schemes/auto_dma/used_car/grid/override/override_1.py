import pandas as pd

def override1(row:pd.DataFrame):
    if(row["Consolidated State for Po processing"].lower() == "madhya pradesh"):
        if((row["Sourcing"].lower() == "ddsa")|((row["Sourcing"].lower() == "ddsa-aggregator"))):
            row["Reduction In Rate"] += 0.0035
            row["Override Remark"] += "1, "

    return row