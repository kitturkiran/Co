import pandas as pd
from datetime import datetime

def override21A(row: pd.DataFrame):
        broker_code=230043
        phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
        if((row["DISB_DATE"] > phase_date) | (row["DMABROKERCODE_y"] != broker_code)):
            return row
        rate = row["Base Rate"]
        
        if(row["TENURE_y"] <= 15):
            rate = 0
        else:
            if(row["TENURE_y"] <= 23):
                row["Reduction In Rate"] = 0.0100
            elif(row["TENURE_y"] <= 35):
                row["Reduction In Rate"] = 0.0050
            
            rate = gridCalculation1(row)
        
        if(row["TotalPF"] < 0.80):
            row["Reduction In Rate"] += 0.0010
        
        if(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())):
            if(row["Irr roundup"] >= 11.00):
                rate = max(rate, 0.0100)
                
        row["Base Rate"] = rate
        row["Override Remark"] += "21, "
                
        return row


def gridCalculation1(row: pd.DataFrame):
    rate = row["Override Rate"]
    grid = {
        'rate_min': [11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25],
        'rate_max': [11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25, 101.0],
        'cat1': [0, 0, 0, 0, 2.25, 2.50, 3.00, 3.50, 3.75, 4.00],
        'cat2': [0, 0, 1.00, 2.25, 2.50, 3.00, 3.25, 3.75, 4.00, 4.25],
        'cat3': [1.75, 2.00, 2.25, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    cat = ""
    if(row["AMTFIN"] < 500000):
        cat = "cat1"
    elif(500000 <= row["AMTFIN"] < 1000000):
        cat = "cat2"
    elif(1000000 <= row["AMTFIN"] < 2000000):
        cat = "cat3"
    elif(row["AMTFIN"] >= 2000000):
        cat = "cat4"

    if(cat != "cat4"):
        rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
        if(rate.shape[0] == 0):
            rate = 0
            
    return (float(rate) / 100)


def override21B(row: pd.DataFrame):
        broker_code=230043
        # phase_date = datetime.strptime("14-04-2023", "%d-%m-%Y")
        if((row["DMABROKERCODE_y"] != broker_code)):
            return row
        rate = row["Base Rate"]
        
        if(row["TENURE_y"] <= 15):
            rate = 0
        else:
            if(row["TENURE_y"] <= 23):
                row["Reduction In Rate"] = 0.0100
            elif(row["TENURE_y"] <= 35):
                row["Reduction In Rate"] = 0.0050
            
        if((row["PROCHANNEL"] == "sale purchase")):
            rate = gridCalculation2(row)
        
        if(row["TotalPF"] < 0.90):
            row["Reduction In Rate"] += 0.0010
        
        if(("alpa" in row["CHANNELCODE"].lower()) | ("stp" in row["CHANNELCODE"].lower()) | ("pa_" in row["CHANNELCODE"].lower())):
            if(row["Irr roundup"] >= 11.25):
                rate = max(rate, 0.0100)
                
        row["Base Rate"] = rate
        row["Override Remark"] += "21, "
                
        return row


def gridCalculation2(row: pd.DataFrame):
    rate = row["Override Rate"]
    grid = {
        'rate_min': [11.50, 11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25],
        'rate_max': [11.75, 12.00, 12.50, 13.00, 13.50, 14.00, 14.25, 14.75, 15.25, 101.0],
        'cat1': [0, 0, 0, 0, 2.25, 2.50, 3.00, 3.50, 3.75, 4.00],
        'cat2': [0, 0, 1.00, 2.25, 2.50, 3.00, 3.25, 3.75, 4.00, 4.25],
        'cat3': [1.75, 2.00, 2.25, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50]
    }

    grid = pd.DataFrame(grid)

    irr = row["Irr roundup"]
    cat = ""
    if(row["AMTFIN"] < 500000):
        cat = "cat1"
    elif(500000 <= row["AMTFIN"] < 1000000):
        cat = "cat2"
    elif(row["AMTFIN"] > 1000000):
        cat = "cat3"
    # elif(row["AMTFIN"] >= 2000000):
    #     cat = "cat4"

    
    rate = grid.loc[(grid["rate_min"] <= irr) & (irr < grid["rate_max"])][cat]
    if(rate.shape[0] == 0):
            rate = 0
            
    return (float(rate) / 100)