import pandas as pd

def override18(row: pd.DataFrame):
    broker_code = 256398
    if((row["DMABROKERCODE_y"] == broker_code) & (row["Consolidated State for Po processing"].lower() == "bangalore")):
        if(row["PROCHANNEL"] == "sale purchase"):
            rate = row["Override Rate"]
            if((row["TotalPF"] < 0.80)):
                row["Reduction In Rate"] = 0.00100
            if(row["TENURE_y"] < 16):
                rate = 0
            else:
                if((row["TENURE_y"] <= 35)):
                    row["Reduction In Rate"] += 0.0100
            # if((row["TotalPF"] < 0.80)):
            #     row["Reduction In Rate"] = 0.00100
                
            if((row["Irr roundup"] >= 13.50) & (row["TENURE_y"] > 16) ):
                    rate = 0.0300
            if((row["Irr roundup"] < 13.49)):
                    rate = 0
        
            row["Override Rate"] = rate
            row["Override Remark"] += "18, "
            # if((row["TotalPF"] < 0.80)):
            #     row["Reduction In Rate"] += 0.0010
    return row