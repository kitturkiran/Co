import pandas as pd

from .override_1 import override1
from .override_2 import override2
from .override_3 import override3
from .override_4 import override4
from .override_5 import override5
from .override_6 import override6
# from used_car.grid.override.override_7 import override7
from .override_8 import override8
from .override_9 import override9
from .override_10 import override10
from .override_11 import override11
from .override_12 import override12
from .override_13 import override13
from .override_14 import override14
from .override_15 import override15
from .override_16 import override16
from .override_17 import override17
from .override_18 import override18
from .override_19 import override19
from .override_20 import override20
from .override_21 import override21A
from .override_21 import override21B
from .override_22 import override22
from .override_24 import override24
from .override_25 import override25
from .override_26 import override26
from .override_27 import override27
from .override_28 import override28
from .override_29 import override29
from .override_30 import override30
from .override_31 import override31

from ..base_grid.base_grid_phase1 import BaseGridPhase1
from ..base_grid.base_grid_phase2 import BaseGridPhase2


def execute(df: pd.DataFrame):
    # Applying base grid
    # df = df.apply(lambda x: BaseGridPhase1(x), axis=1)
    df = df.apply(lambda x: BaseGridPhase2(x), axis=1)
    
    #Applying override grid
    # df = df.apply(lambda x: override5(x), axis=1)
    # df = df.apply(lambda x: override6(x),axis=1)
    # df = df.apply(lambda x: override1(x), axis=1)
    # df = df.apply(lambda x: override2(x), axis=1)
    # df = df.apply(lambda x: override3(x), axis=1)
    # df = df.apply(lambda x: override4(x), axis=1)
    # df = df.apply(lambda x: override22(x), axis=1)
    # df = df.apply(lambda x: override5(x), axis=1)
    # df = df.apply(lambda x: override6(x),axis=1)
    df = df.apply(lambda x: override8(x), axis=1)
    df = df.apply(lambda x: override9(x), axis=1)
    df = df.apply(lambda x: override10(x), axis=1)
    df = df.apply(lambda x: override11(x), axis=1)
    # df = df.apply(lambda x: override12(x), axis=1)
    df = df.apply(lambda x: override13(x), axis=1)
    df = df.apply(lambda x: override14(x), axis=1)
    # df = df.apply(lambda x: override15(x), axis=1)
    # df = df.apply(lambda x: override16(x), axis=1)
    df = df.apply(lambda x: override17(x), axis=1)
    # df = df.apply(lambda x: override18(x), axis=1)
    # df = df.apply(lambda x: override19(x), axis=1)
    # # df = df.apply(lambda x: override20(x), axis=1)
    # df = df.apply(lambda x: override21A(x), axis=1)
    df = df.apply(lambda x: override21B(x), axis=1)
    # df = df.apply(lambda x: override10(x), axis=1)
    # df = df.apply(lambda x: override22(x), axis=1)
    df = df.apply(lambda x: override24(x,df), axis=1)
    # df = df.apply(lambda x: override25(x), axis=1)
    # df = df.apply(lambda x: override26(x), axis=1)
    # df = df.apply(lambda x: override27(x), axis=1)
    # df = df.apply(lambda x: override28(x), axis=1)
    df = df.apply(lambda x: override29(x), axis=1)
    df = df.apply(lambda x: override31(x,df), axis=1)
    df = df.apply(lambda x: override25(x), axis=1)
    # df = df.apply(lambda x: override30(x), axis=1)
    
    return df
