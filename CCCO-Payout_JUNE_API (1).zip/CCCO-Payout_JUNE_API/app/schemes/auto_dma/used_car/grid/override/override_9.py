import pandas as pd

def override9(row:pd.DataFrame):
    # if((row["Consolidated State for Po processing"].lower() != "rowb") | (row["Consolidated State for Po processing"] != "Kolkata")):
    #     return row

    broker_list_1 = [
                    232413,
                    268357,
                    273450,
                    206505,
                    201388,
                    290661,
                    208111,
                    179747,
                    306736,
                    303386,
                    237744,
                    312584,
                    320274,
                    313388,

                    ]
    broker_list_2 = [
                    288806,
                    289526,
                    289703,
                    290212,
                    290349,

                    ]

    # broker = row["DMABROKERCODE_y"]


    if((row["Consolidated State for Po processing"].lower() == "rowb") | (row["Consolidated State for Po processing"] == "Kolkata")):
        if(row["DMABROKERCODE_y"] in broker_list_1):
            row["Reduction In Rate"] += 0.0025
            row["Override Remark"] += "9, "

        if(row["DMABROKERCODE_y"] in broker_list_2):
            row["Reduction In Rate"] += 0.0015
            row["Override Remark"] += "9, "
    
    return row