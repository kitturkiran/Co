from pandas import DataFrame


class OutputInit:
    def __init__(self, df: DataFrame):
        self.df = df

    def updateTopTier(self):
        self.df.loc[((self.df["Consolidated State for Po processing"].str.lower() == "delhi") | (self.df["Consolidated State for Po processing"].str.lower() == "delhi ncr") | (self.df["Consolidated State for Po processing"].str.lower() == "mumbai") | (self.df["Consolidated State for Po processing"].str.lower() == "gujarat") | (self.df["Consolidated State for Po processing"].str.lower(
        ) == "pune") | (self.df["Consolidated State for Po processing"].str.lower() == "bangalore") | (self.df["Consolidated State for Po processing"].str.lower() == "hyderabad") | (self.df["Consolidated State for Po processing"].str.lower() == "chennai")), ["Top/TierII"]] = "Top"

    def updateManfBrand(self):
        condition = (self.df['MANUFACTURERDESC'].str.lower().str.contains("maruti") | self.df['MANUFACTURERDESC'].str.lower().str.contains("hyundai") | self.df['MANUFACTURERDESC'].str.lower().str.contains("tata") | self.df['MANUFACTURERDESC'].str.lower().str.contains("honda") | self.df['MANUFACTURERDESC'].str.lower(
        ).str.contains("toyota") | self.df['MANUFACTURERDESC'].str.lower().str.contains("ford") | self.df['MANUFACTURERDESC'].str.lower().str.contains("fca") | self.df['MANUFACTURERDESC'].str.lower().str.contains("fiat") | self.df['MANUFACTURERDESC'].str.lower().str.contains("jeep"))

        self.df.loc[condition, "MANF_BAND"] = "A"
        self.df.loc[~condition, "MANF_BAND"] = "B"

    def addNetLoan(self):
        self.df["Net Loan"] = (self.df["AMTFIN"] -
                               self.df["ADVANCE_EMI"]) * self.df["flag"]

    def updateFinalNetLoan(self):
        condition = self.df["Asset Insurance PO "] == "No"
        self.df.loc[(condition), "Final Net Loan"] = (
            self.df["Net Loan"] - self.df["Asset Insurance charge ID- 500080"])
        self.df.loc[(~condition), "Final Net Loan"] = self.df["Net Loan"]

    def updateAMTFINPRETAXIRR(self):
        self.df["AMTFIN*PRETAXIRR"] = self.df["AMTFIN"] * self.df["PRETAXIRR"]

    def updateTotalDisbursementAmount(self):
        gp = self.df.groupby(['DMABROKERCODE_y', 'Consolidated State for Po processing'])[
            "AMTFIN"].sum().reset_index()

        for row in range(gp.shape[0]):
            temp = gp.iloc[row, :]
            code = temp["DMABROKERCODE_y"]
            state = temp["Consolidated State for Po processing"]
            total_disb = temp["AMTFIN"]
            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (
                self.df["Consolidated State for Po processing"] == state), "Total Applicable Disbursement"] = total_disb
        self.groupingBroker(gp)
        self.groupbyNorth2Cases()

    def applicableState(self):
        self.df["Temp_State"] = self.df["Consolidated State for Po processing"]
        self.df.loc[(self.df["Consolidated State for Po processing"].isin(["Delhi", "Noida", "Gurgaon"])), "Temp_State"] = "Delhi"
        self.df.loc[(self.df["Consolidated State for Po processing"].isin(["Haryana", "Punjab","HP","J&K"])), "Temp_State"] = "Haryana"
        self.df.loc[(self.df["Sourcing"].str.lower() == "aggregator"), "Temp_State"] = "Aggregator"


    def groupbyNorth2Cases(self):
        gp = self.df.groupby(['DMABROKERCODE_y', 'Latest Zone'])[
            "AMTFIN"].sum().reset_index()

        for row in range(gp.shape[0]):
            temp = gp.iloc[row, :]
            code = temp["DMABROKERCODE_y"]
            total_disb = temp["AMTFIN"]
            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (
                self.df["Latest Zone"] == "North 2"), "Total Applicable Disbursement"] = total_disb

        gp = self.df.groupby(["DMABROKERCODE_y"])
        for code, grp_df in gp:
            delhi = 0
            noida = 0
            gurgaon = 0
            if(grp_df[grp_df["Consolidated State for Po processing"] == "Delhi"].shape[0] > 0):
                delhi = grp_df[grp_df["Consolidated State for Po processing"] == "Delhi"]["Total Applicable Disbursement"].iloc[0]

            if(grp_df[grp_df["Consolidated State for Po processing"] == "Gurgaon"].shape[0] > 0):
                gurgaon = grp_df[grp_df["Consolidated State for Po processing"] == "Gurgaon"]["Total Applicable Disbursement"].iloc[0]
                
            if(grp_df[grp_df["Consolidated State for Po processing"] == "Noida"].shape[0] > 0):
                noida = grp_df[grp_df["Consolidated State for Po processing"] == "Noida"]["Total Applicable Disbursement"].iloc[0]
            
            total = delhi + gurgaon + noida
            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (self.df["Consolidated State for Po processing"].isin(["Delhi", "Noida", "Gurgaon"])), "Total Applicable Disbursement"] = total

        gp = self.df.groupby(["DMABROKERCODE_y"])
        for code, grp_df in gp:
            haryana = 0
            phj = 0

            if(grp_df[grp_df["Consolidated State for Po processing"] == "Haryana"].shape[0] > 0):
                haryana = grp_df[grp_df["Consolidated State for Po processing"] == "Haryana"]["Total Applicable Disbursement"].iloc[0]

            if(grp_df[grp_df["Consolidated State for Po processing"] == "Pun, HP, J&K"].shape[0] > 0):
                phj = grp_df[grp_df["Consolidated State for Po processing"] == "Pun, HP, J&K"]["Total Applicable Disbursement"].iloc[0]
                
            total = haryana + phj
            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (self.df["Consolidated State for Po processing"].isin(["Haryana", "Pun, HP, J&K"])), "Total Applicable Disbursement"] = total


    def groupingBroker(self, gp: DataFrame):
        broker = [
            [230164, 227613, 163891],
            [272355, 181343],
            [104566, 173503, 179283, 261656, 218674],
            [235320, 191433, 273843, 234376],
            [104755, 112362, 244216],
            [106746, 266367, 101696],
            [256601, 209562],
        ]

        for i in range(len(broker)):
            sum = 0
            for j in range(len(broker[i])):
                temp = gp.loc[(gp["DMABROKERCODE_y"] == broker[i][j]) & (
                    gp["Consolidated State for Po processing"].str.lower() == "mumbai")]["AMTFIN"]
                if(len(temp.values) > 0):
                    sum += temp.values[0]

            for j in range(len(broker[i])):
                self.df.loc[((self.df["DMABROKERCODE_y"] == broker[i][j]) & (
                    (self.df["Consolidated State for Po processing"].str.lower() == "mumbai"))), "Total Applicable Disbursement"] = sum

    def updateWIRR(self):
        gp = self.df.groupby(['DMABROKERCODE_y', 'Consolidated State for Po processing'])[
            "AMTFIN*PRETAXIRR"].sum().reset_index()

        for row in range(gp.shape[0]):
            temp = gp.iloc[row, :]
            code = temp["DMABROKERCODE_y"]
            state = temp["Consolidated State for Po processing"]
            result = temp["AMTFIN*PRETAXIRR"]

            self.df.loc[(self.df["DMABROKERCODE_y"] == code) & (
                self.df["Consolidated State for Po processing"] == state), "WIRR"] = round((result / self.df["Total Applicable Disbursement"]), 2)

    def processProchannel(self):
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("inbt")), "PROCHANNEL"] = "inbt"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("internal")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("external")), "PROCHANNEL"] = "external"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("max")), "PROCHANNEL"] = "maxx"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("refinance")), "PROCHANNEL"] = "refinance"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("insta")), "PROCHANNEL"] = "insta"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("internal")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("insta")), "PROCHANNEL"] = "insta"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("top")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("max")), "PROCHANNEL"] = "maxx"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("max")), "PROCHANNEL"] = "maxx"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("refinance")), "PROCHANNEL"] = "refinance"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("eclgs")), "PROCHANNEL"] = "eclgs"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("insta")), "PROCHANNEL"] = "insta"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("external")), "PROCHANNEL"] = "external"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("internal")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("refinance")), "PROCHANNEL"] = "refinance"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("eclgs")), "PROCHANNEL"] = "eclgs"
        # self.df.loc[(self.df["PROCHANNEL"] == '-') & (self.df["CHANNELCODE"].str.lower().str.startswith("intopup")), "PROCHANNEL"] = "inbt"
        self.df.loc[(self.df["PROCHANNEL"] == '-'), "PROCHANNEL"] = "sale purchase"
        self.df.loc[(self.df["CHANNELCODE"].str.lower().str.contains("intopup")), "PROCHANNEL"] = "topup"
        self.df.loc[(self.df["PROCHANNEL"].str.lower().str.contains("insta")), "PROCHANNEL"] = "topup"
    
    
    def processTotalPF(self):
        gp = self.df.groupby(['DMABROKERCODE_y'])[
            ["AMTFIN", "PROCESSINGFEE"]].sum().reset_index()

        for row in range(gp.shape[0]):
            temp1 = gp.iloc[row, :]
            pf = temp1["PROCESSINGFEE"]
            amt = temp1["AMTFIN"]
            code = temp1["DMABROKERCODE_y"]
            if(pf== 0):
                self.df.loc[(self.df["DMABROKERCODE_y"] == code), "TotalPF"] = 0
            else:
                self.df.loc[(self.df["DMABROKERCODE_y"] == code), "TotalPF"] = round(((pf/amt) * 100), 2)


    def executeFinalOutput(self):
        #self.updateTopTier()
        self.updateManfBrand()
        self.addNetLoan()
        self.updateFinalNetLoan()
        self.updateAMTFINPRETAXIRR()
        self.updateTotalDisbursementAmount()
        self.updateWIRR()
        self.processProchannel()
        self.processTotalPF()
        self.applicableState()
        return self.df
