import os
import pandas as pd
from final_calculation_used import executeCalculation
from final_calculation_new import executeCalculationNew,executeCalculationNew_INFINIUM
from data_manipulation import DataManipulation
from data_split_used import DataSplit
from data_split_new import DataSplit1
from final_calculation_used import finalRateCalculation
from output_init_used import OutputInit
from output_init_new import OutputInit1
from new_car.grid.override import executeNew
from used_car.grid.override import execute
from output_structure_used import OutputStructure
from output_structure_new import OutputStructure1
from summary_new import generateSummary
from summary_old import generateSummary1
from datetime import datetime
from summary_used_new import summary_used_new
from summary_used_new_cncl import summary_cncl


currentPath = os.getcwd()
# DMA_FILE = "auto dma dump.xlsx"
# dma_path = f"{currentPath}\Input_file\{DMA_FILE}"
dma_df = pd.read_excel(r"D:\schema _scource code1 _may\Auto DMA\Auto Dma\Auto dma\Input_file\AUTO COU. MANIPAL MAY 23 DUMP..xlsx")
# rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
# TAGGING_FILE = "D:\schema _scource code\Auto DMA\Auto Dma January 2023\Auto dma _january\Input_file\Auto DMA Tagging Jan 23.xls"
tagging_path = r"D:\schema _scource code1 _may\Auto DMA\Auto Dma\Auto dma\Input_file\Revise Tagging File.xlsx"
# tagging_new_df = pd.read_excel(tagging_path)
tagging_new_df = pd.read_excel(tagging_path, sheet_name="New")
tagging_used_df = pd.read_excel(tagging_path, sheet_name="Used")


dataManipulationObj = DataManipulation(dma_df)
cleanedDF = dataManipulationObj.executeCleaning()


dataSplitObj = DataSplit(cleanedDF, tagging_new_df, tagging_used_df)
dataSplitObj.executePreparation()
dataSplitObj1 = DataSplit1(cleanedDF, tagging_new_df, tagging_used_df)
dataSplitObj1.executePreparation()
# dataSplitObj.usedCar.to_excel("newCar.xlsx")
# dataSplitObj1.newCar.to_excel("oldCar.xlsx")


# # # # For New Car
opObj = OutputStructure1(dataSplitObj1.newCar)
newCar = opObj.addStructure("New Car")

finalObj = OutputInit1(newCar)
newCar = finalObj.executeFinalOutput()

newCar = executeNew(newCar)
newCar = executeCalculationNew(newCar)
# newCar_infinium=executeCalculationNew_INFINIUM(newCar)
newCar1=newCar

newCar.to_excel("AUTO DMA_NEW CAR_OUTPUT_MAY23.xlsx", index = False)
# CNCL=pd.read_excel(r"C:\Users\Kiran.k\Downloads\Auto Advane Jan23.xlsx")
newCar=generateSummary(newCar)
newCar.to_excel("AUTO DMA_SUMMARY_MAY23.xlsx",index=False)
# newCar_infinium.to_excel("AUTO DMA_INFINIUM_FEB23.xlsx")




# # Used Car
opObj = OutputStructure(dataSplitObj.usedCar)
usedCar = opObj.addStructure("Old Car")

finalObj = OutputInit(usedCar)
usedCar = finalObj.executeFinalOutput()

usedCar = execute(usedCar)
usedCar = executeCalculation(usedCar)
usedCar1=usedCar

usedCar.to_excel("AUTO DMA_USED CAR_OUTPUT_MAY2023.xlsx", index = False)
usedCar=generateSummary1(usedCar)
usedCar.to_excel("AUTO DMA_USED CAR_SUMMARY_MAY2023.xlsx",index=False)
used_new=pd.concat([newCar,usedCar],ignore_index=True)
used_new.insert(0,"Ref No",range(30001,30001+used_new.shape[0]))
used_new["Ref No"]=used_new["Ref No"].apply(lambda x:"AUDM052"+str(x))
used_new.to_excel("AUTO DMA_NEW_USED CAR_SUMMARY_MAY2023.xlsx",index=False)
cncl=pd.read_excel(r"D:\schema _scource code1 _may\Auto DMA\Auto Dma\Auto dma\Input_file\Case Cancellation.xlsx")
# # tad=0
summary_cncl1=summary_cncl(used_new,cncl)
summary_used_new1=summary_used_new(summary_cncl1)
summary_used_new1.to_excel("summary_used_new.xlsx",index=False)