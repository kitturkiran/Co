from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .data_calculation import Calculation
from .data_massaging import Massaging
from .data_summary import Summary
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil


cv_counsellor_router=APIRouter()
@cv_counsellor_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def cv_ce_payout_calculation(dma: UploadFile,master_mf: UploadFile,
                                   tagging: UploadFile,
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
    print("hello")
    
    dma_df = pd.read_excel(dma.file.read())
    master_mf=pd.read_excel(master_mf.file.read())
    tagging_file = pd.read_excel(tagging.file.read())
    
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

        obj1=Massaging(dma_df, rejected_df,master_mf,tagging_file,start_date,end_date)
        obj1.execute()

        obj2 =Calculation(obj1.df)
        obj2.execution()
        obj3=Summary(obj2.df)
        obj3.execute()
        
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"cv_concellor_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        obj2.df1.to_excel(writer, sheet_name="CV-consellor-Cases", index=False)
        obj1.rejection.to_excel(writer, sheet_name="Rejected", index=False)
        obj3.df.to_excel(writer, sheet_name="Summary", index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)
   
   
    
@cv_counsellor_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/Scheme_4"
    destination_dir = f"./backup/Scheme_4/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"
        