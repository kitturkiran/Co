import pandas as pd

def Caluation(df:pd.DataFrame,df_kerala:pd.DataFrame):
    dma=pd.concat([df,df_kerala],ignore_index=True)
    gp=dma.groupby(["OSP_CODE"])
    dma["TYPE"]=dma["Top/ Tier II"]
    for code,grf in gp:
        f=grf[grf["LAN_TYPE"]=="USED CAR"].shape[0]
        if (f==grf.shape[0]):
            dma.loc[(dma["OSP_CODE"]==code),"TYPE"]="USED"
            
    dma.loc[(dma["CONSOILIDATED_STATE"]=="Kerala"),"capping"]=65000
    dma.loc[(dma["CONSOILIDATED_STATE"]!="Kerala"),"capping"]=50000   

        
    grp = dma.groupby("OSP_CODE")

    summary_df = pd.DataFrame(columns=["OSPCodeCheck", "Retainer/LME Name", "Count","TOP / Tier II","Type","location","State","Amount finance","Adv EMI","AUTO SECURE","Net Loan Amount", "Final Case Wise Incentive Payout", "Final commission", "Fixed Payout", "Fixed + Variable", "Capping", "Net Payable","Amt","Remarks"])

    for code, gdf in grp:
        temp = {}
        temp["OSPCodeCheck"] = [code]
        temp["Retainer/LME Name"] = [gdf["DME_NAME"].iloc[0]]
        temp["Count"] = [gdf.shape[0]]
        temp["TOP / Tier II"] = [gdf["Top/ Tier II"].iloc[0]]
        temp["Type"] = [gdf["TYPE"].iloc[0]]
        temp["location"] = ""
        temp["State"] = [gdf["CONSOILIDATED_STATE"].iloc[0]]
        temp["Amount finance"]=[gdf["AMTFIN"].sum()]
        temp["Adv EMI"]=[gdf["ADVANCE_EMI"].sum()]
        temp["AUTO SECURE"]=[gdf["CHARGE_AMT4/Auto Secure"].sum()]
        temp["Net Loan Amount"]=[gdf["REVISED AMOUNT FINANCE"].sum()]
        temp["Final Case Wise Incentive Payout"] = [round(gdf["PO_AMT"].sum())]
        temp["Final commission"] = [round(gdf["PO_CAPPED_AMT"].sum())]
        temp["Fixed Payout"] = [gdf["TOTAL_SALARY"].iloc[0]]
        temp["Fixed + Variable"] = [temp["Final commission"][0] + temp["Fixed Payout"][0]]
        temp["Capping"] = [gdf["capping"].iloc[0]]
        temp["Amt"]=0
        temp["Remarks"]=""

        
        if(temp["Fixed + Variable"][0] > temp["Capping"][0]):
            temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        else:
            temp["Net Payable"] = [temp["Final commission"][0]]
        
       
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    summary_df["Amt"]=summary_df["Net Payable"]
    summary_df.loc[(summary_df["Count"].between(1,2,inclusive="both")) & (summary_df["Type"]=="USED"),"Amt"]=1500*summary_df["Count"]
    summary_df.loc[(summary_df["Count"].between(1,4,inclusive="both")) & (summary_df["Type"]=="Tier II"),"Amt"]=1500*summary_df["Count"]
    summary_df.loc[(summary_df["Count"].between(1,6,inclusive="both")) & (summary_df["Type"]=="Top"),"Amt"]=1500*summary_df["Count"]

    summary_df.loc[(summary_df["Count"].between(1,2,inclusive="both")) & (summary_df["Type"]=="USED"),"Remarks"]="1500 per case only"
    summary_df.loc[(summary_df["Count"].between(1,4,inclusive="both")) & (summary_df["Type"]=="Tier II"),"Remarks"]="1500 per case only"
    summary_df.loc[(summary_df["Count"].between(1,6,inclusive="both")) & (summary_df["Type"]=="Top"),"Remarks"]="1500 per case only"

    summary_df.loc[(summary_df["Count"].between(3,4,inclusive="both")) & (summary_df["Type"]=="USED"),"Remarks"]="50% of current Fixed salary + incentive as per current incentive structure"
    summary_df.loc[(summary_df["Count"].between(5,6,inclusive="both")) & (summary_df["Type"]=="Tier II"),"Remarks"]="50% of current Fixed salary + incentive as per current incentive structure"
    summary_df.loc[(summary_df["Count"].between(7,8,inclusive="both")) & (summary_df["Type"]=="Top"),"Remarks"]="50% of current Fixed salary + incentive as per current incentive structure"

    summary_df.loc[(summary_df["Count"]>=5) & (summary_df["Type"]=="USED"),"Remarks"]="No Change in current payment structure. Amount equivalent to current Fixed Salary and Incentive"
    summary_df.loc[(summary_df["Count"]>=7) & (summary_df["Type"]=="Tier II"),"Remarks"]="No Change in current payment structure. Amount equivalent to current Fixed Salary and Incentive"
    summary_df.loc[(summary_df["Count"]>=9) & (summary_df["Type"]=="Top"),"Remarks"]="No Change in current payment structure. Amount equivalent to current Fixed Salary and Incentive"    
    
    return summary_df
    
    
    
    
    
    
    
    
    
    