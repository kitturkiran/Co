import os
import pandas as pd
from  data_massaging import DataMassaging
from  data_calculation import DataCalculation
from po_summary import generateSummary,generateSummary1
from data_Calculation_retainer import Caluation

currentPath = os.getcwd()

DMA_Payout_File = "auto dma dump.xlsx"
I_Process_Active_File = "I process active Nov 22.xls"
Master_File = "Master file Nov 22.xls"
Tagging_File = "Auto Tagging Nov 22 (1).xls"

DMA_Path = r"D:\schema _scource code1 _may\Auto Consellor\Auto-Consellor\Auto-Consellor-main_manipalla\Input_File\AUTO COU. MANIPAL MAY 23 DUMP..xlsx"
I_Process_Active_Path = r"D:\schema _scource code1 _may\Auto Consellor\Auto-Consellor\Auto-Consellor-main_manipalla\Input_File\Manipal active May 23.xlsx"
Master_Path = r"D:\schema _scource code1 _may\Auto Consellor\Auto-Consellor\Auto-Consellor-main_manipalla\Input_File\MASTER FILE May 23.xlsx"
tagging=pd.read_excel(r"D:\schema _scource code1 _may\Auto Consellor\Auto-Consellor\Auto-Consellor-main_manipalla\Input_File\May 23 Dump for Manipal Calculation.xls")

dma_df = pd.read_excel(DMA_Path)
dma_df["OSP_CODE"] = dma_df["OSP_CODE"].str.upper()


I_Process_Active_df=pd.read_excel(I_Process_Active_Path)


Master_df = pd.read_excel(Master_Path)





I_Process_Active_df = I_Process_Active_df[["VSTS Code / Counselor SAP Code", "Consolidated State", "Manipal Gross salary", "Designation", "Top/ Tier II", "No of day"]]
# Rename VSTS Code / Counselor SAP Code
I_Process_Active_df.rename(columns={"VSTS Code / Counselor SAP Code":"OSP_CODE"}, inplace=True)
I_Process_Active_df["OSP_CODE"] = I_Process_Active_df["OSP_CODE"].str.upper()


Master_df = Master_df[["Aps Code", "Sourcing"]]
#Rename Aps Code
Master_df.rename(columns={"Aps Code":"DMABROKERCODE"}, inplace=True)
tw=r"D:\schema _scource code1 _may\Auto Consellor\Auto-Consellor\Auto-Consellor-main_manipalla\Input_File\TW Disb Dump as on 30th Apr'23.xls"
tw = pd.read_excel(tw,usecols=["OSP_CODE"])




# Create a rejection Dataframe
rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

#Start With Data Massaging
print("Starting data massaging....")
obj1 = DataMassaging(dma_df, I_Process_Active_df, Master_df, rejected_df,tw,tagging)
obj1.execute()
print("Completed data massaging!")

dma_df = obj1.dma_df
rejected_df = obj1.rejection_df

print("\nApplying grids & calculating payout...")
obj2 = DataCalculation(dma_df)
obj2.execute()

summary_df = generateSummary(obj2.dma_df)
summary_df1 = generateSummary1(obj2.kerala_df)
summary_retainer=Caluation(obj2.dma_df,obj2.kerala_df)
print("Completed Payout Calculation!")

print("\nGenerating excel files...")
obj2.dma_df.to_excel("AUTO COUNSELLOR_MP_OUTPUT_NEW_USED_MAY2023.xlsx", index=False)
obj2.kerala_df.to_excel("AUTO COUNSELLOR_MP_OUTPUT_KERALA_MAY2023.xlsx", index=False)
rejected_df.to_excel("AUTO COUNSELLOR_MP_OUTPUT_REJECTED_MAY2023.xlsx", index=False)

summary_df.to_excel("AUTO COUNSELLOR_MP_SUMMARY_NEW_USED_MAY2023.xlsx")
summary_df1.to_excel("AUTO COUNSELLOR_MP_SUMMARY_KERALA_MAY2023.xlsx")
summary_df2=pd.concat([summary_df,summary_df1],ignore_index=True)
summary_df2.to_excel("AUTO COUNSELLOR_MP_SUMMARY_KERALA_NEW_USED_MAY2023.xlsx")
summary_retainer.to_excel("AUTO COUNSELLOR_SUMMARY_RETAINER_MAY2023.xlsx",index=False)
# kerala_df2=obj2.kerala_df
# _df_=obj2.dma_df
# Mixed=pd.merge([kerala_df2,_df_],ignore_index=True)
# Summary_further1=summary_further(Mixed)
print("Excel files generated!")




