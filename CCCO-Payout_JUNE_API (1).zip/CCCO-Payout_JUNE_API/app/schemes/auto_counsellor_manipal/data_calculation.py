import pandas as pd
import math

class DataCalculation:
    def __init__(self, dma_df:pd.DataFrame):
        self.dma_df = dma_df
        self.dma_df["NO_OF_CASES"] = 0
        self.dma_df["INCENTIVE_RATE"] = 0.0
        self.dma_df["PO_AMT"] = 0.0
        self.dma_df["checking"] = 0
        self.used_df = pd.DataFrame(columns=self.dma_df.columns)
        self.kerala_df = pd.DataFrame(columns=self.dma_df.columns)


    def SeparateDFs_CasesCalc(self):
        self.kerala_df = self.dma_df[self.dma_df["CONSOILIDATED_STATE"].str.lower() == "kerala"].copy()
        kerala_osp_count = self.kerala_df["OSP_CODE"].value_counts().to_dict()
        self.kerala_df["NO_OF_CASES"] = self.kerala_df["OSP_CODE"].map(kerala_osp_count)
        
        self.dma_df = self.dma_df[self.dma_df["CONSOILIDATED_STATE"].str.lower() != "kerala"]
        group = self.dma_df.groupby("OSP_CODE")
        for code, grp in group:
            self.dma_df.loc[(self.dma_df["OSP_CODE"] == code), "NO_OF_CASES"] = grp.shape[0]
            
            if(len(grp["LAN_TYPE"].unique()) == 1):
                if(grp["LAN_TYPE"].unique()[0] == "USED CAR"):
                    temp = self.dma_df[self.dma_df["OSP_CODE"] == code].copy()
                    self.used_df = pd.concat([self.used_df, temp], ignore_index=True)
                    self.dma_df = self.dma_df[self.dma_df["OSP_CODE"] != code]
        
                    
    def grid1_mixed(self, row):
        if(row["BOUND_INBOUND"] == "OUTBOUND"):
            if(row["Top/ Tier II"].lower() == "top"):
                if(row["SUM_OF_AMTFIN"] >= 8000000):
                    row["INCENTIVE_RATE"] = 0.0015
                    return row
                if(row["NO_OF_CASES"] <= 5):
                    return row
                elif(row["NO_OF_CASES"] <= 9):
                    row["INCENTIVE_RATE"] = 0.0007
                elif(row["NO_OF_CASES"] <= 13):
                    row["INCENTIVE_RATE"] = 0.0011
                else:
                    row["INCENTIVE_RATE"] = 0.0015
            else:
                if(row["SUM_OF_AMTFIN"] >= 6000000):
                    row["INCENTIVE_RATE"] = 0.0015
                    return row
                if(row["NO_OF_CASES"] <= 5):
                    return row
                elif(row["NO_OF_CASES"] <= 8):
                    row["INCENTIVE_RATE"] = 0.0007
                else:
                    row["INCENTIVE_RATE"] = 0.0015
        else:
            if(row["SUM_OF_AMTFIN"] >= 6000000):
                row["INCENTIVE_RATE"] = 0.0025
                return row
            if(row["NO_OF_CASES"] <= 5):
                return row
            elif(row["NO_OF_CASES"] <= 8):
                row["INCENTIVE_RATE"] = 0.0007
            elif(row["NO_OF_CASES"] <= 14):
                row["INCENTIVE_RATE"] = 0.0015
            else:
                row["INCENTIVE_RATE"] = 0.0025
                
        return row
        
        
    def grid1_used(self, row):
        if(row["NO_OF_CASES"] <= 3):
            return row
        elif(row["NO_OF_CASES"] <= 6):
            row["INCENTIVE_RATE"] = 0.0010
        elif(row["NO_OF_CASES"] <= 11):
            row["INCENTIVE_RATE"] = 0.0025
        elif(row["NO_OF_CASES"] <= 20):
            row["INCENTIVE_RATE"] = 0.0035
        else:
            row["INCENTIVE_RATE"] = 0.0050
        
        return row


    def grid2(self, row):
        broker = [263243, 287762, 287761, 287763, 287764, 287765, 287767, 287769, 287777, 287778, 287779, 287780, 287781, 287782, 287783, 287784, 287936, 287938, 287939, 287940, 287987, 292929, 292931]
        if(row["DMABROKERCODE"] in broker):
            row["INCENTIVE_RATE"] = 0.0
            
        return row


    def grid3(self, row):
        broker = [171659,
                194573,
                197846,
                183737,
                175552,
                207040,
                207946,
                208632,
                208859,
                212170,
                219020,
                237300,
                233542,
                247235,
                221664,
                271164,
                271690,
                284417,
                283995,
                285899,
                286991,
                289186,
                297632,
                272353,
                ]
            
        if((row["CONSOILIDATED_STATE"].lower() == "chennai") & (row["LAN_TYPE"] == "USED CAR")):
            if(row["Sourcing"] == "DSA"):
                if(row["DMABROKERCODE"] in broker):
                    if(row["NO_OF_CASES"] <= 3):
                        row["INCENTIVE_RATE"] = 0.0
                    elif(row["NO_OF_CASES"] <= 10):
                        row["INCENTIVE_RATE"] = 0.0010
                    else:
                        row["INCENTIVE_RATE"] = 0.0015
                if(row["SC"].lower() == "topup") | (row["SC"].lower() == "inbt"):
                    row["INCENTIVE_RATE"] = 0
            
        return row


    def grid_kerala(self, row):
        if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
            # if(row["Sourcing"] in ["DDSA", "ADM", "MBO"]):
            if(row["checking"]==0):
                if(row["NO_OF_CASES"] <= 5):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 9):
                    row["PO_AMT"] = 500
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250
            if(row["checking"]==1):
                if(row["NO_OF_CASES"] <= 5):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 9):
                    row["PO_AMT"] = 400
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250    
            if(row["checking"]==2):
                if(row["NO_OF_CASES"] <= 4):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 8):
                    row["PO_AMT"] = 500
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250    
        return row

        
        return row
    def grid5(self, row):
        new_broker = [266338, 266450, 269302, 274328]
        used_broker = [266338, 266450, 269302, 275078]
        used_oc = 274328
        if((row["DMABROKERCODE"] in new_broker) | (row["DMABROKERCODE"] in used_broker) | (row["DMABROKERCODE"] == used_oc)):
            if(row["SC"].lower() == "topup"):
                row["INCENTIVE_RATE"] = 0.0
                row["PO_AMT"] = 0.0
                return row
        
        if(row["LAN_TYPE"] == "NEW CAR"):
            if(row["DMABROKERCODE"] in new_broker):
                row["INCENTIVE_RATE"] = 0.0
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
        else:
            if(row["DMABROKERCODE"] in used_broker):
                row["INCENTIVE_RATE"] = 0.0020
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
            elif(row["DMABROKERCODE"] == used_oc):
                row["INCENTIVE_RATE"] = 0.0010
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
                            
            
        def round_up(n,decimals=0):
            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
        row["PO_AMT"]=round(row["PO_AMT"],3)    
        row["PO_AMT"]=round_up(row["PO_AMT"])
                   
                
        return row

    def TWGrid(self, row):
        if((row["IS_TW"] == False)):
            if(row["INCENTIVE_RATE"] == 0.0007):
                row["INCENTIVE_RATE"] = 0.0005
            elif(row["INCENTIVE_RATE"] == 0.0011):
                row["INCENTIVE_RATE"] = 0.0008
            elif(row["INCENTIVE_RATE"] == 0.0016):
                row["INCENTIVE_RATE"] = 0.0010
            elif(row["INCENTIVE_RATE"] == 0.0025):
                row["INCENTIVE_RATE"] = 0.0020
            
            if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                row["PO_AMT"] -= 400
                
        return row
               
                
    def POCalculation(self):
        self.dma_df["PO_AMT"] = round(self.dma_df["INCENTIVE_RATE"] * self.dma_df["REVISED AMOUNT FINANCE"],3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["PO_AMT"]=round_up(row["PO_AMT"])
            return row        
        self.dma_df=self.dma_df.apply(lambda x:Round_off(x),axis=1)                
        # self.used_df["PO_AMT"] = self.used_df["INCENTIVE_RATE"] * self.used_df["REVISED AMOUNT FINANCE"]
        
        
    def POCappedAmt(self, row):
        row["CAPPING"] = 3000
        row["PO_CAPPED_AMT"] = min(row["PO_AMT"], row["CAPPING"])
        sum = (row["TOTAL_SALARY"] + row["PO_CAPPED_AMT"])
        row["PO_CAPPED_AMT"] = (row["PO_CAPPED_AMT"] - sum + 50000) if (sum > 50000) else row["PO_CAPPED_AMT"] 
        row["PO_CAPPED_AMT"] = max(row["PO_CAPPED_AMT"], 0)
        return row
    
    def POCappedAmt1(self, row):
        row["CAPPING"] = 3000
        row["PO_CAPPED_AMT"] = min(row["PO_AMT"], row["CAPPING"])
        sum = (row["TOTAL_SALARY"] + row["PO_CAPPED_AMT"])
        row["PO_CAPPED_AMT"] = (row["PO_CAPPED_AMT"] - sum + 65000) if (sum > 65000) else row["PO_CAPPED_AMT"] 
        row["PO_CAPPED_AMT"] = max(row["PO_CAPPED_AMT"], 0)
        return row       
        
    def execute(self):
        self.SeparateDFs_CasesCalc()
        
        self.dma_df = self.dma_df.apply(lambda row : self.grid1_mixed(row), axis=1)
        self.used_df = self.used_df.apply(lambda row : self.grid1_used(row), axis=1)
        
        self.dma_df = pd.concat([self.dma_df, self.used_df], ignore_index=True)
        
        self.dma_df = self.dma_df.apply(lambda row : self.grid2(row), axis=1)
        # self.used_df = self.used_df.apply(lambda row : self.grid2(row), axis=1)
        
        self.dma_df = self.dma_df.apply(lambda row : self.grid3(row), axis=1)
        # self.used_df = self.used_df.apply(lambda row : self.grid3(row), axis=1)
        
        self.dma_df = self.dma_df.apply(lambda row : self.grid5(row), axis=1)
        # self.dma_df = self.dma_df.apply(lambda row: self.TWGrid(row), axis=1)
        # self.used_df = self.used_df.apply(lambda row : self.grid5(row), axis=1)
        
        self.POCalculation()

        temp=self.kerala_df.groupby("OSP_CODE")
        p=[]
        u=[]
        for code,grf in temp:
            
            k=grf.loc[grf["LAN_TYPE"]=="NEW CAR"].shape[0]
            if (k==grf.shape[0]):
                p.append(code)
            k=grf.loc[grf["LAN_TYPE"]=="USED CAR"].shape[0]
            if (k==grf.shape[0]):
                u.append(code)
                
        
        self.kerala_df.loc[self.kerala_df["OSP_CODE"].isin(p),"checking"]=1     
        self.kerala_df.loc[self.kerala_df["OSP_CODE"].isin(u),"checking"]=2    
        
        
        self.kerala_df = self.kerala_df.apply(lambda row : self.grid_kerala(row), axis=1)
        self.kerala_df = self.kerala_df.apply(lambda row : self.grid5(row), axis=1)
        # self.kerala_df = self.kerala_df.apply(lambda row: self.TWGrid(row), axis=1)    
        self.dma_df = self.dma_df.apply(lambda row : self.POCappedAmt(row), axis=1)
        # self.used_df = self.used_df.apply(lambda row : self.POCappedAmt(row), axis=1)
        self.kerala_df = self.kerala_df.apply(lambda row : self.POCappedAmt1(row), axis=1)
        self.dma_df=self.dma_df.drop(["checking"],axis=1)