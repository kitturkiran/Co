from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .data_massaging import DataMassaging
from .data_calculation import DataCalculation
from .po_summary import generateSummary,generateSummary1
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil
from .data_Calculation_retainer import Caluation

auto_couns_router = APIRouter()

@auto_couns_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def auto_couns_payout_calculation(dma: UploadFile, 
                                        process_active: UploadFile,
                                        master: UploadFile,
                                        tagging: UploadFile,
                                        tw: UploadFile,
                                        auto_secure:UploadFile,
                                        start_date: str = Body(...),
                                        end_date: str = Body(...), 
                                        bg_task: BackgroundTasks = None):
        
    dma_df = pd.read_excel(dma.file.read())
    dma_df["OSP_CODE"] = dma_df["OSP_CODE"].str.upper()
    
    process_active_file = process_active.file.read()

    I_Process_Active_df = pd.read_excel(process_active_file, sheet_name=0)
    
    
    

    
    I_Process_Active_df = I_Process_Active_df[["VSTS Code / Counselor SAP Code", "State", "I Process Gross salary", "Designation", "Top/ Tier II", "No of day"]]
    # Rename VSTS Code / Counselor SAP Code
    I_Process_Active_df.rename(columns={"VSTS Code / Counselor SAP Code":"OSP_CODE"}, inplace=True)
    I_Process_Active_df["OSP_CODE"] = I_Process_Active_df["OSP_CODE"].str.upper()    
    
    master_df = pd.read_excel(master.file.read(), usecols=["Aps Code", "Sourcing"])
    master_df.rename(columns={"Aps Code":"DMABROKERCODE"}, inplace=True)
    master_df.drop_duplicates(subset=["DMABROKERCODE"], keep="first", inplace=True)
    
    tagging_file = tagging.file.read()
    tagging_cols =["DMABROKERCODE", "Sourcing", "AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO "]
    tagging_df = pd.concat([pd.read_excel(tagging_file, sheet_name=1, usecols=tagging_cols),
                            pd.read_excel(tagging_file, sheet_name=2, usecols=tagging_cols)],
                            ignore_index=True
                            )
    
    
    tw_df = pd.read_excel(tw.file.read(), usecols=["OSP_CODE"])
    auto_secure=pd.read_excel(auto_secure.file.read())
    auto_secure.rename(columns={"CHARGE_AMT4/AUTO SECURE":"Auto Secure"},inplace=True)
    
    # auto_secure.rename(columns={"Asset Insurance charge ID- 500080":"AMT"},inplace=True)
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        
        dm_obj = DataMassaging(dma_df, I_Process_Active_df, master_df, rejected_df, tagging_df, tw_df,auto_secure,start_date,end_date)
        dm_obj.execute()
        
        dc_obj = DataCalculation(dm_obj.dma_df)
        dc_obj.execute()
        
        summary_retainer=Caluation(dc_obj.dma_df,dc_obj.kerala_df)

        summary_df = generateSummary(dc_obj.dma_df)
        summary_df1=generateSummary1(dc_obj.kerala_df)
        merged_df = pd.concat([summary_df, summary_df1], ignore_index=True)
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    
    file_name = f"auto_counsellor_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        dc_obj.dma_df.to_excel(writer, sheet_name="NEW_USED", index=False)
        dc_obj.kerala_df.to_excel(writer, sheet_name="KERALA", index=False)
        dm_obj.rejection_df.to_excel(writer, sheet_name="REJECTED", index=False)
        summary_df.to_excel(writer, sheet_name="SUMMARY", index=False)
        summary_df1.to_excel(writer, sheet_name="SUMMARY_kerla", index=False)
        merged_df.to_excel(writer, sheet_name="SUMMARY_kerla_newused", index=False)
        summary_retainer.to_excel(writer,sheet_name="SUMMARY_RETAINER",index=False)
    
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)


@auto_couns_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/auto_counsellor"
    destination_dir = f"./backup/AUTO_COUNSELLOR/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"