import os
import pandas as pd
from  data_massaging import DataMassaging
from  data_calculation import DataCalculation
from  data_Calculation_retainer import Caluation
from po_summary import generateSummary,generateSummary1

DMA_Path = r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\AUTO COU. MANIPAL MAY 23 DUMP..xlsx"
I_Process_Active_Path = r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\I process active.xlsx"
Master_Path = r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\Master File.xlsx"
tagging = r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\Tagging All.xlsx"
tw=r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\TW CASES.xlsx"
auto_secure=pd.read_excel(r"C:\Users\kiran.k\Downloads\1. Input\Counsellor Str May 23\Unseclore\AUTO COU. MANIPAL MAY 23 DUMP..xlsx")
auto_secure.rename(columns={"CHARGE_AMT4/Auto Secure":"Auto Secure"},inplace=True)
dma_df = pd.read_excel(DMA_Path)
dma_df["OSP_CODE"] = dma_df["OSP_CODE"].str.upper()

I_Process_Active_1_df = pd.read_excel(I_Process_Active_Path, sheet_name=0)
I_Process_Active_2_df = pd.read_excel(I_Process_Active_Path, sheet_name=1)
I_Process_Active_df = pd.read_excel(I_Process_Active_Path, sheet_name=0)

Master_df = pd.read_excel(Master_Path)

tagging_cols =["DMABROKERCODE", "Sourcing", "AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO "]
tagging_df = pd.concat([pd.read_excel(tagging, sheet_name=1, usecols=tagging_cols),
                            pd.read_excel(tagging, sheet_name=2, usecols=tagging_cols)],
                            ignore_index=True
                            )



I_Process_Active_df = I_Process_Active_df[["VSTS Code / Counselor SAP Code", "State", "I Process Gross salary", "Designation", "Top/ Tier II", "No of day"]]
# Rename VSTS Code / Counselor SAP Code
I_Process_Active_df.rename(columns={"VSTS Code / Counselor SAP Code":"OSP_CODE"}, inplace=True)
I_Process_Active_df["OSP_CODE"] = I_Process_Active_df["OSP_CODE"].str.upper()
# dma_df = pd.merge(dma_df, I_Process_Active_df, on="OSP_CODE")



Master_df = Master_df[["Aps Code", "Sourcing"]]
#Rename Aps Code
Master_df.rename(columns={"Aps Code":"DMABROKERCODE"}, inplace=True)

tw_df = pd.read_excel(tw, usecols=["OSP_CODE"])




# Create a rejection Dataframe
rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

#Start With Data Massaging
print("Starting data massaging....")
obj1 = DataMassaging(dma_df, I_Process_Active_df, Master_df, rejected_df, tagging_df, tw_df,auto_secure)
obj1.execute()
print("Completed data massaging!")

dma_df = obj1.dma_df
rejected_df = obj1.rejection_df

print("\nApplying grids & calculating payout...")
obj2 = DataCalculation(dma_df)
obj2.execute()

summary_retainer=Caluation(obj2.dma_df,obj2.kerala_df)

summary_df = generateSummary(obj2.dma_df)
summary_df1 = generateSummary1(obj2.kerala_df)
print("Completed Payout Calculation!")

print("\nGenerating excel files...")
obj2.dma_df.to_excel("AUTO COUNSELLOR_OUTPUT_NEW_USED_MAY.xlsx", index=False)
obj2.kerala_df.to_excel("AUTO COUNSELLOR_OUTPUT_KERALA_MAY.xlsx", index=False)
rejected_df.to_excel("AUTO COUNSELLOR_OUTPUT_REJECTED_MAY.xlsx", index=False)

summary_df.to_excel("AUTO COUNSELLOR_SUMMARY_NEW_USED_MAY.xlsx",index=False)
summary_df1.to_excel("AUTO COUNSELLOR_SUMMARY_KERALA_MAY.xlsx",index=False)
summary_df2=pd.concat([summary_df,summary_df1],ignore_index=True)
summary_df2.to_excel("AUTO COUNSELLOR_SUMMARY_KERALA_NEW_USED_MAY.xlsx",index=False)
summary_retainer.to_excel("AUTO COUNSELLOR_RETAINER_SUMMARY_KERALA_NEW_USED_MAY.xlsx",index=False)
print("Excel files generated!")