import pandas as pd

def generateSummary(df:pd.DataFrame):
    grp = df.groupby("OSP_CODE")

    summary_df = pd.DataFrame(columns=["OSPCodeCheck", "Retainer/LME Name", "Count", "Location", "State", "Amount finance", "Adv EMI", "Auto Secure", "Net Loan Amount", "Final Case Wise Incentive Payout", "Final commission", "Fixed Payout", "Fixed + Variable", "Capping", "Net Payable"])

    for code, gdf in grp:
        temp = {}
        temp["OSPCodeCheck"] = [code]
        temp["Retainer/LME Name"] = [gdf["DME_NAME"].iloc[0]]
        temp["Count"] = [gdf.shape[0]]
        temp["Location"] = [gdf["BRANCHNM"].iloc[0]]
        temp["State"] = [gdf["C State"].iloc[0]]
        temp["Amount finance"] = [gdf["SUM_OF_AMTFIN"].iloc[0]]
        temp["Adv EMI"] = [gdf["ADVANCE_EMI"].sum()]
        temp["Auto Secure"] = [gdf["Auto Secure"].sum()]
        temp["Net Loan Amount"] = [temp["Amount finance"][0] - temp["Auto Secure"][0]]
        temp["Final Case Wise Incentive Payout"] = [round(gdf["PO_AMT"].sum())]
        temp["Final commission"] = [round(gdf["PO_CAPPED_AMT"].sum())]
        temp["Fixed Payout"] = [gdf["TOTAL_SALARY"].iloc[0]]
        temp["Fixed + Variable"] = [temp["Final commission"][0] + temp["Fixed Payout"][0]]
        temp["Capping"] = [50000]
        # if(temp["State"]=="Kerala"):
        #     temp["Capping"] = [65000]
        
        if(temp["Fixed + Variable"][0] > temp["Capping"][0]):
            temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        else:
            temp["Net Payable"] = [temp["Final commission"][0]]
        
        # if((temp["Fixed + Variable"][0] > 65000) & (temp["State"]=="Kerala")):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]        
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    return summary_df
def generateSummary1(df:pd.DataFrame):
    grp = df.groupby("OSP_CODE")

    summary_df = pd.DataFrame(columns=["OSPCodeCheck", "Retainer/LME Name", "Count", "Location", "State", "Amount finance", "Adv EMI", "Auto Secure", "Net Loan Amount", "Final Case Wise Incentive Payout", "Final commission", "Fixed Payout", "Fixed + Variable", "Capping", "Net Payable"])

    for code, gdf in grp:
        temp = {}
        temp["OSPCodeCheck"] = [code]
        temp["Retainer/LME Name"] = [gdf["DME_NAME"].iloc[0]]
        temp["Count"] = [gdf.shape[0]]
        temp["Location"] = [gdf["BRANCHNM"].iloc[0]]
        temp["State"] = [gdf["C State"].iloc[0]]
        temp["Amount finance"] = [gdf["SUM_OF_AMTFIN"].iloc[0]]
        temp["Adv EMI"] = [gdf["ADVANCE_EMI"].sum()]
        temp["Auto Secure"] = [gdf["Auto Secure"].sum()]
        temp["Net Loan Amount"] = [temp["Amount finance"][0] - temp["Auto Secure"][0]]
        temp["Final Case Wise Incentive Payout"] = [round(gdf["PO_AMT"].sum())]
        temp["Final commission"] = [round(gdf["PO_CAPPED_AMT"].sum())]
        temp["Fixed Payout"] = [gdf["TOTAL_SALARY"].iloc[0]]
        temp["Fixed + Variable"] = [temp["Final commission"][0] + temp["Fixed Payout"][0]]
        temp["Capping"] = [65000]
        # if(temp["State"]=="Kerala"):
        #     temp["Capping"] = [65000]
        
        if(temp["Fixed + Variable"][0] > temp["Capping"][0]):
            temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        else:
            temp["Net Payable"] = [temp["Final commission"][0]]
        
        # if((temp["Fixed + Variable"][0] > 65000) & (temp["State"]=="Kerala")):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]        
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    return summary_df