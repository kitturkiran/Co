from datetime import datetime
import os
import pandas as pd

class DataMassaging:
    def __init__(self, dma_df: pd.DataFrame, I_Process_Active_df: pd.DataFrame, Master_df: pd.DataFrame, rejection_df: pd.DataFrame, tagging_df:pd.DataFrame,tw_df: pd.DataFrame,auto_secure:pd.DataFrame,start_date,end_date):
        self.dma_df = dma_df
        self.used_df = pd.DataFrame()
        self.I_Process_Active_df = I_Process_Active_df
        self.Master_df = Master_df
        self.rejection_df = rejection_df
        self.tagging_df = tagging_df
        # self.tagging_new_df = tagging_new_df
        # self.tagging_used_df = tagging_used_df
        # self.asset_insurance_df = asset_insurance_df
        self.tw_df = tw_df
        self.auto_secure=auto_secure
        print(self.auto_secure)
        # self.tagging_branch_df = tagging_branch_df
        self.startDate=start_date
        self.endDate=end_date
        
        
    def processSC(self):
        self.dma_df["SC"] = "-"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("inbt")), "SC"] = "inbt"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("internal")), "SC"] = "topup"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("external")), "SC"] = "external"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("max")), "SC"] = "maxx"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("refinance")), "SC"] = "refinance"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["CHANNELCODE"].str.lower().str.contains("insta")), "SC"] = "insta"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("internal")), "SC"] = "topup"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("top")), "SC"] = "topup"
        # self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"]=="INTopup_Track_Multiplier"), "SC"] = "topup"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("max")), "SC"] = "maxx"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("max")), "SC"] = "maxx"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("refinance")), "SC"] = "refinance"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("eclgs")), "SC"] = "eclgs"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["CHANNELCODE"].str.lower().str.contains("insta")), "SC"] = "insta"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("external")), "SC"] = "external"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("internal")), "SC"] = "topup"
        self.dma_df.loc[(self.dma_df["SC"] == '-') & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("refinance")), "SC"] = "refinance"
        # self.df.loc[(self.df["SC"] == '-') & (self.df["PROMOTIONDESC"].str.lower().str.contains("eclgs")), "SC"] = "eclgs"
        self.dma_df.loc[(self.dma_df["SC"] == '-'), "SC"] = "sale purchase"
        self.dma_df.loc[(self.dma_df["CHANNELCODE"].str.lower().str.startswith("intopup")==True), "SC"] = "topup"

    def MergeTagging(self):
        # tagging_new = self.tagging_new_df[["AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO "]]
        # tagging_used = self.tagging_used_df[["AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO "]]
        # # tagging_branch = self.tagging_branch_df[["AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO "]]

        # tagging_final = pd.concat([tagging_new, tagging_used])
        # print(tagging_final.shape)

        self.dma_df = pd.merge(self.dma_df, self.tagging_df[["AGREEMENTNO", "Asset Insurance charge ID- 500080", "Asset Insurance PO ","Segment"]], on="AGREEMENTNO", how="left")
        # print(self.dma_df.shape)
    
    def MergeAssetInsurance(self):
        # cd = os.getcwd()
        # asset_insurance_df = pd.read_excel(r"C:\Users\Kiran.k\Downloads\schema _scource code\Auto Consellor\Auto-Consellor_December\Auto-Consellor-main\Input_File\Asset Insurance PO.xlsx")
        # asset_insurance_df.rename(columns={"Remarks": "SC"}, inplace=True)
        # asset_insurance_df = asset_insurance_df[["AGREEMENTNO", "SC"]]
        self.dma_df = pd.merge(self.dma_df, self.asset_insurance_df, on="AGREEMENTNO")
        print(self.dma_df.shape)
    
    
    def RemoveOutsidePeriod(self):
        self.dma_df["DISB_DATE"] = pd.to_datetime(self.dma_df["DISB_DATE"])
        # startDate = datetime.strptime("1-3-2023", "%d-%m-%Y")
        # endDate = datetime.strptime("31-3-2023", "%d-%m-%Y")
        temp = self.dma_df[((self.dma_df["DISB_DATE"] > self.endDate) == True) | ((self.dma_df["DISB_DATE"] < self.startDate) == True)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Outside the Period of Calculation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[((self.dma_df["DISB_DATE"] <= self.endDate) == True) & ((self.dma_df["DISB_DATE"] >= self.startDate) == True)]
    
       
    def StatusOtherThanA(self):
        temp = self.dma_df[self.dma_df["STATUS"] != 'A'].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Status Other Than A"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["STATUS"] == 'A']
        print(self.dma_df.shape)
    
    def AgreementBlankCases(self):
        temp = self.dma_df[self.dma_df["AGREEMENTNO"].isna()].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Agreement Blank Cases"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.df = self.dma_df[~self.dma_df["AGREEMENTNO"].isna()]
        print(self.dma_df.shape)
    
    
    def OSPBlankCases(self):
        temp = self.dma_df[self.dma_df["OSP_CODE"].isna()].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "OSP Code Blank Cases"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["OSP_CODE"].isna() == False]
        print(self.dma_df.shape)
    
    
    def OSPOnlyNumberCase(self):
        temp = self.dma_df[(self.dma_df["OSP_CODE"].astype(str).str.isdigit()) & (self.dma_df["OSP_CODE"].astype(str).str.len() == 6)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Cases Source by Bank Employee"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["OSP_CODE"].astype(str).str.isdigit() == False) & (self.dma_df["OSP_CODE"].astype(str).str.len() != 6)]
        print(self.dma_df.shape)
    
    def MapOPSCode(self):
        osp_codes = self.I_Process_Active_df["OSP_CODE"].to_list()
        print(osp_codes)
        temp = self.dma_df[~self.dma_df["OSP_CODE"].isin(osp_codes)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "OSP Code not found in master"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["OSP_CODE"].isin(osp_codes)]
        print(self.dma_df.shape)
    
    
    def MergeIProcessActive(self):
        self.dma_df = pd.merge(self.dma_df, self.I_Process_Active_df, on="OSP_CODE")
        self.dma_df.rename(columns={"State":"CONSOILIDATED_STATE"}, inplace=True)
        self.dma_df.rename(columns={"I Process Gross salary":"TOTAL_SALARY"}, inplace=True)
        self.dma_df["PROCESS_FLAG"] = "VALID"
        self.dma_df.loc[self.dma_df["CONSOILIDATED_STATE"].str.lower().str.contains("chennai"), "PROCESS_FLAG"] = "CHENNAI VALID"
        self.dma_df.loc[self.dma_df["CONSOILIDATED_STATE"].str.lower().str.contains("kerala"), "PROCESS_FLAG"] = "KERALA VALID"
        print(self.dma_df.shape)
     
    def MapConsolidatedState(self):
        self.MergeIProcessActive()
        temp = self.dma_df[self.dma_df["CONSOILIDATED_STATE"].isna()].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "State not found in master"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["CONSOILIDATED_STATE"].isna())]
        print(self.dma_df.shape)
    
    
    def MapNoOfDay(self):
        temp = self.dma_df[self.dma_df["No of day"] == 0].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "No of day 0 in master"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["No of day"] != 0]
        print(self.dma_df.shape)
    
    
    def MapTotalSalary(self):
        temp = self.dma_df[self.dma_df["TOTAL_SALARY"] == 0].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Total Salary 0 in master"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["TOTAL_SALARY"] != 0]
        print(self.dma_df.shape)
    
    
    def MapDesignation(self):
        temp = self.dma_df[self.dma_df["Designation"].isna()].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Designation not found in master"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~self.dma_df["Designation"].isna()]
        print(self.dma_df.shape)
    
    
    def NovationCases(self):
        temp = self.dma_df[self.dma_df["SCHEMECODE"].str.lower().str.contains("novation")].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "NOVATION"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["SCHEMECODE"].str.lower().str.contains("novation") == False]
        print(self.dma_df.shape)
    
    
    def RBKCases(self):
        temp = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk")].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "RBK"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk") == False]
        print(self.dma_df.shape)
    
    
    def DeathCases(self):
        temp = self.dma_df[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death",na=False)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "DEATH"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death",na=False) == False]
        print(self.dma_df.shape)
    
    def NabardCases(self):
        self.dma_df["EMPLOYERNAME"].fillna("-", inplace=True)
        temp = self.dma_df[self.dma_df["EMPLOYERNAME"].str.lower().str.contains("nabard")].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "NABARD"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["EMPLOYERNAME"].str.lower().str.contains("nabard") == False]
        print(self.dma_df.shape)
        
    def MapSourcingFromTagging(self, row):

        broker_code = row["DMABROKERCODE"]
        
        if(self.tagging_df[self.tagging_df["DMABROKERCODE"] == broker_code].shape[0] > 0):
            row["Sourcing"] = self.tagging_df[self.tagging_df["DMABROKERCODE"] == broker_code]["Sourcing"].iloc[0]
        
        return row
    
    
    def MapSourcing(self):
        self.Master_df.dropna(subset=["DMABROKERCODE"], inplace=True)
        self.dma_df = pd.merge(self.dma_df, self.Master_df, on="DMABROKERCODE", how='left')
        self.dma_df.loc[(self.dma_df["NAME"].str.lower().str.contains("branch")), "Sourcing"] = "ADM"
        self.dma_df.loc[(self.dma_df["NAME"].str.len() >= 4) & (self.dma_df["NAME"].str[-4:].str.isdigit()), "Sourcing"] = "ADM"
        self.dma_df.loc[(self.dma_df["NAME"].str.lower().str.contains("alternate channel")), "Sourcing"] = "DST"
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="SPTNE00047464320"),"Sourcing"]= "DST"
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"]=="SPGUR00047474058"),"Sourcing"]= "DST"
        dma_na = self.dma_df[(self.dma_df["Sourcing"].isna() | self.dma_df["Sourcing"].str.lower().str.contains("not found"))].copy()
        self.dma_df = self.dma_df[~(self.dma_df["Sourcing"].isna() | self.dma_df["Sourcing"].str.lower().str.contains("not found"))]
        self.tagging_df.dropna(subset=["DMABROKERCODE"], inplace=True)
        # self.tagging_used_df.dropna(subset=["DMABROKERCODE"], inplace=True)
        # self.tagging_branch_df.dropna(subset=["DMABROKERCODE"], inplace=True)
        
        dma_na = dma_na.apply(lambda row: self.MapSourcingFromTagging(row), axis=1)
        
        self.dma_df = pd.concat([self.dma_df, dma_na], ignore_index=True)
        # self.dma_df.loc[(self.dma_df["Sourcing"].str.lower().str.contains("branch",na=False)), "Sourcing"] = "ADM"
        
        temp = self.dma_df[(self.dma_df["Sourcing"].isna() | self.dma_df["Sourcing"].str.lower().str.contains("not found"))].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Sourcing not found in master"
        print(temp)
        print(temp.shape)
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        print(self.dma_df.shape)
        self.dma_df = self.dma_df[~(self.dma_df["Sourcing"].isna() | self.dma_df["Sourcing"].str.lower().str.contains("not found"))]
        print(self.dma_df.shape)
    
    
    def ClassifyNewUsed(self):
        temp = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LA") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("LU") == False) & (self.dma_df["AGREEMENTNO"].str.startswith(
            "LP") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("SP") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("PU") == False)].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Neither New nor Used"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LA") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LU") == True) | (self.dma_df["AGREEMENTNO"].str.startswith(
            "LP") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("SP") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("PU") == True)]
        self.dma_df["LAN_TYPE"] = ""
        self.dma_df.loc[self.dma_df["AGREEMENTNO"].str.startswith("LA") == True, "LAN_TYPE"] = "NEW CAR"
        self.dma_df.loc[self.dma_df["AGREEMENTNO"].str.startswith("LA") == False, "LAN_TYPE"] = "USED CAR"
    
    
    def RemoveDSAMBOCases(self):
        temp = self.dma_df[(self.dma_df["LAN_TYPE"] == 'NEW CAR') & ((self.dma_df["Sourcing"] == "DSA") | (self.dma_df["Sourcing"] == "DSA-MBO"))].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Other then Confirm by bank"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["LAN_TYPE"] == 'USED CAR') | ((self.dma_df["LAN_TYPE"] == 'NEW CAR') & (self.dma_df["Sourcing"].str.lower() != "dsa") & (self.dma_df["Sourcing"].str.lower() != "dsa-mbo"))]
        self.dma_df=self.dma_df.loc[self.dma_df["AGREEMENTNO"].duplicated()==False]
    
    def OutboundInbound(self):
        self.dma_df["BOUND_INBOUND"] = ""
        grp = self.dma_df.groupby("OSP_CODE")
        for code, gdf in grp:
            adm = gdf[gdf["Sourcing"] == "ADM"].shape[0]
            ddsa = gdf[gdf["Sourcing"] == "DDSA"].shape[0]
            dsa = gdf[gdf["Sourcing"] == "DSA"].shape[0]
            dst = gdf[gdf["Sourcing"] == "DST"].shape[0]
            mbo = gdf[gdf["Sourcing"] == "DSA-MBO"].shape[0]
            agg = gdf[gdf["Sourcing"] == "DDSA-Aggregator"].shape[0]
            agg1 = gdf[gdf["Sourcing"] == "Aggregator"].shape[0]
            inbound = adm + dst
            outbound = ddsa + dsa + dst + mbo + agg +agg1
            
            if inbound == outbound:
                self.dma_df.loc[((self.dma_df["OSP_CODE"] == code) & (self.dma_df["Designation"].str.lower().str.contains("retainer"))), "BOUND_INBOUND"] = "OUTBOUND"
                self.dma_df.loc[((self.dma_df["OSP_CODE"] == code) & (self.dma_df["Designation"].str.lower().str.contains("lme"))), "BOUND_INBOUND"] = "INBOUND"
                self.dma_df.loc[((self.dma_df["OSP_CODE"] == code) & (self.dma_df["Designation"].str.lower().str.contains("retainer cum lme"))), "BOUND_INBOUND"] = "OUTBOUND"
                self.dma_df.loc[((self.dma_df["OSP_CODE"] == code) & (self.dma_df["Designation"].str.lower().str.contains("lme cum retainer"))), "BOUND_INBOUND"] = "INBOUND"
            elif outbound > inbound:
                self.dma_df.loc[self.dma_df["OSP_CODE"] == code, "BOUND_INBOUND"] = "OUTBOUND"
            else:
                self.dma_df.loc[self.dma_df["OSP_CODE"] == code, "BOUND_INBOUND"] = "INBOUND"
                
    
    def AdditionalColsforFinalFile(self):
        self.dma_df["REVISED AMOUNT FINANCE"] = self.dma_df["AMTFIN"] - self.dma_df["ADVANCE_EMI"]
        for col in self.dma_df.columns:
            print(col)
        print(self.dma_df["Asset Insurance PO "].head())
        print(self.auto_secure)
        self.dma_df=pd.merge(self.dma_df,self.auto_secure[["AGREEMENTNO","Auto Secure"]],on="AGREEMENTNO",how="left")
        # print(self.dma_df["AMT"])
        self.dma_df["Auto Secure"].fillna(0, inplace=True)
        
        self.dma_df["REVISED AMOUNT FINANCE"] = self.dma_df["REVISED AMOUNT FINANCE"] - self.dma_df["Auto Secure"]
        # self.dma_df["CAPPING"] = 3000
        self.dma_df["SUM_OF_AMTFIN"] = 0
        grp = self.dma_df.groupby("OSP_CODE")
        
        for code, grp_df in grp:
            self.dma_df.loc[self.dma_df["OSP_CODE"] == code, "SUM_OF_AMTFIN"] = grp_df["AMTFIN"].sum()
    
    
    def RemoveDSAHelp(self, row):
        dict = {
            # "Kama093778":"Rajasthan",
            # "IPRO005079N00078":"Rajasthan",
            # "IPRO005079P07994":"Rajasthan",
            # "IPRO005079S02110":"Rajasthan",
            # "IPRO005079T01309":"Rajasthan",
            # 'IPRO005079T00878':'Rajasthan',
            # # 'IPRO005079P07728':'Rajasthan',
            # 'IPRO005079I05229':'NAGPUR',
            # 'IPRO005079X05552':'NAGPUR',
            # 'IPRO005079H01287':'NAGPUR',
            # 'MANI080536A09896':'NAGPUR',
            # 'IPRO005079R05731':'GOA',
            # 'MANI080536B03432':'SANGLI',
            # 'IPRO005079N06551':'SATARA',
            # 'IPRO005079Z03705':'GOA',
            # 'IPRO005079W06386':'Goa',
            # 'IPRO005079V09249':'KOLHAPUR',
            # 'IPRO005079W05776':'KOLHAPUR',
            # 'IPRO005079A05780':'Goa',
            # 'IPRO005079Z04763':'SATARA',
            # 'IPRO005079P05620':'Nasik','IPRO005079R03870':'Nasik',
            # 'IPRO005079Z04927':'Nasik',
            # 'IPRO005079A03780':'Aurangabad',
            # 'IPRO005079R04340':'Aurangabad',
            # 'IPRO005079B02907':'Ahmednagar',
            # 'ipro005079s03640':'Jalgaon',
            # # 'FNF':'Pune',
            # 'IPRO005079S07357':'Pune',
            # 'IPRO005079Q00760':'Pune',
            # 'IPRO005079P03783':'Pune',
            # 'IPRO005079E08031':'Pune',
            # 'IPRO005079E09386':'Pune',
            # 'MANI080536B03134':'Pune',
            # 'MANI080536B03976':'Pune',
            # 'IPRO005079F02478':'Pune',
            # 'IPRO005079Y09504':'Pune',
            # 'IPRO005079M02842':'Pune',
            # 'IPRO005079X05317':'Pune',
            # 'IPRO005079Y01422':'Pune',
            # 'SAND065876':'Pune',
            # 'IPRO005079S02819':'Pune',
            # 'IPRO005079V03980':'Pune',
            # 'IPRO005079S07922':'Pune',
            # 'IPRO005079V06844':'Pune',
            # 'IPRO005079R03384':'Pune',
            # 'IPRO005079Z05444':'Pune',
            # 'IPRO005079A01494':'Pune',
            # 'IPRO005079C07622':'Pune',
            

                "Kama093778":"romg",
                "IPRO005079N00078":"romg",
                "IPRO005079P07994":"romg",
                "IPRO005079S02110":"romg",
                "IPRO005079T01309":"romg",
                "IPRO005079T00878":"romg",
                "IPRO005079I05229":"romg",
                "IPRO005079X05552":"romg",
                "IPRO005079H01287":"romg",
                "MANI080536A09896":"romg",
                "IPRO005079N06551":"romg",
                "IPRO005079Z03705":"romg",
                "IPRO005079V09249":"romg",
                "IPRO005079W05776":"romg",
                "IPRO005079Z04763":"romg",
                "IPRO005079R05731":"romg",
                "MANI080536B03432":"romg",
                "IPRO005079F07220":"romg",
                "IPRO005079P05620":"romg",
                "IPRO005079R03870":"romg",
                "IPRO005079Z04927":"romg",
                "IPRO005079R04340":"romg",
                "IPRO005079B02907":"romg",
                "IPRO005079S03640":"romg",
                "IPRO005079S07357":"romg",
                "IPRO005079Q00760":"romg",
                "IPRO005079P03783":"romg",
                "IPRO005079Y09504":"romg",
                "IPRO005079M02842":"romg",
                "IPRO005079X05317":"romg",
                "SAND065876":"romg",
                "IPRO005079S02819":"romg",
                "IPRO005079V03980":"romg",
                "IPRO005079S07922":"romg",
                "IPRO005079V06844":"romg",
                "IPRO005079R03384":"romg",
                "IPRO005079Z05444":"romg",
                "IPRO005079A01494":"romg",
                "IPRO005079C07622":"romg",
                "IPRO005079E08031":"romg",
                "IPRO005079E09386":"romg",
                "MANI080536B03134":"romg",
                "MANI080536B03976":"romg",
                "IPRO005079F02478":"romg",
                "MANI080536B03987":"romg",


            
        }
        
        chennai_broker = [171659,194573,197846,183737,175552,207040,207946,208632,208859,212170,219020,237300,233542,247235,221664,271164,271690,284417,283995,285899,286991,289186,297632,272353]

        if(row["LAN_TYPE"] == "USED CAR"):
            if(row["CONSOILIDATED_STATE"].lower() != "gujarat"):
                if(row["Sourcing"] == "DSA"):
                    if(row["OSP_CODE"] in dict.keys()):
                        row["flag"] = True
                        # if(dict[row["OSP_CODE"]].lower() != row["CONSOILIDATED_STATE"].lower()):
                        #     row["flag"] = False
                    else:
                        row["flag"] = False

                    if((row["CONSOILIDATED_STATE"].lower() == "chennai") & (row["DMABROKERCODE"] in chennai_broker)):
                        row["flag"] = True
        
        return row
    
    
    def RemoveDSAOldCar(self):
        self.dma_df["flag"] = True
        self.dma_df = self.dma_df.apply(lambda row : self.RemoveDSAHelp(row), axis=1)
        temp = self.dma_df[self.dma_df["flag"] == False].copy()
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Override 18"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df =  self.dma_df[self.dma_df["flag"] == True]
        # self.dma_df=self.dma_df.loc[self.dma_df["AGREEMENTNO"].duplicated()==False]
    
    def FlagTWCases(self):
        self.dma_df["IS_TW"] = True
        grp = self.tw_df.groupby("OSP_CODE")
        for code, gdf in grp:
            if(gdf.shape[0] < 5):
                self.dma_df.loc[(self.dma_df["OSP_CODE"] == code), "IS_TW"] = False
    # def BoundFromDesignation(self):
    #     self.dma_df.loc[(self.dma_df["Designation"].str.lower() == "retainer") & ((self.dma_df["Sourcing"].str.lower() == "ddsa") | (self.dma_df["Sourcing"].str.lower() == "dst")), "BOUND_INBOUND"] = "OUTBOUND"
        
    #     self.dma_df.loc[(self.dma_df["Designation"].str.lower() == "retainer cum lme") & ((self.dma_df["Sourcing"].str.lower() == "ddsa") | (self.dma_df["Sourcing"].str.lower() == "dst") | (self.dma_df["Sourcing"].str.lower() == "adm")), "BOUND_INBOUND"] = "OUTBOUND"
        
    #     self.dma_df.loc[(self.dma_df["Designation"].str.lower() == "lme") & ((self.dma_df["Sourcing"].str.lower() == "adm") | (self.dma_df["Sourcing"].str.lower() == "dst")), "BOUND_INBOUND"] = "INBOUND"
        
    #     self.dma_df.loc[(self.dma_df["Designation"].str.lower() == "lme cum retainer") & ((self.dma_df["Sourcing"].str.lower() == "adm") | (self.dma_df["Sourcing"].str.lower() == "dst") | (self.dma_df["Sourcing"].str.lower() == "ddsa")), "BOUND_INBOUND"] = "INBOUND"
    
    
    def execute(self):
        self.processSC()
        self.MergeTagging()
        # self.MergeAssetInsurance()
        self.RemoveOutsidePeriod()
        self.StatusOtherThanA()
        self.AgreementBlankCases()
        self.OSPBlankCases()
        self.OSPOnlyNumberCase()
        self.MapOPSCode()
        self.MapConsolidatedState()
        self.MapNoOfDay()
        self.MapTotalSalary()
        self.MapDesignation()
        self.NovationCases()
        self.RBKCases()
        self.DeathCases()
        self.NabardCases()
        self.MapSourcing()
        self.ClassifyNewUsed()
        self.RemoveDSAMBOCases()
        self.RemoveDSAOldCar()
        self.OutboundInbound()
        self.AdditionalColsforFinalFile()
        self.FlagTWCases()
        # self.BoundFromDesignation()