import pandas as pd

def generateSummary(df:pd.DataFrame):
    grp = df.groupby("I process Emp Code of TL")

    summary_df = pd.DataFrame(columns=["Employee ID", "State2", "Name of Team Leader (TL)", "NEW", "USED", "No of total N/U", "New/Used", "Per Cases", "Incentives", "Salary", "Fix + Ince", "Capping", "Incentives to be paid"])

    for code, gdf in grp:
        temp = {}
        temp["Employee ID"] = [code]
        temp["State2"] = [gdf["State"].iloc[0]]
        temp["Name of Team Leader (TL)"] = [gdf["Name of Team Leader (TL)"].iloc[0]]
        temp["NEW"] = [gdf["Count_of_emp_code_new"].iloc[0]]
        temp["USED"] = [gdf["Count_of_emp_code_used"].iloc[0]]
        temp["No of total N/U"] = [gdf["Count_of_emp_code"].iloc[0]]
        temp["New/Used"] = [gdf["NEW/USED"].iloc[0]]
        temp["Per Cases"] = [gdf["PO"].iloc[0]]
        temp["Incentives"] = [gdf["Payout"].iloc[0]]
        temp["Salary"] = [(gdf["I Process Gross salary"]).iloc[0]]
        temp["Fix + Ince"] = [(gdf["PO+Salary"].iloc[0])]
        # temp["CAP"] = [gdf["TOTAL_SALARY"].iloc[0]]
        # temp["Fixed + Variable"] = [temp["Final commission"][0] + temp["Fixed Payout"][0]]
        temp["Capping"] = [35000]
        temp["Incentives to be paid"]=[(gdf["Final Payout"].iloc[0])]
        # if(temp["State"]=="Kerala"):
        #     temp["Capping"] = [65000]
        
        # if(temp["Fixed + Variable"][0] > temp["Capping"][0]):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]
        
        # if((temp["Fixed + Variable"][0] > 65000) & (temp["State"]=="Kerala")):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]        
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    return summary_df
def generateSummary1(df:pd.DataFrame):
    grp = df.groupby("I process Emp Code of TL")

    summary_df = pd.DataFrame(columns=["Employee code", "State2", "Name of Team Leader (TL)", "Total", "Incentive Amt/case", "Incentive Applicable", "Salary", "Sal+Incentives", "Cap", "Incentives to be paid"])

    for code, gdf in grp:
        temp = {}
        temp["Employee code"] = [code]
        temp["State2"] = [gdf["State"].iloc[0]]
        temp["Name of Team Leader (TL)"] = [gdf["Name of Team Leader (TL)"].iloc[0]]
        temp["Total"] = [gdf.shape[0]]
        temp["Incentive Amt/case"] = [gdf["Payout"].iloc[0]]
        temp["Incentive Applicable"] = 0
        temp["Salary"] = [gdf["I Process Gross salary"].iloc[0]]
        temp["Sal+Incentives"] = [gdf["PO+Salary"].iloc[0]]
        temp["Cap"] = [gdf["Capping"].iloc[0]]
        temp["Incentives to be paid"] = [round(gdf["Final Payout"]).iloc[0]]
        # temp["Final commission"] = [round(gdf["PO_CAPPED_AMT"].sum())]
        # temp["Fixed Payout"] = [gdf["TOTAL_SALARY"].iloc[0]]
        # temp["Fixed + Variable"] = [temp["Final commission"][0] + temp["Fixed Payout"][0]]
        # temp["Capping"] = [65000]
        # if(temp["State"]=="Kerala"):
        #     temp["Capping"] = [65000]
        
        # if(temp["Fixed + Variable"][0] > temp["Capping"][0]):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]
        
        # if((temp["Fixed + Variable"][0] > 65000) & (temp["State"]=="Kerala")):
        #     temp["Net Payable"] = [temp["Final commission"][0] - (temp["Fixed + Variable"][0] - temp["Capping"][0])]
        # else:
        #     temp["Net Payable"] = [temp["Final commission"][0]]        
        
        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    return summary_df



def generateSummary2(df:pd.DataFrame):
    grp = df.groupby("Emp Code")

    summary_df = pd.DataFrame(columns=["Employee Code", "OSP_CODE", "DME_NAME", "Total"])

    for code, gdf in grp:
        temp = {}
        temp["Employee Code"] = [code]
        temp["OSP_CODE"] = [gdf["OSP_CODE"].iloc[0]]
        temp["DME_NAME"] = [gdf["DME_NAME"].iloc[0]]
        temp["Total"] = [gdf["Payout_after_Capping"].sum()]

        temp = pd.DataFrame(temp)
        summary_df = pd.concat([summary_df, temp], ignore_index=True)  
        
    return summary_df