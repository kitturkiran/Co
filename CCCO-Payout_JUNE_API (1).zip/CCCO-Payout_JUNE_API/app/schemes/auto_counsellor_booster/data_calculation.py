import pandas as pd
import math

class DataCalculation:
    def __init__(self, dma_df:pd.DataFrame,booster_tier2:pd.DataFrame,booster_top:pd.DataFrame,I_Process_Active_2_df:pd.DataFrame,Rejection_df:pd.DataFrame,booster_Delhi:pd.DataFrame):
        self.dma_df = dma_df
        print(self.dma_df.shape[0],"kiran")
        self.dma_df["NO_OF_CASES"] = 0
        self.dma_df["INCENTIVE_RATE"] = 0.0
        self.dma_df["PO_AMT"] = 0
        self.dma_df["checking"] = 0
        # self.used_df = pd.DataFrame(columns=self.dma_df.columns)
        # self.kerala_df = pd.DataFrame(columns=self.dma_df.columns)
        self.Booster_tier=booster_tier2
        self.booster_top=booster_top
        self.booster_Delhi=booster_Delhi
        self.I_Process_Active_2_df=I_Process_Active_2_df
        self.rejection_df=Rejection_df
        self.top=None
        self.tier=None


    def SeparateDFs_CasesCalc(self):
        self.kerala_df = self.dma_df[self.dma_df["CONSOILIDATED_STATE"].str.lower() == "kerala"].copy()
        kerala_osp_count = self.kerala_df["OSP_CODE"].value_counts().to_dict()
        self.kerala_df["NO_OF_CASES"] = self.kerala_df["OSP_CODE"].map(kerala_osp_count)
        
        self.dma_df = self.dma_df[self.dma_df["CONSOILIDATED_STATE"].str.lower() != "kerala"]
        group = self.dma_df.groupby("OSP_CODE")
        for code, grp in group:
            self.dma_df.loc[(self.dma_df["OSP_CODE"] == code), "NO_OF_CASES"] = grp.shape[0]
            
            if(len(grp["LAN_TYPE"].unique()) == 1):
                if(grp["LAN_TYPE"].unique()[0] == "USED CAR"):
                    temp = self.dma_df[self.dma_df["OSP_CODE"] == code].copy()
                    self.used_df = pd.concat([self.used_df, temp], ignore_index=True)
                    self.dma_df = self.dma_df[self.dma_df["OSP_CODE"] != code]
        
                    
    def grid1_mixed(self, row):
        if(row["BOUND_INBOUND"] == "OUTBOUND"):
            if(row["Top/ Tier II"].lower() == "top"):
                if(row["SUM_OF_AMTFIN"] >= 8000000):
                    row["INCENTIVE_RATE"] = 0.0015
                    return row
                if(row["NO_OF_CASES"] <= 5):
                    return row
                elif(row["NO_OF_CASES"] <= 9):
                    row["INCENTIVE_RATE"] = 0.0007
                elif(row["NO_OF_CASES"] <= 13):
                    row["INCENTIVE_RATE"] = 0.0011
                else:
                    row["INCENTIVE_RATE"] = 0.0015
            else:
                if(row["SUM_OF_AMTFIN"] >= 6000000):
                    row["INCENTIVE_RATE"] = 0.0015
                    return row
                if(row["NO_OF_CASES"] <= 5):
                    return row
                elif(row["NO_OF_CASES"] <= 8):
                    row["INCENTIVE_RATE"] = 0.0007
                else:
                    row["INCENTIVE_RATE"] = 0.0015
        else:
            if(row["SUM_OF_AMTFIN"] >= 6000000):
                row["INCENTIVE_RATE"] = 0.0025
                return row
            if(row["NO_OF_CASES"] <= 5):
                return row
            elif(row["NO_OF_CASES"] <= 8):
                row["INCENTIVE_RATE"] = 0.0007
            elif(row["NO_OF_CASES"] <= 14):
                row["INCENTIVE_RATE"] = 0.0015
            else:
                row["INCENTIVE_RATE"] = 0.0025
                
        return row
        
        
    def grid1_used(self, row):
        if(row["NO_OF_CASES"] <= 3):
            return row
        elif(row["NO_OF_CASES"] <= 6):
            row["INCENTIVE_RATE"] = 0.0010
        elif(row["NO_OF_CASES"] <= 11):
            row["INCENTIVE_RATE"] = 0.0025
        elif(row["NO_OF_CASES"] <= 20):
            row["INCENTIVE_RATE"] = 0.0035
        else:
            row["INCENTIVE_RATE"] = 0.0050
        
        return row


    def grid2(self, row):
        broker = [263243, 287762, 287761, 287763, 287764, 287765, 287767, 287769, 287777, 287778, 287779, 287780, 287781, 287782, 287783, 287784, 287936, 287938, 287939, 287940, 287987, 292929, 292931]
        if(row["DMABROKERCODE"] in broker):
            row["INCENTIVE_RATE"] = 0.0
            
        return row


    def grid3(self, row):
        broker = [171659,194573,197846,183737,175552,207040,207946,208632,208859,212170,219020,237300,233542,247235,221664,271164,271690,284417,283995,285899,286991,289186,297632,272353]
            
        if((row["CONSOILIDATED_STATE"].lower() == "chennai") & (row["LAN_TYPE"] == "USED CAR")):
            if(row["Sourcing"] == "DSA"):
                if(row["DMABROKERCODE"] in broker):
                    if(row["NO_OF_CASES"] <= 3):
                        row["INCENTIVE_RATE"] = 0.0
                    elif(row["NO_OF_CASES"] <= 10):
                        row["INCENTIVE_RATE"] = 0.0010
                    else:
                        row["INCENTIVE_RATE"] = 0.0015
                    if(row["SC"].lower() == "topup") | (row["SC"].lower() == "inbt"):
                        row["INCENTIVE_RATE"] = 0
            
        return row


    def grid_kerala(self, row):
        if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
            # if(row["Sourcing"] in ["DDSA", "ADM", "MBO"]):
            if(row["checking"]==0):
                if(row["NO_OF_CASES"] <= 5):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 9):
                    row["PO_AMT"] = 500
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250
            if(row["checking"]==1):
                if(row["NO_OF_CASES"] <= 5):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 9):
                    row["PO_AMT"] = 400
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250    
            if(row["checking"]==2):
                if(row["NO_OF_CASES"] <= 4):
                    row["PO_AMT"] = 0
                elif(row["NO_OF_CASES"] <= 8):
                    row["PO_AMT"] = 500
                elif(row["NO_OF_CASES"] <= 14):
                    row["PO_AMT"] = 800
                elif(row["NO_OF_CASES"] <= 20):
                    row["PO_AMT"] = 1000
                else:
                    row["PO_AMT"] = 1250    
        return row

        
        return row
    def grid5(self, row):
        new_broker = [266338, 266450, 269302, 274328]
        used_broker = [266338, 266450, 269302, 275078]
        used_oc = 274328
        if((row["DMABROKERCODE"] in new_broker) | (row["DMABROKERCODE"] in used_broker) | (row["DMABROKERCODE"] == used_oc)):
            if(row["SC"].lower() == "topup"):
                row["INCENTIVE_RATE"] = 0.0
                row["PO_AMT"] = 0.0
                return row
                
        
        if(row["LAN_TYPE"] == "NEW CAR"):
            if(row["DMABROKERCODE"] in new_broker):
                row["INCENTIVE_RATE"] = 0.0
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
        else:
            if(row["DMABROKERCODE"] in used_broker):
                row["INCENTIVE_RATE"] = 0.0020
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
            elif(row["DMABROKERCODE"] == used_oc):
                row["INCENTIVE_RATE"] = 0.0010
                if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                    row["PO_AMT"] = round(row["INCENTIVE_RATE"] * row["REVISED AMOUNT FINANCE"],3)
                            
            
        def round_up(n,decimals=0):
            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
            
        row["PO_AMT"]=round_up(row["PO_AMT"])
                   
                
        return row

    def TWGrid(self, row):
        if((row["IS_TW"] == False)):
            if(row["INCENTIVE_RATE"] == 0.0007):
                row["INCENTIVE_RATE"] = 0.0005
            elif(row["INCENTIVE_RATE"] == 0.0011):
                row["INCENTIVE_RATE"] = 0.0008
            elif(row["INCENTIVE_RATE"] == 0.0015):
                row["INCENTIVE_RATE"] = 0.0010
            elif(row["INCENTIVE_RATE"] == 0.0025):
                row["INCENTIVE_RATE"] = 0.0020
            
            if(row["CONSOILIDATED_STATE"].lower() == "kerala"):
                row["PO_AMT"] -= 400
                
        return row
               
                
    def POCalculation(self):
        self.dma_df["PO_AMT"] = round(self.dma_df["INCENTIVE_RATE"] * self.dma_df["REVISED AMOUNT FINANCE"],3)
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["PO_AMT"]=round_up(row["PO_AMT"])
            return row        
        self.dma_df=self.dma_df.apply(lambda x:Round_off(x),axis=1)                
        # self.used_df["PO_AMT"] = self.used_df["INCENTIVE_RATE"] * self.used_df["REVISED AMOUNT FINANCE"]
        
        
    def POCappedAmt(self, row):
        row["CAPPING"] = 3000
        row["PO_CAPPED_AMT"] = min(row["PO_AMT"], row["CAPPING"])
        sum = (row["TOTAL_SALARY"] + row["PO_CAPPED_AMT"])
        row["PO_CAPPED_AMT"] = (row["PO_CAPPED_AMT"] - sum + 50000) if (sum > 50000) else row["PO_CAPPED_AMT"] 
        row["PO_CAPPED_AMT"] = max(row["PO_CAPPED_AMT"], 0)
        return row
    
    def POCappedAmt1(self, row):
        row["CAPPING"] = 3000
        row["PO_CAPPED_AMT"] = min(row["PO_AMT"], row["CAPPING"])
        sum = (row["TOTAL_SALARY"] + row["PO_CAPPED_AMT"])
        row["PO_CAPPED_AMT"] = (row["PO_CAPPED_AMT"] - sum + 65000) if (sum > 65000) else row["PO_CAPPED_AMT"] 
        row["PO_CAPPED_AMT"] = max(row["PO_CAPPED_AMT"], 0)
        return row
    
    def Merging(self):
        osp = self.Booster_tier["OSP code of Retainer/LME"].str.lower().tolist()
        osp1 = self.booster_top["OSP code of Retainer/LME"].str.lower().tolist()
        # print(len(osp))
        # print(len(osp1))
     
    
    
        
        # Rejected_=self.df[~(self.df["OSP_CODE"].str.lower().isin(osp))].copy()
        # Rejected_=pd.DataFrame(Rejected_)
      
        # Rejected_["Remark"]="NOT PRESENT PRESENT IN ATTENDANCE SHEET"
   
        # self.rejection=pd.concat([Rejected_,self.rejection],ignore_index=True)
       
        temp=self.dma_df[self.dma_df["OSP_CODE"].str.lower().isin(osp)]
        temp1=self.dma_df[self.dma_df["OSP_CODE"].str.lower().isin(osp1)]
        temp2=self.dma_df[~(self.dma_df["OSP_CODE"].str.lower().isin(osp))]
        temp3=self.dma_df[~(self.dma_df["OSP_CODE"].str.lower().isin(osp1))]
        temp2["REMARK"]="OSP_Code not present Tier"
        temp3["REMARK"]="OSP_code not present Top"
        self.rejection_df=pd.concat([self.rejection_df,temp2],ignore_index=True)
        self.rejection_df=pd.concat([self.rejection_df,temp3],ignore_index=True)
        
        # temp=temp.loc[(temp["OSP_CODE"].duplicated()==False)]
        # temp1=temp1.loc[(temp1["OSP_CODE"].duplicated()==False)]
        print(temp1.shape[0],"kiran")
        print(temp.shape[0],"kiran")
        temp["Top_Tier2_cases"]="tier2"
        temp1["Top_Tier2_cases"]="TOP"

        self.dma_df=pd.concat([temp,temp1],ignore_index=True)
        
        self.top=self.dma_df[(self.dma_df["Top_Tier2_cases"]=="TOP")]
        self.tier=self.dma_df[(self.dma_df["Top_Tier2_cases"]=="tier2")]
        
        temp3=self.dma_df[(self.dma_df["Top_Tier2_cases"]!="TOP")]
        temp2=self.dma_df[(self.dma_df["Top_Tier2_cases"]!="tier2")]
        temp2["REMARK"]="Other than Tier2 cases"
        temp3["REMARK"]="Other than Top cases"
        self.rejection_df=pd.concat([self.rejection_df,temp2],ignore_index=True)
        self.rejection_df=pd.concat([self.rejection_df,temp3],ignore_index=True)
        
        self.booster_top.rename(columns={"OSP code of Retainer/LME":"OSP_CODE"},inplace=True)
        self.Booster_tier.rename(columns={"OSP code of Retainer/LME":"OSP_CODE"},inplace=True)
        self.Booster_tier["OSP_CODE"]=self.Booster_tier["OSP_CODE"].str.upper()
        self.booster_top["OSP_CODE"]=self.booster_top["OSP_CODE"].str.upper()
        
        self.top=pd.merge(self.top,self.booster_top[["OSP_CODE","State","Name of Team Leader (TL)","I process Emp Code of TL"]],on="OSP_CODE",how="left")
        self.tier=pd.merge(self.tier,self.Booster_tier[["OSP_CODE","State","Name of Team Leader (TL)","I process Emp Code of TL"]],on="OSP_CODE",how="left")
        
    def Count(self):
        self.top["PO"]=0
        self.tier["PO"]=0
        # self.top["Count_of_emp_code"]=0
        # self.tier["Count_of_emp_code"]=0
        self.tier=self.tier.loc[(self.tier["AGREEMENTNO"].duplicated()==False)]
        self.top["Count_of_emp_code"]=self.top.groupby(["I process Emp Code of TL","LAN_TYPE"])["I process Emp Code of TL"].transform("count")
        self.tier["Count_of_emp_code"]=self.tier.groupby(["I process Emp Code of TL"])["I process Emp Code of TL"].transform("count")
        # grp=self.top.groupby(["I process Emp Code of TL"])
        # for code,gdf in grp:
        #     temp=gdf[(gdf["LAN_TYPE"]=="NEW CAR"),"Count_of_emp_code"]
        #     temp1=gdf[(gdf["LAN_TYPE"]=="USED CAR"),"Count_of_emp_code"]
        #     print(temp)
        #     print(temp1)
        #     # if temp>temp1:
        #     #     self.top["NEW/USED"]="NEW"
        #     # else:
        #     #     self.top["NEW/USED"]="OLD"  
        
        temp=self.top[(self.top["LAN_TYPE"]=="NEW CAR")] 
        temp1=self.top[(self.top["LAN_TYPE"]=="USED CAR")]
        temp["Count_of_emp_code_new"]=temp.groupby(["I process Emp Code of TL"])["I process Emp Code of TL"].transform("count")
        temp1["Count_of_emp_code_used"]=temp1.groupby(["I process Emp Code of TL"])["I process Emp Code of TL"].transform("count")        
        # temp=pd.merge(temp,temp1[["Count_of_emp_code_used"]],on="I process Emp Code of TL",how="left")
        # temp["Count_of_emp_code_used1"]=temp["Count_of_emp_code_used"]
        # self.top=pd.concat([temp,temp1],ignore_index=True)
        self.top=pd.merge(self.top,temp1[["I process Emp Code of TL","Count_of_emp_code_used"]],on="I process Emp Code of TL",how="left")
        self.top=pd.merge(self.top,temp[["I process Emp Code of TL","Count_of_emp_code_new"]],on="I process Emp Code of TL",how="left")
        self.top["Count_of_emp_code_used"].fillna(0,inplace=True)
        self.top["Count_of_emp_code_new"].fillna(0,inplace=True)
        self.top.loc[((self.top["Count_of_emp_code_new"])>(self.top["Count_of_emp_code_used"])),"NEW/USED"]="NEW"
        self.top.loc[((self.top["Count_of_emp_code_new"])<(self.top["Count_of_emp_code_used"])),"NEW/USED"]="OLD"
        self.I_Process_Active_2_df.rename(columns={"EmpCode":"I process Emp Code of TL"},inplace=True)
        self.top=pd.merge(self.top,self.I_Process_Active_2_df[["I process Emp Code of TL","I Process Gross salary"]],on="I process Emp Code of TL",how="left")
        self.tier=pd.merge(self.tier,self.I_Process_Active_2_df[["I process Emp Code of TL","I Process Gross salary"]],on="I process Emp Code of TL",how="left")
        self.tier["I Process Gross salary"].fillna(0,inplace=True)
        self.top["I Process Gross salary"].fillna(0,inplace=True)
        self.top=self.top.loc[(self.top["AGREEMENTNO"].duplicated()==False)]
        self.tier=self.tier.loc[(self.tier["AGREEMENTNO"].duplicated()==False)]
        self.rejection_df=self.rejection_df.loc[(self.rejection_df["AGREEMENTNO"].duplicated()==False)]
        # self.dma_df=self.dma_df.loc[self.dma_df["DMABROKERCODE"].duplicated()==False]
        self.top["Count_of_emp_code"]=self.top["Count_of_emp_code_used"]+self.top["Count_of_emp_code_new"]
        
    def ExtrationofdelhiCases(self):
        self.delhi=self.rejection_df.loc[(self.rejection_df["OSP_CODE"]=="IPRO005079F04915") | (self.rejection_df["OSP_CODE"]=="IPRO005079F02398")]
        print(self.delhi.shape[0])
        
    def Booster_Delhi(self):
        # self.delhi["Segment"]=""
        self.booster_Delhi.rename(columns={"OSP Code":"OSP_CODE"},inplace=True)
        self.delhi=pd.merge(self.delhi,self.booster_Delhi[["OSP_CODE","Emp Code"]],on="OSP_CODE",how="left")
        
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047349823"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047302859"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047268665"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047358550"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047364402"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047296025"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047383203"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047289371"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047351367"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047313345"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047358261"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047306916"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047367086"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047392374"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047383387"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047295573"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047261644"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047296677"),"Segment"]="B+"
        # # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047296677"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047369844"),"Segment"]="B+"
        # # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047296677"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047333495"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LAGHZ00047268720"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LANOD00047307155"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LUDEL00047296736"),"Segment"]="A+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047375303"),"Segment"]="B+"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047281182"),"Segment"]="A"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047306851"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047124948"),"Segment"]="C"
        # self.delhi.loc[(self.delhi["AGREEMENTNO"]=="LADEL00047124948"),"Segment"]="C"
    
    def booster_Delhi_segment(self):
        self.delhi["PO rate"]=0.0015
        self.delhi.loc[(self.delhi["Segment"]=="A+") | (self.delhi["Segment"]=="A"),"PO rate"]=0.0007
        self.delhi["Segment"].fillna(0,inplace=True)
        self.delhi.loc[(self.delhi["Segment"]==0),"PO rate"]=0
    def booster_Delhi_grid1(self):
        self.delhi["Payout"]=0
        self.delhi["Net_Loan"]=self.delhi["AMTFIN"]-self.delhi["ADVANCE_EMI"]
        self.delhi["Payout"]=self.delhi["PO rate"]*self.delhi["Net_Loan"]
        def Round_off(row:pd.DataFrame):
            
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            
            row["Payout"]=round_up(row["Payout"])
            return row        
        self.delhi=self.delhi.apply(lambda x:Round_off(x),axis=1)
        self.delhi["Capping"]=3000
        self.delhi["Payout_after_Capping"]=0
        self.delhi.loc[(self.delhi["Payout"]>3000),"Payout_after_Capping"]=3000
        self.delhi.loc[(self.delhi["Payout"]<3000),"Payout_after_Capping"]=self.delhi["Payout"] 
        self.delhi=self.delhi.drop(["Asset Insurance charge ID- 500080","Asset Insurance PO ","CONSOILIDATED_STATE","TOTAL_SALARY","Designation","Top/ Tier II","No of day","PROCESS_FLAG","Sourcing","LAN_TYPE","flag","remark1","BOUND_INBOUND","REVISED AMOUNT FINANCE","SUM_OF_AMTFIN","IS_TW","Auto Secure","NO_OF_CASES","INCENTIVE_RATE","PO_AMT","checking","Top_Tier2_cases"],axis=1)             
        
        
        
    def Booster_top_grid(self):
        
        self.top.loc[(self.top["NEW/USED"]=="NEW")& (self.top["Count_of_emp_code"]>=41),"PO"]=600
        self.top.loc[(self.top["NEW/USED"]=="NEW")& (self.top["Count_of_emp_code"]>=50),"PO"]=650
        self.top.loc[(self.top["NEW/USED"]=="NEW")& (self.top["Count_of_emp_code"]>=60),"PO"]=700
        self.top.loc[(self.top["NEW/USED"]=="NEW")& (self.top["Count_of_emp_code"]>=70),"PO"]=750

        self.top.loc[(self.top["NEW/USED"]=="OLD")& (self.top["Count_of_emp_code"]>=21),"PO"]=700
        self.top.loc[(self.top["NEW/USED"]=="OLD")& (self.top["Count_of_emp_code"]>=40),"PO"]=750
        self.top.loc[(self.top["NEW/USED"]=="OLD")& (self.top["Count_of_emp_code"]>=50),"PO"]=800
        
        
        
    def Booster_tier_grid(self):
        self.tier.loc[(self.tier["Count_of_emp_code"]<15),"PO"]=0
        self.tier.loc[(self.tier["Count_of_emp_code"]>=16),"PO"]=500
        self.tier.loc[(self.tier["Count_of_emp_code"]>=30),"PO"]=500
        self.tier.loc[(self.tier["Count_of_emp_code"]>=40),"PO"]=750
        self.tier.loc[(self.tier["Count_of_emp_code"]>=50),"PO"]=750
        
        # self.top.loc[(self.top["NEW/USED"]=="OLD")& (self.top["Count_of_emp_code"]>=70),"PO"]=750     
    # def Booster_tier2_grid(row:pd.DataFrame):
                
    #         if (row["Count_of_emp_code"]<16):
    #             row["PO"]=0
    #         elif (row["Count_of_emp_code"]<30):
    #             row["PO"]=500
    #         elif (row["Count_of_emp_code"]<40):
    #             row["PO"]=500
    #         elif (row["Count_of_emp_code"]<50):
    #             row["PO"]=750
    #         else:
    #             row["PO"]=750
        
        
    
        
    def Caluation(self):
        self.top["Payout"]=0
        self.top["Revised Count"]=0
        # self.tier["Payout"]=0
        # self.tier["Payout"]=self.tier["Count_of_emp_code"]*self.tier["PO"]
        self.top.loc[(self.top["NEW/USED"]=="NEW"),"Revised Count"]=self.top["Count_of_emp_code"]-40
        self.top.loc[(self.top["NEW/USED"]=="OLD"),"Revised Count"]=self.top["Count_of_emp_code"]-20
        self.top["Payout"]=self.top["Revised Count"]*self.top["PO"]
        self.top["Payout"]=self.top["Revised Count"]*self.top["PO"]
        self.top["PO+Salary"]=0
        self.top["PO+Salary"]=self.top["Payout"]+self.top["I Process Gross salary"]
        self.top["Capping"]=35000
        self.top.loc[(self.top["PO+Salary"])>(self.top["Capping"]),"Final Payout"]=self.top["Capping"]-self.top["I Process Gross salary"]
        self.top.loc[(self.top["PO+Salary"])<(self.top["Capping"]),"Final Payout"]=self.top["Payout"]
    
    def Calculation_Tier(self):
        self.tier["Payout"]=0
        self.tier["Payout"]=self.tier["Count_of_emp_code"]*self.tier["PO"]
        self.tier["PO+Salary"]=0
        self.tier["PO+Salary"]=self.tier["Payout"]+self.tier["I Process Gross salary"]
        self.tier["Capping"]=45000
        self.tier.loc[(self.tier["State"].str.lower().str.contains("kerala")),"Capping"]=65000
        self.tier.loc[(self.tier["PO+Salary"])>(self.tier["Capping"]),"Final Payout"]=self.tier["Capping"]-self.tier["I Process Gross salary"]
        self.tier.loc[(self.tier["PO+Salary"])<(self.tier["Capping"]),"Final Payout"]=self.tier["Payout"] 
        
            
                
               
        
    def execute(self):
        # self.SeparateDFs_CasesCalc()
        
        # self.dma_df = self.dma_df.apply(lambda row : self.grid1_mixed(row), axis=1)
        # self.used_df = self.used_df.apply(lambda row : self.grid1_used(row), axis=1)
        
        # self.dma_df = pd.concat([self.dma_df, self.used_df], ignore_index=True)
        
        # self.dma_df = self.dma_df.apply(lambda row : self.grid2(row), axis=1)
        # # self.used_df = self.used_df.apply(lambda row : self.grid2(row), axis=1)
        
        # self.dma_df = self.dma_df.apply(lambda row : self.grid3(row), axis=1)
        # # self.used_df = self.used_df.apply(lambda row : self.grid3(row), axis=1)
        
        # self.dma_df = self.dma_df.apply(lambda row : self.grid5(row), axis=1)
        # self.dma_df = self.dma_df.apply(lambda row: self.TWGrid(row), axis=1)
        # # self.used_df = self.used_df.apply(lambda row : self.grid5(row), axis=1)
        
        # self.POCalculation()

        # temp=self.kerala_df.groupby("OSP_CODE")
        # p=[]
        # u=[]
        # for code,grf in temp:
            
        #     k=grf.loc[grf["LAN_TYPE"]=="NEW CAR"].shape[0]
        #     if (k==grf.shape[0]):
        #         p.append(code)
        #     k=grf.loc[grf["LAN_TYPE"]=="USED CAR"].shape[0]
        #     if (k==grf.shape[0]):
        #         u.append(code)
                
        
        # self.kerala_df.loc[self.kerala_df["OSP_CODE"].isin(p),"checking"]=1     
        # self.kerala_df.loc[self.kerala_df["OSP_CODE"].isin(u),"checking"]=2    
        
        
        # self.kerala_df = self.kerala_df.apply(lambda row : self.grid_kerala(row), axis=1)
        # self.kerala_df = self.kerala_df.apply(lambda row : self.grid5(row), axis=1)
        # self.kerala_df = self.kerala_df.apply(lambda row: self.TWGrid(row), axis=1)    
        # self.dma_df = self.dma_df.apply(lambda row : self.POCappedAmt(row), axis=1)
        # # self.used_df = self.used_df.apply(lambda row : self.POCappedAmt(row), axis=1)
        # self.kerala_df = self.kerala_df.apply(lambda row : self.POCappedAmt1(row), axis=1)
        # # self.dma_df.loc[self.dma_df["DMABROKERCODE"].isin([266338,266450,269302,275078,274328]),"PO_AMT"]=0
        # self.dma_df=self.dma_df.drop(["checking"],axis=1)
        # self.Booster()
        self.Merging()
        self.Count()
        self.Booster_top_grid()
        self.Booster_tier_grid()
        self.Caluation()
        self.Calculation_Tier()
        self.ExtrationofdelhiCases()
        self.Booster_Delhi()
        self.booster_Delhi_segment()
        self.booster_Delhi_grid1()
        # self.top = self.top.apply(lambda x: Booster_top_grid(x), axis=1)
        # self.tier = self.top.apply(lambda x: Booster_tier2_grid(x), axis=1)
        # self.top=self.top.apply(lambda x:Booster_top_grid(x),axis=1)
        
        
    # def Booster_top_grid(row:pd.DataFrame):
    #     if (row["NEW/USED"]=="NEW"):
    #         if (row["Count_of_emp_code"]<41):
    #             row["PO"]=0
    #         elif (row["Count_of_emp_code"]<50):
    #             row["PO"]=600
    #         elif (row["Count_of_emp_code"]<60):
    #             row["PO"]=650
    #         elif (row["Count_of_emp_code"]<70):
    #             row["PO"]=700
    #         else:
    #             row["PO"]=750
            
        
    #     if (row["NEW/USED"]=="OLD"):
    #         if (row["Count_of_emp_code"]<21):
    #             row["PO"]=0
    #         elif (row["Count_of_emp_code"]<40):
    #             row["PO"]=700
    #         elif (row["Count_of_emp_code"]<50):
    #             row["PO"]=750

    #         else:
    #             row["PO"]=800
    #     return row
    
    
    # def Booster_tier2_grid(row:pd.DataFrame):
                
    #         if (row["Count_of_emp_code"]<16):
    #             row["PO"]=0
    #         elif (row["Count_of_emp_code"]<30):
    #             row["PO"]=500
    #         elif (row["Count_of_emp_code"]<40):
    #             row["PO"]=500
    #         elif (row["Count_of_emp_code"]<50):
    #             row["PO"]=750
    #         else:
    #             row["PO"]=750