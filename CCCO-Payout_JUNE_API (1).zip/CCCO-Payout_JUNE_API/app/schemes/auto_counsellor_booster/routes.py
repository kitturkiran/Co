from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .data_massaging import DataMassaging
from .data_massaging1 import DataMassaging1
from .data_calculation import DataCalculation
from .po_summary import generateSummary,generateSummary1,generateSummary2
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil

auto_couns_booster_router = APIRouter()

@auto_couns_booster_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def auto_couns_payout_calculation(dma: UploadFile, 
                                        process_active: UploadFile,
                                        tagging:UploadFile,
                                        master: UploadFile,
                                        auto_secure: UploadFile,
                                        tw: UploadFile,
                                        DMA_Path1: UploadFile, 
                                        process_active1: UploadFile,
                                        master1: UploadFile,
                                        auto_secure1: UploadFile,
                                        tw1:UploadFile,
                                        booster:UploadFile,
                                        start_date: str = Body(...),
                                        end_date: str = Body(...), 
                                        bg_task: BackgroundTasks = None):
        
    dma_df = pd.read_excel(dma.file.read())
    dma_df["OSP_CODE"] = dma_df["OSP_CODE"].str.upper()
    
    process_active_file = process_active.file.read()
    I_Process_Active_df = pd.read_excel(process_active_file, sheet_name=0)
    
    I_Process_Active_df = I_Process_Active_df[["VSTS Code / Counselor SAP Code", "State", "I Process Gross salary", "Designation", "Top/ Tier II", "No of day"]]
    # Rename VSTS Code / Counselor SAP Code
    I_Process_Active_df.rename(columns={"VSTS Code / Counselor SAP Code":"OSP_CODE"}, inplace=True)
    I_Process_Active_df["OSP_CODE"] = I_Process_Active_df["OSP_CODE"].str.upper()
    
    tagging = tagging.file.read()

    tagging_cols =["DMABROKERCODE", "Sourcing", "AGREEMENTNO","Segment","Asset Insurance charge ID- 500080", "Asset Insurance PO "]
    tagging_df = pd.concat([pd.read_excel(tagging, sheet_name=1, usecols=tagging_cols),
                            pd.read_excel(tagging, sheet_name=2, usecols=tagging_cols),
                            pd.read_excel(tagging, sheet_name=3, usecols=tagging_cols)],
                            ignore_index=True
                            )
    master_df = pd.read_excel(master.file.read(), usecols=["Aps Code", "Sourcing"])
    master_df.rename(columns={"Aps Code":"DMABROKERCODE"}, inplace=True)
    master_df.drop_duplicates(subset=["DMABROKERCODE"], keep="first", inplace=True)
    tw_df = pd.read_excel(tw.file.read(), usecols=["OSP_CODE"])
    auto_secure =pd.read_excel(auto_secure.file.read())
    # auto_secure.rename(columns={"Asset Insurance charge ID- 500080":"AMT"},inplace=True)
    
    
    #files of manipal.
    dma_df1 = pd.read_excel(DMA_Path1.file.read())
    dma_df1["OSP_CODE"] = dma_df1["OSP_CODE"].str.upper()
    
    I_Process_Active_df1 = pd.read_excel(process_active1.file.read())
    I_Process_Active_df1 = I_Process_Active_df1[["VSTS Code / Counselor SAP Code", "Consoilidated State", "Manipal Gross salary", "Designation", "Top/ Tier II", "No of day"]]
    # Rename VSTS Code / Counselor SAP Code
    I_Process_Active_df1.rename(columns={"VSTS Code / Counselor SAP Code":"OSP_CODE"}, inplace=True)
    I_Process_Active_df1["OSP_CODE"] = I_Process_Active_df1["OSP_CODE"].str.upper()
    tw1=pd.read_excel(tw1.file.read())
    
    
    
    master_df1 = pd.read_excel(master1.file.read())
    master_df1 = master_df1[["Aps Code", "Sourcing"]]
    #Rename Aps Code
    master_df1.rename(columns={"Aps Code":"DMABROKERCODE"}, inplace=True)
        
    auto_secure1 =pd.read_excel(auto_secure1.file.read())
    
    
    
    
    booster=booster.file.read()
    booster_tier2=pd.read_excel(booster,sheet_name="TierII Mapping")
    booster_top=pd.read_excel(booster,sheet_name="TOP MAPPING")
    booster_Delhi=pd.read_excel(booster,sheet_name="Delhi Mapping")
    I_Process_Active_2_df = pd.read_excel(process_active_file, sheet_name="Sales Team Leader")
    try:
        rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        rejected_df1 = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])
        print("massaging started")
        obj1 = DataMassaging(dma_df, I_Process_Active_df, master_df, rejected_df, tagging_df, tw_df,auto_secure,start_date, end_date)
        obj1.execute()
        print("massaging started1")
        obj2 = DataMassaging1(dma_df1, I_Process_Active_df1, master_df1, rejected_df1,tw1,tagging_df,start_date, end_date)
        obj2.execute1()
        print("massasging completerd")
        M1=obj1.dma_df
        M2=obj2.dma_df
        R1=obj1.rejection_df
        R2=obj2.rejection_df
        
        obj3=pd.concat([M1,M2],ignore_index=True)
        obj4=pd.concat([R1,R2],ignore_index=True)
        
        obj2 = DataCalculation(obj3,booster_tier2,booster_top,I_Process_Active_2_df,obj4,booster_Delhi)
        obj2.execute()
        print("end of Calculation")

        summary_df = generateSummary(obj2.top)
        summary_df1 = generateSummary1(obj2.tier)
        summary_df2 = generateSummary2(obj2.delhi)
        
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    
    file_name = f"auto_counsellor_booster_output_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"


    
    with pd.ExcelWriter(f"{file_path}") as writer:
        obj2.top.to_excel(writer, sheet_name="Top", index=False)
        obj2.tier.to_excel(writer, sheet_name="Tier", index=False)
        obj2.delhi.to_excel(writer, sheet_name="Delhi", index=False)
        summary_df.to_excel(writer, sheet_name="SUMMARY_top", index=False)
        summary_df1.to_excel(writer, sheet_name="SUMMARY_teir", index=False)
        summary_df2.to_excel(writer, sheet_name="SUMMARY_Delhi", index=False)
    
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)


@auto_couns_booster_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/auto_counsellor_booster"
    destination_dir = f"./backup/AUTO_COUNSELLOR_BOOSTER/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"