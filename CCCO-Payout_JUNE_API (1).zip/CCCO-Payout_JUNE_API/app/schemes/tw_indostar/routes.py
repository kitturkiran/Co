from fastapi import APIRouter, UploadFile, Depends, HTTPException, Body
from ...auth.auth_bearer import JWTBearer
from fastapi.responses import FileResponse
import pandas as pd
from .datacalculaion import Calculation
from .datamassaging import Massaging
# from .po_summary import generateSummary
# from .po_summary import generateSummary1
from datetime import datetime
from fastapi.background import BackgroundTasks
import os
import shutil

tw_indostar_router = APIRouter()
print("hello")
@tw_indostar_router.post("/calculate-payout", dependencies=[Depends(JWTBearer())])
async def tw_indostar_calculation(dma: UploadFile,
                                  additional_rate:UploadFile,
                                   
                                   
                                   start_date: str = Body(...),
                                   end_date: str = Body(...), 
                                   bg_task: BackgroundTasks = None):
        
    print("starting")
    dma_df = pd.read_excel(dma.file.read())
    additional_rate=pd.read_excel(additional_rate.file.read())
    
    try:
        rejection=pd.DataFrame()

        obj=Massaging(dma_df,rejection,start_date,end_date)
        obj.execute()
        obj1=Calculation(obj.df,additional_rate)
        obj1.Execute()
        
        # summary_df = generateSummary(dc_obj.df)
        # summary_df1 = generateSummary1(dc_obj.df)
        
    except KeyError as missing_key:
        raise HTTPException(status_code=422, detail={"Missing Key": f"{missing_key.args[0]}"})
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    
    file_name = f"tw_IndoStar_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.xlsx"
    file_path = f"./app/output_files/{file_name}"
    
    with pd.ExcelWriter(f"{file_path}") as writer:
        obj1.cf.to_excel(writer, sheet_name="TW-IndoStar", index=False)
        # dc_obj.with_connector.to_excel(writer, sheet_name="CV-CE-DMA_with_connector-Pay-Cases", index=False)
        
        obj.rejection.to_excel(writer, sheet_name="TW-IndoStart_Rejected", index=False)
        # summary_df.to_excel(writer, sheet_name="Summary_without_connector", index=False)
        # summary_df1.to_excel(writer, sheet_name="Summary_with_connector", index=False)
        
    bg_task.add_task(os.remove, file_path)
    
    return FileResponse(file_path, filename=file_name, background=bg_task)


@tw_indostar_router.post("/save-scheme", dependencies=[Depends(JWTBearer())])
async def save_scheme():
    today = datetime.now()
    cur_month = today.strftime("%B")
    
    source_dir = "./app/schemes/tw_indostar"
    destination_dir = f"./backup/TW_INDOSTAR/{cur_month}"
    
    if(os.path.exists(destination_dir)):
        shutil.rmtree(destination_dir)
    
    shutil.copytree(source_dir, destination_dir)
    
    return "Scheme Saved Successfully"