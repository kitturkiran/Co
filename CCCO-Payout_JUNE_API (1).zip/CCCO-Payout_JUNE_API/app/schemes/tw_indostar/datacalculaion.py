from datetime import datetime
import math
import pandas as pd
class Calculation:
    def __init__(self,calculator,additional):
        self.cf=calculator
        self.additional=additional

    def add_structure(self):
        self.cf["DISBURSEMENT_MONTH Check"]=0
        self.cf["Gross PF"]=0
        self.cf["Base PF"]=0
        self.cf["GST"]=0
        self.cf["Capping"]=0
        self.cf["Final Base"]=0
        self.cf["OD for PO Calculation"]=0
        self.cf["Base OD"]=0
        self.cf["GST OD"]=0
        
        
        
    def Pfpo(self):

        # self.cf.loc{self.cf["DATE_OF_REPORT"]}
        startdate=datetime.strptime("1-03-2023","%d-%m-%Y")
        enddate=datetime.strptime("31-03-2023","%d-%m-%Y")
        self.cf["DISBURSEMENT_MONTH"]=pd.to_datetime(self.cf["DISBURSEMENT_MONTH"])
        self.cf.loc[(self.cf["DISBURSEMENT_MONTH"]>=startdate)&(self.cf["DISBURSEMENT_MONTH"]<=enddate),"DISBURSEMENT_MONTH Check"]=1
        self.cf["Gross PF"]=round(((self.cf["PROCESSING_FEES"]/118)*100),2)
        self.cf["Base PF"]=round(((self.cf["Gross PF"]/118)*100),2)
        self.cf["GST"]=round((self.cf["Gross PF"]-self.cf["Base PF"]),2)
        self.cf["Capping"]=round((self.cf["DISBURSEDAMOUNT"]*0.0125),2)
        self.cf["Final Base"]=self.cf["Base PF"]
        self.cf.loc[self.cf["Base PF"]>self.cf["Capping"],"Final Base"]=self.cf["Capping"]
        self.cf.loc[self.cf["DISBURSEMENT_MONTH Check"]==0,"Gross PF"]=0
        self.cf.loc[self.cf["DISBURSEMENT_MONTH Check"]==0,"Base PF"]=0
        self.cf.loc[self.cf["DISBURSEMENT_MONTH Check"]==0,"GST"]=0
        self.cf.loc[self.cf["DISBURSEMENT_MONTH Check"]==0,"Final Base"]=0
    
    def  odpo(self):
        self.cf["OD for PO Calculation"]=round(((self.cf["CHARGES_COLLECTION_OD"]/118)*100),2)
        self.cf["Base OD"]=round(((self.cf["OD for PO Calculation"]/118)*100),2)
        self.cf["GST OD"]=self.cf["OD for PO Calculation"]-self.cf["Base OD"]
        
    
    def Interestpo(self):
        self.cf["Interest accrued for a month"]=self.cf["BILLED_INT_DURING_MONTH"]
        self.cf["Customer rate"]=(self.cf["ROI_CHARGED_TO_CUSTOMER"])
        date=datetime.strptime("1-04-2021","%d-%m-%Y")
        self.cf["Retention Rate"]=10.40
        self.cf.loc[(self.cf["DISBURSEMENT_MONTH"]>=date),"Retention Rate"]=8.6
        self.cf=pd.merge(self.cf,self.additional[["ICICI_LAN","PARTNERS_LAN"]],how="left",on="ICICI_LAN")
        self.cf.loc[(self.cf["PARTNERS_LAN_y"]=="0.50% more on retention rate"),"Retention Rate"]=self.cf["Retention Rate"]+0.5
        self.cf["Incen􀆟ve payable to Indostar"]=(self.cf["Interest accrued for a month"]*(1-(self.cf["Retention Rate"]/self.cf["Customer rate"])))
        self.cf.loc[self.cf["Interest accrued for a month"]==0,"Incen􀆟ve payable to Indostar"]=0
        self.cf.loc[self.cf["Incen􀆟ve payable to Indostar"]<0,"Incen􀆟ve payable to Indostar"]=0
        self.cf.drop(columns="PARTNERS_LAN_y",inplace=True)
        
        def Round_off(row:pd.DataFrame):
                
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            row["Incen􀆟ve payable to Indostar"]=round(row["Incen􀆟ve payable to Indostar"],2)
            # row["Incen􀆟ve payable to Indostar"]=round_up(row["Incen􀆟ve payable to Indostar"],2)
            return row        
        self.cf=self.cf.apply(lambda x:Round_off(x),axis=1)   
        

        
    def Execute(self):
        self.add_structure()
        self.Pfpo()
        self.odpo()
        self.Interestpo()