import pandas as pd
from datamassaging import Massaging
from datacalculaion import Calculation

df=pd.read_excel(r"D:\schema _scource code1\Tw_indostar\input_file\Dump.xlsx")
additional=pd.read_excel(r"D:\schema _scource code1\cv_indostar\input_file\LAN Confirmed.xlsx")
rejection=pd.DataFrame()

obj=Massaging(df,rejection)
obj.execute()
obj1=Calculation(obj.df,additional)
obj1.Execute()

obj1.cf.to_excel("output.xlsx",index=False)
obj.rejection.to_excel("rejection.xlsx",index=False)

















