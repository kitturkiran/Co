from datetime import datetime
import pandas as pd

class DataMassaging:
    def __init__(self, df:pd.DataFrame, rejection_df:pd.DataFrame,tagging_df:pd.DataFrame, start_date,end_date):
        self.dma_df = df
        self.rejection_df = rejection_df
        self.startDate = start_date
        self.endDate = end_date
        self.tagging_df=tagging_df


    def NewAndRefinanace(self):
        temp = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LD") == False) & (self.dma_df["AGREEMENTNO"].str.startswith("UD") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "LAN not as per Process note"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[(self.dma_df["AGREEMENTNO"].str.startswith("LD") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UD") == True)]

        self.dma_df["NEW/REFINANCE_OP"] = ""
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("LD") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("LQ") == True), "NEW/REFINANCE_OP"] = "NEW"
        self.dma_df.loc[(self.dma_df["AGREEMENTNO"].str.startswith("UD") == True) | (self.dma_df["AGREEMENTNO"].str.startswith("UQ") == True), "NEW/REFINANCE_OP"] = "REFINANCE"

    def RemoveOtherThanA(self):
        temp = self.dma_df[self.dma_df["STATUS"] != 'A'].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Status Other Than A"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["STATUS"] == 'A']

    def RemoveValuesWithBranch_Direct(self):
        temp = self.dma_df[(self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "DMA Name Contains BRANCH, DIRECT, MAGMA"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((self.dma_df["DMA_NAME"].str.lower().str.contains("branch")) | (self.dma_df["DMA_NAME"].str.lower().str.startswith("direct") == True))]

    def RemoveFromPromotionDescription(self):
        temp = self.dma_df[self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Promotion desc with values death of app / nabard subsidy"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(self.dma_df["PROMOTIONDESC"].str.lower().str.contains("death of app") | self.dma_df["DMA_NAME"].str.lower().str.contains("death of co app") | self.dma_df["DMA_NAME"].str.lower().str.contains("nabard subsidy"))]

    def RemoveBasedOnTenure(self):
        temp = self.dma_df[((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18))].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "New Car Tenure <= 24/Refinance CV CE <= 18"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~(((self.dma_df["NEW/REFINANCE_OP"] == "NEW") & (self.dma_df["TENURE"] < 24)) | ((self.dma_df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.dma_df["TENURE"] < 18)))]
        
    def RemoveOutsidePeriod(self):
        self.dma_df["DISBURSALDATE"] = pd.to_datetime(self.dma_df["DISBURSALDATE"])
        temp = self.dma_df[(((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False)].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Outside the Period of Calculation"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[~((((self.dma_df["DISBURSALDATE"] > self.endDate) == True) | ((self.dma_df["DISBURSALDATE"] < self.startDate) == True)) & (self.dma_df["PROMOTIONDESC"].str.lower().str.contains("credit days") == False))]

    def RBKCases(self):
        temp = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "File No. Contain RBK"
        self.rejection_df = pd.concat([self.rejection_df, temp], ignore_index=True)
        self.dma_df = self.dma_df[self.dma_df["FILENO"].str.lower().str.contains("rbk") == False]
        self.tagging_df = self.tagging_df[["DMA_BROKER_ID", "Category", "DMA/DIRECT/ BRANCH/ CONNECTOR/ DDSA", "State as per CB Product","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)","CV / CE"]]
        self.dma_df = pd.merge(self.dma_df, self.tagging_df, on="DMA_BROKER_ID",how="left")
        self.dma_df["VOL_LOAN_AMT"] = self.dma_df["AMTFIN"] - self.dma_df["ADVANCE_EMI"]
        self.dma_df=self.dma_df.loc[(self.dma_df["AGREEMENTNO"].duplicated()==False)]
    def Add_structure(self):
        pass
        # self.dma_df["PF"]=0
        # self.dma_df["0.25% of loan"]=0
        # self.dma_df["balance_amount"]=0
        # self.dma_df["PO"]=0
        # self.dma_df["NON_PSL_Percentage"]=0
        # self.dma_df["NON_PSL_VALUE"]=0
        # self.dma_df["Final Payout"]=0
    
    
    def execute(self):
        self.NewAndRefinanace()
        self.RemoveOtherThanA()
        self.RemoveValuesWithBranch_Direct()
        self.RemoveFromPromotionDescription()
        self.RemoveBasedOnTenure()
        self.RemoveOutsidePeriod()
        self.RBKCases()
        self.Add_structure()
        