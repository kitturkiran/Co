import os
import pandas as pd
from data_calculation import DataCalculation
from po_summary import generateSummary,generateSummary1 
from data_massaging import DataMassaging



dma_df = pd.read_excel(r"D:\schema _scource code1\CV consellor\scheme _4_April 2023\Input_File\ME PO Dump.xlsx")
tagging_df=pd.read_excel(r"D:\schema _scource code1\CV consellor\scheme _4_April 2023\Input_File\CV CE Input Sheet.xlsx")

rejected_df = pd.DataFrame(columns=["AGREEMENTNO", "REMARK"])

obj1 = DataMassaging(dma_df, rejected_df,tagging_df,"1-05-2023","31-05-2023")
obj1.execute()

data_calculation1 = DataCalculation(obj1.dma_df,tagging_df,obj1.rejection_df)
data_calculation1.execute()

data_calculation1.rejected_df.to_excel("Rejected_CV_CE_ME_MAY2023.xlsx",index=False)
data_calculation1.df.to_excel("output_CV_ME_MAY2023.xlsx",index=False)
# data_calculation1.without_connector.to_excel("output_without connetor_cases.xlsx")
summary_df = generateSummary(data_calculation1.df)
summary_df.to_excel("summary_CV_ME_MAY2023.xlsx",index=False)
# summary_df1 = generateSummary1(data_calculation1.df)
# summary_df1.to_excel("summary_with_connector.xlsx")
