import pandas as pd
import numpy as np
import math
class DataCalculation:
    def __init__(self, df:pd.DataFrame, tagging_df: pd.DataFrame, rejected_df:pd.DataFrame):
        self.df = df
        self.tagging_df = tagging_df
        self.rejected_df = rejected_df
        self.with_connector=None
        self.without_connector=None
        

    def AddColumnBasedOnPromotionDesc(self):
        self.df["Strategic/FTU/Retail_OP"] = "NA"
        self.df.loc[((self.df["PROMOTIONDESC"].str.lower().str.contains("strategic") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("str") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("stg") == True)), "Strategic/FTU/Retail_OP"] = "STRATEGIC"
      
        condition = ((self.df["PROMOTIONDESC"].str.lower().str.contains("ftu") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("ftb") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("first time user") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("first time buyer") == True) | (self.df["PROMOTIONDESC"].str.lower().str.contains("first") == True))
        self.df.loc[condition, "Strategic/FTU/Retail_OP"] = "FTU"
        
        self.df.loc[(self.df["Strategic/FTU/Retail_OP"] == "NA"), "Strategic/FTU/Retail_OP"] = "RETAIL"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093438"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093393"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093383"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093387"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093333"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093317"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093346"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093341"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093367"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093327"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        self.df.loc[(self.df["AGREEMENTNO"]=="LQJMR00047093434"),"Strategic/FTU/Retail_OP"]="STRATEGIC"
        
        
      
           
    def Initialization(self):

        self.tagging_df = self.tagging_df[["AGREEMENTNO", "Chassis / Body / CE", "Category", "DSA/ Direct/ Connector", "State as per CB Product", "Novation Scheme Code", "Equipment","From  STATE ( From LOCATIONS - DSA I BOX DETAILS) state","To State ( Business Branch Location Captured)","CV / CE"]]
        self.df = pd.merge(self.df, self.tagging_df, on="AGREEMENTNO")

        self.df["LOAN_AMT"] = round(self.df["AMTFIN"] - self.df["ADVANCE_EMI"],3)
        
        self.df["VOL_LOAN_AMT"] = round(self.df["AMTFIN"] - self.df["ADVANCE_EMI"],3)

        self.df["IRR"] = self.df["IRR"].round(2)
        
        self.df["BODY/TOPUP"] = ""
        
        self.df["MIN_LOGIN_RATE"] = 0.0
        
        self.df["LAN_WISE_RATE"] = 0.0
        
        self.df["LAN_PAYOUT"] = 0.0

        self.df["Total_Disbursement_Amount"] = 0

        self.df["VOL_WISE_RATE"] = 0.0

        self.df["VOL_PAYOUT"] = 0.0
        
        self.df["STRATEGIC_NEW_LAN_PO"] = 0.0
        
        self.df["RETAIL_NEW_LAN_PO"] = 0.0
        
        self.df["FTU_NEW_LAN_PO"] = 0.0
        
        self.df["STRATEGIC_REFINANCE_LAN_PO"] = 0.0
        
        self.df["RETAIL_REFINANCE_LAN_PO"] = 0.0
        
        self.df["FTU_REFINANCE_LAN_PO"] = 0.0
        
        self.df["STRATEGIC_VOL_PO"] = 0.0
        
        self.df["RETAIL_VOL_PO"] = 0.0
        
        self.df["FTU_VOL_PO"] = 0.0


        self.df["No_Of_Units"] = 0

        self.df["Asset_PO"] = 0
        self.df["CONNECTOR PO"] = 0.0
        self.df["PAYOUT"] = 0.0
        self.df["NON_PSL_Percentage"] = 0

        self.df["NON_PSL_VALUE"] = 0
        self.df["Final Payout"] = 0.0

    def SetMinLoginRate(self):
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "NEW") & (self.df["Strategic/FTU/Retail_OP"] == "STRATEGIC")), "MIN_LOGIN_RATE"] = 0.096
        
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "NEW") & (self.df["Strategic/FTU/Retail_OP"] == "RETAIL")), "MIN_LOGIN_RATE"] = 0.1035
        
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "NEW") & (self.df["Strategic/FTU/Retail_OP"] == "FTU")), "MIN_LOGIN_RATE"] = 0.1335
        
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.df["Strategic/FTU/Retail_OP"] == "STRATEGIC")), "MIN_LOGIN_RATE"] = 0.106
        
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.df["Strategic/FTU/Retail_OP"] == "RETAIL")), "MIN_LOGIN_RATE"] = 0.1135
        
        self.df.loc[((self.df["NEW/REFINANCE_OP"] == "REFINANCE") & (self.df["Strategic/FTU/Retail_OP"] == "FTU")), "MIN_LOGIN_RATE"] = 0.1435
        
    def SetNoOfUnits(self):
        self.df["Equipment"].fillna("-", inplace=True)
        grp = self.df.groupby("OSP_CODE")

        for code, gdf in grp:
            bhl = gdf[gdf["Equipment"] == "BHL"].shape[0]
            Excavator = gdf[gdf["Equipment"] == "Excavator"].shape[0]
            mobile_crane = gdf[gdf["Equipment"] == "Mobile Crane"].shape[0]
            self.df.loc[((self.df["OSP_CODE"] == code) & (self.df["Equipment"] == "BHL")), "No_Of_Units"] = bhl
            self.df.loc[((self.df["OSP_CODE"] == code) & (self.df["Equipment"] == "Excavator")), "No_Of_Units"] = Excavator
            self.df.loc[((self.df["OSP_CODE"] == code) & (self.df["Equipment"] == "Mobile Crane")), "No_Of_Units"] = mobile_crane

    def LanWiseGrid(self, row: pd.DataFrame):
        irr = row["IRR"]
        lan = row["NEW/REFINANCE_OP"]
        type = row["Strategic/FTU/Retail_OP"]
            
        if(irr <= 9.10):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_PAYOUT"] = 3000
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 3000
                else:
                    row["LAN_PAYOUT"] = 0.0
            else:
                if(type == "STRATEGIC"):
                    row["LAN_PAYOUT"] = 0.0
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 0.0
                else:
                    row["LAN_PAYOUT"] = 0.0  
                               
        elif(irr <= 9.6):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0030
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 3000
                else:
                    row["LAN_PAYOUT"] = 0.0
            else:
                if(type == "STRATEGIC"):
                    row["LAN_PAYOUT"] = 3000
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 0.0
                else:
                    row["LAN_PAYOUT"] = 0.0
                    
        elif(irr <= 9.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0070
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 3000
                else:
                    row["LAN_PAYOUT"] = 0.0
            else:
                if(type == "STRATEGIC"):
                    row["LAN_PAYOUT"] = 3000
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 2000
                else:
                    row["LAN_PAYOUT"] = 0.0
                    
        elif(irr <= 10.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0080
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0030
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0030
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 2000
                else:
                    row["LAN_PAYOUT"] = 0.0
        elif(irr <= 10.60):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0090
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0080
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0030
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 2000
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 10.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.011
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0090
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0070
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 2000
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 11.10):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0120
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.010
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0090
                elif(type == "RETAIL"):
                    row["LAN_PAYOUT"] = 2000
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 11.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0130
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0110
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0110
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0030
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 11.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0150
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0130
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0130
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0070
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 12.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0170
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0130
                else:
                    row["LAN_PAYOUT"] = 3000
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0150
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0090
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 12.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0190
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0150
                else:
                    row["LAN_WISE_RATE"] = 0.0055
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0170
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0110
                else:
                    row["LAN_PAYOUT"] = 2000
                    
        elif(irr <= 13.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0210
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0170
                else:
                    row["LAN_WISE_RATE"] = 0.00650
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0190
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0130
                else:
                    row["LAN_WISE_RATE"] = 0.0030
                    
        elif(irr <= 13.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0230
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0190
                else:
                    row["LAN_WISE_RATE"] = 0.010
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0210
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0130
                else:
                    row["LAN_WISE_RATE"] = 0.0030
                    
        elif(irr <= 14.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0250
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0210
                else:
                    row["LAN_WISE_RATE"] = 0.0120
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0230
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0150
                else:
                    row["LAN_WISE_RATE"] = 0.0030
                    
        elif(irr <= 14.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0270
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0230
                else:
                    row["LAN_WISE_RATE"] = 0.0140
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0250
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0170
                else:
                    row["LAN_WISE_RATE"] = 0.010
                    
        elif(irr <= 15.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0290
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0250
                else:
                    row["LAN_WISE_RATE"] = 0.0160
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0270
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0190
                else:
                    row["LAN_WISE_RATE"] = 0.0120
                    
        elif(irr <= 15.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0310
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0270
                else:
                    row["LAN_WISE_RATE"] = 0.0180
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0290
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0210
                else:
                    row["LAN_WISE_RATE"] = 0.0140
                    
        elif(irr <= 16.35):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0330
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0290
                else:
                    row["LAN_WISE_RATE"] = 0.0200
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0310
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0230
                else:
                    row["LAN_WISE_RATE"] = 0.0160
                    
        elif(irr <= 16.85):
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0350
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0310
                else:
                    row["LAN_WISE_RATE"] = 0.0220
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0330
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0250
                else:
                    row["LAN_WISE_RATE"] = 0.0180
        else:
            if(lan == "NEW"):
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0370
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0330
                else:
                    row["LAN_WISE_RATE"] = 0.0240
            else:
                if(type == "STRATEGIC"):
                    row["LAN_WISE_RATE"] = 0.0350
                elif(type == "RETAIL"):
                    row["LAN_WISE_RATE"] = 0.0270
                else:
                    row["LAN_WISE_RATE"] = 0.020
                    
        if(row["BODY/TOPUP"] in ["BODY", "TOPUP"]):
            if((irr/100) < row["MIN_LOGIN_RATE"]):
                    row["LAN_PAYOUT"] = 0.0
                    row["LAN_WISE_RATE"] = 0.0
                     
        return row
                      
    def SetBody_Topup(self):
        self.df.loc[(self.df["PROMOTIONDESC"].str.lower().str.contains("top")), "BODY/TOPUP"] = "TOPUP"
        self.df.loc[(self.df["MAKE"].str.lower().str.contains("body") | self.df["MODELNAME"].str.lower().str.contains("body") | self.df["ASSET_CATG"].str.lower().str.contains("body") | (self.df["Chassis / Body / CE"] == "BODY")), "BODY/TOPUP"] = "BODY"

    def SetNewLoanAmt(self):
        self.df.loc[((self.df["IRR"]/100) < self.df["MIN_LOGIN_RATE"]), "VOL_LOAN_AMT"] = 0

    def GroupByVolume(self):
        grp = self.df.groupby(["DMA_BROKER_ID", "Strategic/FTU/Retail_OP"])
        for code, grp in grp:
            self.df.loc[((self.df["DMA_BROKER_ID"] == code[0]) & (self.df["Strategic/FTU/Retail_OP"] == code[1])), "Total_Disbursement_Amount"] = grp["VOL_LOAN_AMT"].sum() 

    def CalculateVolumeWise(self, row):
        amt = row["Total_Disbursement_Amount"]
        type = row["Strategic/FTU/Retail_OP"]
        irr = row["IRR"]
        if(amt < 5000000):
            return row
        elif(amt < 10000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.0
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.001
            else:
                row["VOL_WISE_RATE"] = 0.002
        elif(amt < 15000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.001
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.001
            else:
                row["VOL_WISE_RATE"] = 0.004
        elif(amt < 20000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.001
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.002
            else:
                row["VOL_WISE_RATE"] = 0.006
        elif(amt < 25000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.001
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.002
            else:
                row["VOL_WISE_RATE"] = 0.008
        elif(amt < 30000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.002
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.003
            else:
                row["VOL_WISE_RATE"] = 0.010
        elif(amt < 35000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.002
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.003
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 40000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.003
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.003
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 45000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.003
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.005
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 50000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.003
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.005
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 55000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.005
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 60000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.007
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 65000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.007
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 70000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.007
            else:
                row["VOL_WISE_RATE"] = 0.012
        elif(amt < 75000000):
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.007
            else:
                row["VOL_WISE_RATE"] = 0.012
        else:
            if(type == "STRATEGIC"):
                row["VOL_WISE_RATE"] = 0.004
            elif(type == "RETAIL"):
                row["VOL_WISE_RATE"] = 0.008
            else:
                row["VOL_WISE_RATE"] = 0.012

        if((irr/100) < row["MIN_LOGIN_RATE"]):
            row["VOL_PAYOUT"] = 0.0
            row["VOL_WISE_RATE"] = 0.0


        return row
    
    def FinalCalculation(self, row: pd.DataFrame):

        def round_up(n,decimals=0):
            multiplier=10**decimals
            return math.floor(n*multiplier + 0.5)/multiplier
        row["LOAN_AMT"]=round_up(row["LOAN_AMT"])
        row["VOL_LOAN_AMT"]=round_up(row["VOL_LOAN_AMT"])
        
        if(row["LAN_PAYOUT"] == 0.0):
            row["LAN_PAYOUT"] = round(row["LAN_WISE_RATE"] * row["LOAN_AMT"],3)
            row["LAN_PAYOUT"]=round_up(row["LAN_PAYOUT"])
        row["VOL_PAYOUT"] = round(row["VOL_WISE_RATE"] * row["VOL_LOAN_AMT"],3)
        row["VOL_PAYOUT"]=round_up(row["VOL_PAYOUT"])
        row["Final Payout"] = (row["LAN_PAYOUT"] + row["VOL_PAYOUT"])
        row["PAYOUT"] = (row["LAN_PAYOUT"] + row["VOL_PAYOUT"])
        
        return row
        
    def SegregatePayout(self, row: pd.DataFrame):
        lan = row["NEW/REFINANCE_OP"]
        type = row["Strategic/FTU/Retail_OP"]
        
        if(type == "STRATEGIC"):
            if(lan == "NEW"):
                row["STRATEGIC_NEW_LAN_PO"] = row["LAN_PAYOUT"]
            else:
                row["STRATEGIC_REFINANCE_LAN_PO"] = row["LAN_PAYOUT"]
            row["STRATEGIC_VOL_PO"] = row["VOL_PAYOUT"]
            
        elif(type == "RETAIL"):
            if(lan == "NEW"):
                row["RETAIL_NEW_LAN_PO"] = row["LAN_PAYOUT"]
            else:
                row["RETAIL_REFINANCE_LAN_PO"] = row["LAN_PAYOUT"]
            row["RETAIL_VOL_PO"] = row["VOL_PAYOUT"]
            
        else:
            if(lan == "NEW"):
                row["FTU_NEW_LAN_PO"] = row["LAN_PAYOUT"]
            else:
                row["FTU_REFINANCE_LAN_PO"] = row["LAN_PAYOUT"]
            row["FTU_VOL_PO"] = row["VOL_PAYOUT"]
        
        return row
        
    def PSLCases(self, row: pd.DataFrame):
        if(row["PSL_FLAG"].lower() == "n"):
            reduction = (row["LOAN_AMT"]) * 0.0010
        
            new_ref = row["NEW/REFINANCE_OP"]
            type = row["Strategic/FTU/Retail_OP"]
            
            mapping = {
                "STRATEGICNEW": 3000,
                "RETAILNEW": 3000,
                "FTUNEW": 3000,
                "STRATEGICREFINANCE": 3000,
                "RETAILREFINANCE": 2000,
                "FTUREFINANCE": 2000  
            }
            
            if(row["Final Payout"] > mapping[type+new_ref]):
                row["NON_PSL_Percentage"] = 0.0010
                row["NON_PSL_VALUE"] = reduction
                row["Final Payout"] -= reduction
        
        return row
    
    def ConnectorCases(self, row):
        irr = row["IRR"]
        if(row["DSA/ Direct/ Connector"].lower() == "connector"):
            if((irr/100) < row["MIN_LOGIN_RATE"]):
                row["CONNECTOR PO"] = 2000
                row["Final Payout"] = 2000
            else:
                state = row["State as per CB Product"].lower()
                category = row["Category"].lower()
                if(state != "tamil nadu"):
                    if(category == "scv"):
                        row["CONNECTOR PO"] = 2500
                        row["Final Payout"] = 2500
                    elif(category in ["lcv", "icv"]):
                        row["CONNECTOR PO"] = 4000
                        row["Final Payout"] = 4000
                    elif(category in ["hcv", "ce"]):
                        row["CONNECTOR PO"] = 5000
                        row["Final Payout"] = 5000
                else:
                    if(category == "scv"):
                        row["CONNECTOR PO"] = 3500
                        row["Final Payout"] = 3500
                    elif(category in ["lcv", "icv"]):
                        row["CONNECTOR PO"] = 5000
                        row["Final Payout"] = 5000
                    elif(category in ["hcv", "ce"]):
                        row["CONNECTOR PO"] = 6000
                        row["Final Payout"] = 6000
                        
            if(row["Strategic/FTU/Retail_OP"].lower() == "strategic"):
                row["Final Payout"] = -100
        
        return row        

    def RemoveNovation(self):
        self.df["Novation Scheme Code"].fillna("-", inplace=True)
        temp = self.df[self.df["Novation Scheme Code"].str.lower().str.contains("novation")].copy()["AGREEMENTNO"]
        temp = pd.DataFrame(temp)
        temp["REMARK"] = "Novation"
        self.rejected_df = pd.concat([self.rejected_df, temp], ignore_index=True)
        self.df = self.df[self.df["Novation Scheme Code"].str.lower().str.contains("novation") == False]

    def AssetPO(self, row:pd.DataFrame):
        flag = False
        if(row["DSA/ Direct/ Connector"].lower() == "connector"):
            if(row["Equipment"] != "-"):
                irr = row["IRR"]
                if(row["Strategic/FTU/Retail_OP"] == "RETAIL"):
                    if(row["NEW/REFINANCE_OP"] == "NEW"):
                        if(irr < 9.75):
                            row["Asset_PO"] = 2000
                            row["Final Payout"] += 2000
                            flag = True
                    else:
                        if(irr < 10.75):
                            row["Asset_PO"] = 2000
                            row["Final Payout"] += 2000
                            flag = True
                elif(row["Strategic/FTU/Retail_OP"] == "FTU"):
                    if(row["NEW/REFINANCE_OP"] == "NEW"):
                        if(irr < 11.00):
                            row["Asset_PO"] = 2000
                            row["Final Payout"] += 2000
                            flag = True
                    else:
                        if(irr < 12.00):
                            row["Asset_PO"] = 2000
                            row["Final Payout"] += 2000
                            flag = True
                            
                if(flag == False):

                    if(row["Strategic/FTU/Retail_OP"] == "RETAIL"):
                        if(row["NEW/REFINANCE_OP"] == "NEW"):
                            if(irr >= 10.10):
                                unit = row["No_Of_Units"]
                                equipment = row["Equipment"]
                                if(unit < 4):
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 5000
                                        row["Final Payout"] += 5000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 6000
                                        row["Final Payout"] += 6000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 3500
                                        row["Final Payout"] += 3500
                                elif(unit < 8):
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 7000
                                        row["Final Payout"] += 7000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 8000
                                        row["Final Payout"] += 8000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 4500
                                        row["Final Payout"] += 4500
                                else:
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 8000
                                        row["Final Payout"] += 8000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 9000
                                        row["Final Payout"] += 9000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 5000
                                        row["Final Payout"] += 5000
                    elif(row["Strategic/FTU/Retail_OP"] == "FTU"):
                        if(row["NEW/REFINANCE_OP"] == "NEW"):
                            if(irr >= 11.35):
                                unit = row["No_Of_Units"]
                                equipment = row["Equipment"]
                                if(unit < 4):
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 5000
                                        row["Final Payout"] += 5000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 6000
                                        row["Final Payout"] += 6000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 3500
                                        row["Final Payout"] += 3500
                                elif(unit < 8):
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 7000
                                        row["Final Payout"] += 7000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 8000
                                        row["Final Payout"] += 8000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 4500
                                        row["Final Payout"] += 4500
                                else:
                                    if(equipment == "BHL"):
                                        row["Asset_PO"] = 8000
                                        row["Final Payout"] += 8000 
                                    elif(equipment == "Excavator"):
                                        row["Asset_PO"] = 9000
                                        row["Final Payout"] += 9000
                                    elif(equipment == "Mobile Crane"):
                                        row["Asset_PO"] = 5000
                                        row["Final Payout"] += 5000

        return row
         
    def split_connector(self):
        self.with_connector=self.df[self.df["DSA/ Direct/ Connector"].str.lower()=="connector"]
        self.without_connector=self.df[self.df["DSA/ Direct/ Connector"].str.lower()!="connector"]
        self.with_connector=self.with_connector.drop(["VOL_LOAN_AMT","LAN_WISE_RATE","Total_Disbursement_Amount","VOL_WISE_RATE","STRATEGIC_NEW_LAN_PO","RETAIL_NEW_LAN_PO","FTU_NEW_LAN_PO","STRATEGIC_REFINANCE_LAN_PO","RETAIL_REFINANCE_LAN_PO","FTU_REFINANCE_LAN_PO","STRATEGIC_VOL_PO","RETAIL_VOL_PO","FTU_VOL_PO"],axis=1)
    
    def Round_off(self,row:pd.DataFrame,i):
        if(isinstance(row[i],float)==True):
            row[i]=round((row[i]),1)
            # # if(a%5==0):
            # #     row[i]=row[i]+0.5
            # print(row[i])
            farc,whole=math.modf(row[i])
            if(farc==0.5):
                row[i]=row[i]+0.5
                
        return row
    def PF(self):
        self.df["PO_rate"]=0
        self.df["PO_Amount"]=0
        # self.df["NON_PSL_Percentage"] = 0

        # self.df["NON_PSL_VALUE"] = 0
        # self.df["Final Payout"] = 0.0
        # self.df["PF"]=(self.df["PROCESSING_FEE"]/self.df["AMTFIN"])*100
        # self.df["0.25% of loan"]=self.df["AMTFIN"]*0.0025
        # self.df["balance_amount"]=self.df["PROCESSING_FEE"]-self.df["0.25% of loan"]
        # self.df.loc[(self.df["IRR"].between(8.70,9.00,inclusive="both")),"PO_rate"]=0.35
        self.df.loc[(self.df["IRR"].between(9.00,9.50,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="NEW"),"PO_rate"]=0.0035
        self.df.loc[(self.df["IRR"].between(9.50,9.75,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="NEW"),"PO_rate"]=0.0075
        self.df.loc[(self.df["IRR"].between(9.75,10.00,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="NEW"),"PO_rate"]=0.0090
        self.df.loc[(self.df["IRR"]>10)&(self.df["NEW/REFINANCE_OP"]=="NEW"),"PO_rate"]=0.01
        
        # self.df.loc[(self.df["IRR"].between(9.00,9.50,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="REFINANCE"),"PO_rate"]=0.35
        # self.df.loc[(self.df["IRR"].between(9.50,9.75,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="REFINANCE"),"PO_rate"]=0.75
        self.df.loc[(self.df["IRR"].between(9.75,10.00,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="REFINANCE"),"PO_rate"]=0.0035
        self.df.loc[(self.df["IRR"]>10)&(self.df["NEW/REFINANCE_OP"]=="REFINANCE"),"PO_rate"]=0.0075
        self.df["PO_Amount"]=round(self.df["PO_rate"]*self.df["VOL_LOAN_AMT"],3)
        
        self.df.loc[(self.df["IRR"].between(8.70,9.00,inclusive="both"))&(self.df["NEW/REFINANCE_OP"]=="NEW"),"PO_Amount"]=3000
        self.df.loc[(self.df["IRR"].between(9.50,9.75,inclusive="right"))&(self.df["NEW/REFINANCE_OP"]=="REFINANCE"),"PO_Amount"]=5000
        
        
        def Round_off(row:pd.DataFrame):
                
            def round_up(n,decimals=0):
                multiplier=10**decimals
                return math.floor(n*multiplier + 0.5)/multiplier
            row["PO_Amount"]=round_up(row["PO_Amount"])


            return row
        self.df=self.df.apply(lambda x:Round_off(x),axis=1)
        # self.df.drop(columns=["ADV_EMI","Net_loan","Gross_payout","Cancellations","Revised Gross Payout","Ref. No 80per","Ref. No 20per"],inplace=True)
        # self.df.rename(columns={"Loan Amount":"Net_loan"},inplace=True)
        # self.df["PO_Amount"]=self.df["PO_rate"]*self.df["VOL_LOAN_AMT"]
        
        # self.df.loc[(self.df["IRR"]>10.35),"PO_rate"]=(self.df["balance_amount"])
        # self.df.loc[(self.df["PSL_FLAG"]=="N"),"NON_PSL_Percentage"]="1%"
        # self.df.loc[(self.df["PSL_FLAG"]=="N"),"NON_PSL_VALUE"]=self.df["AMTFIN"]*0.0010
        # self.df["Final Payout"]=self.df["PO_Amount"]-self.df["NON_PSL_VALUE"]
        
        
        
        
        
    def execute(self):
        self.PF()
        # self.AddColumnBasedOnPromotionDesc()
        # self.Initialization()
        # self.RemoveNovation()
        # self.SetMinLoginRate()
        # self.SetBody_Topup()
        # self.df = self.df.apply(lambda row : self.LanWiseGrid(row), axis=1)
        # self.SetNewLoanAmt()
        # self.GroupByVolume()
        # self.df = self.df.apply(lambda row : self.CalculateVolumeWise(row), axis=1)
        # self.df = self.df.apply(lambda row: self.FinalCalculation(row), axis=1)
        # self.df = self.df.apply(lambda row: self.SegregatePayout(row), axis=1)
        # self.df = self.df.apply(lambda row: self.ConnectorCases(row), axis=1)
        # temp = self.df[(self.df["Final Payout"] == -100)].copy()["AGREEMENTNO"]
        # temp = pd.DataFrame(temp)
        # temp["REMARK"] = "Startegic Connector"
        # self.rejected_df = pd.concat([self.rejected_df, temp], ignore_index=True)
        # self.df = self.df[(self.df["Final Payout"] != -100)]
        # self.SetNoOfUnits()
        # self.df = self.df.apply(lambda row: self.AssetPO(row), axis=1)
        # self.df = self.df.apply(lambda row: self.PSLCases(row), axis=1)
        # self.df.reset_index(drop=True, inplace=True)
        # self.df.drop(["LAN_PAYOUT", "VOL_PAYOUT"], axis = 1, inplace=True)
        # list=["STRATEGIC_NEW_LAN_PO","RETAIL_NEW_LAN_PO","FTU_NEW_LAN_PO","STRATEGIC_REFINANCE_LAN_PO","RETAIL_REFINANCE_LAN_PO","FTU_REFINANCE_LAN_PO","STRATEGIC_VOL_PO","RETAIL_VOL_PO","FTU_VOL_PO","Asset_PO","CONNECTOR PO","NON_PSL_VALUE","PAYOUT","Final Payout"]
        # for i in list:
        #     self.df = self.df.apply(lambda row : self.Round_off(row,i), axis=1)
        #     self.df[i]=round(self.df[i])
        # self.split_connector()
        

